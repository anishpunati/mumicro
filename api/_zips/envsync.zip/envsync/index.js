#!/usr/bin/env node
// envsync — diff your .env against .env.example
// Zero dependencies. Works with any Node.js >=14.

const fs = require('fs');
const path = require('path');

const VERSION = '1.0.0';

const RESET  = '\x1b[0m';
const RED    = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN  = '\x1b[32m';
const BOLD   = '\x1b[1m';
const DIM    = '\x1b[2m';

function parseEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const lines = fs.readFileSync(filePath, 'utf8').split('\n');
  const keys = new Map();
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    const val = line.slice(eq + 1).trim();
    keys.set(key, val);
  }
  return keys;
}

function help() {
  console.log(`
${BOLD}envsync${RESET} v${VERSION} — diff .env against .env.example

${BOLD}Usage:${RESET}
  envsync [options] [example-file] [env-file]

${BOLD}Arguments:${RESET}
  example-file   Path to the reference file  (default: .env.example)
  env-file       Path to the active env file (default: .env)

${BOLD}Options:${RESET}
  --strict       Exit 1 if any keys are missing or empty
  --no-color     Disable color output
  --version      Print version
  --help         Show this help

${BOLD}Examples:${RESET}
  envsync
  envsync .env.example .env.local
  envsync --strict
  envsync .env.template .env.production --strict
`);
}

const args = process.argv.slice(2);

if (args.includes('--version')) { console.log(VERSION); process.exit(0); }
if (args.includes('--help'))    { help(); process.exit(0); }

const strict   = args.includes('--strict');
const noColor  = args.includes('--no-color');
const positional = args.filter(a => !a.startsWith('--'));

const examplePath = positional[0] || '.env.example';
const envPath     = positional[1] || '.env';

const c = noColor
  ? { red:'', yellow:'', green:'', bold:'', dim:'', reset:'' }
  : { red:RED, yellow:YELLOW, green:GREEN, bold:BOLD, dim:DIM, reset:RESET };

const example = parseEnvFile(path.resolve(examplePath));
const env     = parseEnvFile(path.resolve(envPath));

if (!example) {
  console.error(`${c.red}✗ not found: ${examplePath}${c.reset}`);
  process.exit(1);
}
if (!env) {
  console.error(`${c.red}✗ not found: ${envPath}${c.reset}`);
  process.exit(1);
}

const missing = [];
const extra   = [];
const empty   = [];
const ok      = [];

for (const [key] of example) {
  if (!env.has(key))             missing.push(key);
  else if (env.get(key) === '')  empty.push(key);
  else                           ok.push(key);
}
for (const [key] of env) {
  if (!example.has(key)) extra.push(key);
}

const label = (sym, col, text) => `${col}${sym}${c.reset} ${text}`;

console.log(`\n${c.bold}envsync${c.reset}  ${c.dim}${examplePath} → ${envPath}${c.reset}\n`);

if (missing.length === 0 && empty.length === 0 && extra.length === 0) {
  console.log(`${c.green}✓ All ${ok.length} keys are present and set.${c.reset}\n`);
  process.exit(0);
}

for (const k of missing) console.log(label('✗ MISSING', c.red,    k));
for (const k of empty)   console.log(label('⚠ EMPTY  ', c.yellow, k));
for (const k of extra)   console.log(label('+ EXTRA  ', c.dim,    k));
if (ok.length)            console.log(`\n${c.green}✓ OK: ${ok.length} key(s)${c.reset}`);

console.log('');

const shouldFail = strict && (missing.length > 0 || empty.length > 0);
process.exit(shouldFail ? 1 : 0);
