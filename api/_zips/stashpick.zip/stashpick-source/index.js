#!/usr/bin/env node
'use strict';

const { execSync } = require('child_process');

const VERSION = '1.0.0';

// ─── ANSI helpers ──────────────────────────────────────────────────────────
const ESC    = '\x1b[';
const CLEAR  = ESC + '2J';
const HOME   = ESC + 'H';
const HIDE_C = ESC + '?25l';
const SHOW_C = ESC + '?25h';
const RESET  = '\x1b[0m';
const BOLD   = '\x1b[1m';
const DIM    = '\x1b[2m';
const RED    = '\x1b[31m';
const GREEN  = '\x1b[32m';
const YELLOW = '\x1b[33m';
const CYAN   = '\x1b[36m';
const WHITE  = '\x1b[37m';
const BG_SEL = '\x1b[48;5;237m';

function w(s) { process.stdout.write(s); }

// ─── CLI flags ─────────────────────────────────────────────────────────────
const args = process.argv.slice(2);

if (args.includes('--version') || args.includes('-v')) {
  console.log(`stashpick v${VERSION}`);
  process.exit(0);
}

if (args.includes('--help') || args.includes('-h')) {
  console.log(
`stashpick v${VERSION}

  Interactive git stash browser — arrow-key through stashes,
  preview diffs, and apply / pop / drop with a single keypress.

USAGE
  npx stashpick

KEYS
  ↑ / k     move up
  ↓ / j     move down
  a         apply selected stash (keeps it in the list)
  p         pop selected stash (apply + remove from list)
  d         drop selected stash (permanently delete)
  q / Esc   quit without changing anything

REQUIREMENTS
  Must be run inside a git repository.
  Requires git 2.x+.
`);
  process.exit(0);
}

// ─── Git sanity check ──────────────────────────────────────────────────────
try {
  execSync('git rev-parse --git-dir', { stdio: 'ignore' });
} catch (_) {
  console.error('stashpick: not inside a git repository.');
  process.exit(1);
}

// ─── Data ─────────────────────────────────────────────────────────────────
function getStashes() {
  try {
    const out = execSync('git stash list --format=%gd%x09%ai%x09%s', { encoding: 'utf8' }).trim();
    if (!out) return [];
    return out.split('\n').map(line => {
      const parts = line.split('\t');
      return {
        ref:  parts[0] || '',
        date: (parts[1] || '').slice(0, 10),
        msg:  parts.slice(2).join('\t').trim()
      };
    });
  } catch (_) { return []; }
}

const diffCache = {};
function getDiff(ref) {
  if (diffCache[ref] !== undefined) return diffCache[ref];
  try {
    const raw = execSync(`git stash show -p --stat "${ref}"`, {
      encoding: 'utf8', maxBuffer: 512 * 1024, stdio: ['ignore', 'pipe', 'ignore']
    });
    diffCache[ref] = raw;
  } catch (_) { diffCache[ref] = '(no diff available)'; }
  return diffCache[ref];
}

// ─── Rendering ─────────────────────────────────────────────────────────────
function colorDiffLine(line) {
  if (line.startsWith('+++') || line.startsWith('---')) return DIM + line + RESET;
  if (line.startsWith('+'))  return GREEN + line + RESET;
  if (line.startsWith('-'))  return RED   + line + RESET;
  if (line.startsWith('@@')) return CYAN  + line + RESET;
  if (/^(diff|index|new file|deleted file|old mode|new mode)/.test(line)) return BOLD + line + RESET;
  return DIM + line + RESET;
}

function truncate(s, len) {
  if (!s) return ' '.repeat(len);
  if (s.length <= len) return s + ' '.repeat(len - s.length);
  return s.slice(0, len - 1) + '…';
}

// Strip ANSI for length calculation
function visLen(s) { return s.replace(/\x1b\[[0-9;]*m/g, '').length; }

function render(stashes, sel) {
  const cols = Math.max(process.stdout.columns || 100, 60);
  const rows = Math.max(process.stdout.rows    || 30,  10);

  const LIST_W  = Math.min(52, Math.floor(cols * 0.42));
  const DIVIDER = ' │ ';
  const DIFF_W  = cols - LIST_W - DIVIDER.length;
  const HEADER  = 3;   // title + subtitle + separator
  const FOOTER  = 2;   // separator + status
  const BODY    = rows - HEADER - FOOTER;

  w(CLEAR + HOME + HIDE_C);

  // Title bar
  const title = ` stashpick  ${stashes.length} stash${stashes.length !== 1 ? 'es' : ''}`;
  const help  = 'a=apply  p=pop  d=drop  q=quit ';
  const pad   = Math.max(0, cols - title.length - help.length);
  w(BOLD + CYAN + title + RESET + DIM + ' '.repeat(pad) + help + RESET + '\n');

  // Column headers
  const refH  = truncate('ref', 11);
  const dateH = truncate('date', 10);
  const msgH  = truncate('message', LIST_W - 23);
  w(DIM + ' ' + refH + '  ' + dateH + '  ' + msgH + DIVIDER +
    truncate('diff preview', DIFF_W) + RESET + '\n');

  w(DIM + '─'.repeat(cols) + RESET + '\n');

  // Visible stash window (scrolling)
  const halfBody = Math.floor(BODY / 2);
  const start    = Math.max(0, Math.min(sel - halfBody, stashes.length - BODY));
  const end      = Math.min(stashes.length, start + BODY);

  // Diff lines for selected stash
  const diffText  = getDiff(stashes[sel].ref);
  const diffLines = diffText.split('\n');

  for (let row = 0; row < BODY; row++) {
    const si = start + row;
    let leftSide = '';

    if (si < end) {
      const s   = stashes[si];
      const isSel = si === sel;
      const arrow = isSel ? BOLD + YELLOW + '▶ ' + RESET : '  ';
      const ref   = DIM  + truncate(s.ref,  11) + RESET;
      const date  = DIM  + truncate(s.date, 10) + RESET;
      const msgW  = LIST_W - 25;
      const msg   = isSel
        ? BOLD + truncate(s.msg, msgW) + RESET
        : DIM  + truncate(s.msg, msgW) + RESET;
      const line  = arrow + ref + '  ' + date + '  ' + msg;
      leftSide = (isSel ? BG_SEL : '') + line + (isSel ? RESET : '');
    } else {
      leftSide = ' '.repeat(LIST_W);
    }

    const dl        = diffLines[row] || '';
    const diffCol   = colorDiffLine(dl).slice(0, DIFF_W * 4); // generous buffer for ANSI

    // Pad left side to fixed visual width
    const leftVis  = visLen(leftSide.replace(/\x1b\[[0-9;]*m/g, ''));
    const leftPad  = ' '.repeat(Math.max(0, LIST_W - leftVis));

    w(leftSide + leftPad + DIM + DIVIDER + RESET + diffCol + '\n');
  }

  w(DIM + '─'.repeat(cols) + RESET + '\n');

  // Status bar
  const s = stashes[sel];
  const statusLeft = ` ${sel + 1}/${stashes.length}  ${s.ref}  ${s.msg}`;
  w(DIM + truncate(statusLeft, cols - 1) + RESET);
}

// ─── Actions ──────────────────────────────────────────────────────────────
function cleanup() {
  try {
    process.stdin.setRawMode(false);
    process.stdin.pause();
  } catch (_) {}
  w(SHOW_C + CLEAR + HOME);
}

function runGit(cmd, label, ref) {
  cleanup();
  try {
    execSync(cmd, { stdio: 'inherit' });
    console.log(`\n${label}: ${ref}`);
  } catch (e) {
    console.error(`\nFailed to ${label.toLowerCase()} ${ref}`);
    process.exit(1);
  }
  process.exit(0);
}

// ─── Main ─────────────────────────────────────────────────────────────────
const stashes = getStashes();

if (stashes.length === 0) {
  console.log('stashpick: no stashes found in this repository.');
  process.exit(0);
}

let sel = 0;

process.stdin.setRawMode(true);
process.stdin.resume();
process.stdin.setEncoding('utf8');

process.on('SIGINT', () => { cleanup(); process.exit(0); });
process.on('exit',   cleanup);

render(stashes, sel);

process.stdin.on('data', key => {
  const ref = stashes[sel].ref;

  // Quit
  if (key === 'q' || key === '\x1b' || key === '\x03') {
    cleanup(); process.exit(0);
  }

  // Navigation
  if (key === '\x1b[A' || key === 'k') {
    sel = Math.max(0, sel - 1);
    render(stashes, sel);
    return;
  }
  if (key === '\x1b[B' || key === 'j') {
    sel = Math.min(stashes.length - 1, sel + 1);
    render(stashes, sel);
    return;
  }

  // Actions
  if (key === 'a') runGit(`git stash apply "${ref}"`, 'Applied', ref);
  if (key === 'p') runGit(`git stash pop "${ref}"`,   'Popped',  ref);
  if (key === 'd') runGit(`git stash drop "${ref}"`,  'Dropped', ref);
});
