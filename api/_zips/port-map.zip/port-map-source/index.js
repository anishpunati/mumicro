#!/usr/bin/env node
'use strict';

const http = require('http');
const { execSync, exec } = require('child_process');

const VERSION = '1.0.0';
const SLUG = 'port-map';

if (process.argv.includes('--version')) {
  console.log(VERSION);
  process.exit(0);
}

if (process.argv.includes('--help')) {
  console.log(`
${SLUG} v${VERSION}

  Scan all listening TCP ports on this machine and open a live web dashboard.

Usage:
  npx ${SLUG}          Open the dashboard in your default browser
  npx ${SLUG} --json   Print port data as JSON and exit (pipe-friendly)
  npx ${SLUG} --help   Show this help
  npx ${SLUG} --version Show version

Examples:
  npx ${SLUG}
  npx ${SLUG} --json
  npx ${SLUG} --json | grep '"process"'
`);
  process.exit(0);
}

function getPorts() {
  const platform = process.platform;
  let output = '';

  try {
    if (platform === 'darwin') {
      output = execSync('lsof -iTCP -sTCP:LISTEN -n -P 2>/dev/null', { encoding: 'utf8' });
    } else {
      try {
        output = execSync('ss -tlnp 2>/dev/null', { encoding: 'utf8' });
      } catch (_) {
        output = execSync('netstat -tlnp 2>/dev/null', { encoding: 'utf8' });
      }
    }
  } catch (_) {
    return [];
  }

  const ports = [];
  const seen = new Set();

  if (platform === 'darwin') {
    const lines = output.split('\n').slice(1);
    for (const line of lines) {
      const parts = line.trim().split(/\s+/);
      if (parts.length < 9) continue;
      const cmd = parts[0];
      const pid = parts[1];
      const name = parts[8] || '';
      const portMatch = name.match(/:(\d+)$/);
      if (!portMatch) continue;
      const port = parseInt(portMatch[1], 10);
      const address = name.slice(0, name.lastIndexOf(':'));
      const key = `${port}-${pid}`;
      if (seen.has(key)) continue;
      seen.add(key);
      ports.push({ port, pid: parseInt(pid, 10), process: cmd, address });
    }
  } else {
    const lines = output.split('\n').slice(1);
    for (const line of lines) {
      const parts = line.trim().split(/\s+/);
      if (parts.length < 4) continue;
      const localAddr = parts[3] || '';
      const portMatch = localAddr.match(/:(\d+)$/);
      if (!portMatch) continue;
      const port = parseInt(portMatch[1], 10);
      const address = localAddr.slice(0, localAddr.lastIndexOf(':'));
      const processInfo = parts.slice(5).join(' ');
      const pidMatch = processInfo.match(/pid=(\d+)/);
      const cmdMatch = processInfo.match(/users:\(\("([^"]+)"/);
      const pid = pidMatch ? parseInt(pidMatch[1], 10) : 0;
      const cmd = cmdMatch ? cmdMatch[1] : 'unknown';
      const key = `${port}-${pid}`;
      if (seen.has(key)) continue;
      seen.add(key);
      ports.push({ port, pid, process: cmd, address });
    }
  }

  return ports.sort((a, b) => a.port - b.port);
}

if (process.argv.includes('--json')) {
  console.log(JSON.stringify(getPorts(), null, 2));
  process.exit(0);
}

function buildPage(ports, capturedAt) {
  const portsJson = JSON.stringify(ports);
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>port-map</title>
<style>
  :root {
    --bg: #0f1117;
    --surface: #1a1d27;
    --border: #2d3148;
    --text: #e2e8f0;
    --muted: #64748b;
    --accent: #6366f1;
    --mono: 'SF Mono', 'Fira Code', 'Menlo', monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg); color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    min-height: 100vh; padding: 2rem 1.5rem;
  }
  .header {
    max-width: 860px; margin: 0 auto 1.5rem;
    display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap;
  }
  h1 { font-size: 1.4rem; font-weight: 700; letter-spacing: -0.02em; }
  h1 span { color: var(--accent); }
  .badge {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 9999px; padding: 0.2rem 0.7rem;
    font-size: 0.72rem; color: var(--muted); white-space: nowrap;
  }
  .search-wrap { max-width: 860px; margin: 0 auto 1.25rem; }
  input[type=text] {
    width: 100%; padding: 0.55rem 1rem;
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 8px; color: var(--text); font-size: 0.9rem; outline: none;
    transition: border-color 0.15s;
  }
  input[type=text]:focus { border-color: var(--accent); }
  .table-wrap {
    max-width: 860px; margin: 0 auto;
    border-radius: 10px; border: 1px solid var(--border); overflow: hidden;
  }
  table { width: 100%; border-collapse: collapse; }
  th {
    background: var(--surface); padding: 0.65rem 1rem;
    text-align: left; font-size: 0.7rem; text-transform: uppercase;
    letter-spacing: 0.06em; color: var(--muted);
    cursor: pointer; user-select: none; white-space: nowrap;
  }
  th:hover { color: var(--text); }
  td { padding: 0.65rem 1rem; border-top: 1px solid var(--border); font-size: 0.85rem; }
  tr:hover td { background: var(--surface); }
  .port { font-family: var(--mono); color: var(--accent); font-weight: 600; }
  .proc { font-weight: 500; }
  .pid  { font-family: var(--mono); color: var(--muted); font-size: 0.78rem; }
  .addr { font-family: var(--mono); color: var(--muted); font-size: 0.78rem; }
  .empty { text-align: center; padding: 3rem 1rem; color: var(--muted); font-size: 0.875rem; }
  .footer {
    max-width: 860px; margin: 1.25rem auto 0;
    font-size: 0.72rem; color: var(--muted); text-align: center;
  }
  #match-badge { display: none; }
</style>
</head>
<body>

<div class="header">
  <h1>port<span>-map</span></h1>
  <span class="badge" id="total-badge">${ports.length} listening port${ports.length !== 1 ? 's' : ''}</span>
  <span class="badge" id="match-badge"></span>
</div>

<div class="search-wrap">
  <input type="text" id="q" placeholder="Filter by port, process, or address…" autofocus>
</div>

<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th onclick="doSort('port')">Port</th>
        <th onclick="doSort('process')">Process</th>
        <th onclick="doSort('pid')">PID</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody id="tbody"></tbody>
  </table>
</div>

<div class="footer">
  port-map &middot; captured at ${capturedAt} &middot; press Enter in terminal to close
</div>

<script>
  const DATA = ${portsJson};
  let sortKey = 'port', sortAsc = true;

  function doSort(key) {
    if (sortKey === key) sortAsc = !sortAsc;
    else { sortKey = key; sortAsc = true; }
    render();
  }

  function render() {
    const q = document.getElementById('q').value.toLowerCase().trim();
    let rows = q
      ? DATA.filter(r =>
          String(r.port).includes(q) ||
          (r.process || '').toLowerCase().includes(q) ||
          (r.address || '').toLowerCase().includes(q))
      : DATA.slice();

    rows.sort((a, b) => {
      const av = a[sortKey] ?? '', bv = b[sortKey] ?? '';
      if (av < bv) return sortAsc ? -1 : 1;
      if (av > bv) return sortAsc ?  1 : -1;
      return 0;
    });

    const mb = document.getElementById('match-badge');
    if (q && rows.length !== DATA.length) {
      mb.textContent = rows.length + ' match' + (rows.length !== 1 ? 'es' : '');
      mb.style.display = 'inline';
    } else {
      mb.style.display = 'none';
    }

    const tbody = document.getElementById('tbody');
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="empty">No ports match your filter.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(r => \`<tr>
      <td><span class="port">\${r.port}</span></td>
      <td><span class="proc">\${r.process || 'unknown'}</span></td>
      <td><span class="pid">\${r.pid || '—'}</span></td>
      <td><span class="addr">\${r.address || '*'}</span></td>
    </tr>\`).join('');
  }

  document.getElementById('q').addEventListener('input', render);
  render();
</script>
</body>
</html>`;
}

function tryPort(preferred, cb) {
  const s = http.createServer();
  s.listen(preferred, '127.0.0.1', () => {
    const p = s.address().port;
    s.close(() => cb(p));
  });
  s.on('error', () => {
    const s2 = http.createServer();
    s2.listen(0, '127.0.0.1', () => {
      const p = s2.address().port;
      s2.close(() => cb(p));
    });
  });
}

tryPort(7777, (listenPort) => {
  const ports = getPorts();
  const capturedAt = new Date().toLocaleTimeString();
  const page = buildPage(ports, capturedAt);

  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(page);
  });

  server.listen(listenPort, '127.0.0.1', () => {
    const url = `http://localhost:${listenPort}`;
    console.log(`\nport-map — ${ports.length} listening port${ports.length !== 1 ? 's' : ''} found`);
    console.log(`Dashboard: ${url}`);
    console.log('Press Enter to close...\n');

    const opener = process.platform === 'darwin' ? 'open' : 'xdg-open';
    exec(`${opener} "${url}"`);
  });

  const autoClose = setTimeout(() => {
    console.log('Auto-closing after 60 seconds.');
    server.close(() => process.exit(0));
  }, 60000);

  process.stdin.setEncoding('utf8');
  process.stdin.once('data', () => {
    clearTimeout(autoClose);
    server.close(() => process.exit(0));
  });

  process.on('SIGINT', () => {
    clearTimeout(autoClose);
    server.close(() => process.exit(0));
  });
});
