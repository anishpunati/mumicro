#!/usr/bin/env node
// env-diff: Compare two .env files and surface missing, added, or changed variables
// Zero dependencies. Handles comments, quoted values, and `export` prefixes.

const fs = require('fs');
const path = require('path');

const RED    = '\x1b[31m';
const GREEN  = '\x1b[32m';
const YELLOW = '\x1b[33m';
const DIM    = '\x1b[2m';
const RESET  = '\x1b[0m';
const BOLD   = '\x1b[1m';
const VERSION = '1.0.0';

function usage() {
  console.log(`
${BOLD}env-diff v${VERSION}${RESET}
Compare two .env files and surface missing, added, or changed variables.

${BOLD}Usage:${RESET}
  npx env-diff <file-a> <file-b>

${BOLD}Options:${RESET}
  --keys-only   Only show key names, not values
  --json        Output result as JSON
  --help        Show this help
  --version     Show version

${BOLD}Examples:${RESET}
  npx env-diff .env .env.production
  npx env-diff .env.example .env --keys-only
`);
}

function parseEnv(filePath) {
  const abs = path.resolve(filePath);
  if (!fs.existsSync(abs)) {
    console.error(`${RED}Error: File not found: ${filePath}${RESET}`);
    process.exit(1);
  }
  const result = {};
  for (const raw of fs.readFileSync(abs, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const stripped = line.startsWith('export ') ? line.slice(7) : line;
    const eq = stripped.indexOf('=');
    if (eq === -1) continue;
    const key = stripped.slice(0, eq).trim();
    let val = stripped.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) ||
        (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (key) result[key] = val;
  }
  return result;
}

function mask(v) {
  if (!v) return DIM + '(empty)' + RESET;
  if (v.length <= 4) return '*'.repeat(v.length);
  return v.slice(0, 2) + '*'.repeat(Math.min(v.length - 4, 8)) + v.slice(-2);
}

const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) { usage(); process.exit(0); }
if (args.includes('--version') || args.includes('-v')) { console.log(VERSION); process.exit(0); }

const keysOnly = args.includes('--keys-only');
const asJson   = args.includes('--json');
const files    = args.filter(a => !a.startsWith('--'));

if (files.length !== 2) {
  console.error(`${RED}Error: Provide exactly two .env files.${RESET}`);
  usage(); process.exit(1);
}

const a = parseEnv(files[0]);
const b = parseEnv(files[1]);
const allKeys = new Set([...Object.keys(a), ...Object.keys(b)]);
const missing = [], added = [], changed = [], same = [];

for (const k of [...allKeys].sort()) {
  const inA = k in a, inB = k in b;
  if      (inA && !inB)    missing.push(k);
  else if (!inA && inB)    added.push(k);
  else if (a[k] !== b[k]) changed.push(k);
  else                     same.push(k);
}

if (asJson) {
  console.log(JSON.stringify({
    missing: missing.map(k => ({ key: k, ...(keysOnly ? {} : { was: a[k] }) })),
    added:   added.map(k =>   ({ key: k, ...(keysOnly ? {} : { now: b[k] }) })),
    changed: changed.map(k => ({ key: k, ...(keysOnly ? {} : { from: a[k], to: b[k] }) })),
    unchanged: same.length,
  }, null, 2));
  process.exit(0);
}

console.log(`\n${BOLD}env-diff:${RESET} ${DIM}${files[0]}${RESET} → ${DIM}${files[1]}${RESET}\n`);

if (missing.length) {
  console.log(`${BOLD}${RED}Missing in ${files[1]} (${missing.length}):${RESET}`);
  for (const k of missing)
    console.log(`  ${RED}− ${k}${RESET}${keysOnly ? '' : `  ${DIM}was: ${mask(a[k])}${RESET}`}`);
  console.log();
}
if (added.length) {
  console.log(`${BOLD}${GREEN}Added in ${files[1]} (${added.length}):${RESET}`);
  for (const k of added)
    console.log(`  ${GREEN}+ ${k}${RESET}${keysOnly ? '' : `  ${DIM}now: ${mask(b[k])}${RESET}`}`);
  console.log();
}
if (changed.length) {
  console.log(`${BOLD}${YELLOW}Changed (${changed.length}):${RESET}`);
  for (const k of changed) {
    console.log(`  ${YELLOW}~ ${k}${RESET}`);
    if (!keysOnly) {
      console.log(`      ${DIM}before: ${mask(a[k])}${RESET}`);
      console.log(`      ${DIM}after:  ${mask(b[k])}${RESET}`);
    }
  }
  console.log();
}

if (!missing.length && !added.length && !changed.length) {
  console.log(`${GREEN}✓ Files are identical (${same.length} keys)${RESET}\n`);
} else {
  console.log(`${DIM}─── ${same.length} unchanged · ${RED}${missing.length} missing${RESET}${DIM} · ${GREEN}${added.length} added${RESET}${DIM} · ${YELLOW}${changed.length} changed${RESET}${DIM} ───${RESET}\n`);
}
