#!/usr/bin/env node
'use strict';

// cert-peek: Check SSL certificate expiry and details for any domain.
// Zero runtime dependencies — uses Node's built-in tls module.

const tls = require('tls');
const { version } = require('./package.json');

const WARN_DAYS = 30;
const CRITICAL_DAYS = 14;

// ── Argument parsing ──────────────────────────────────────────────────────────

function parseArgs(argv) {
  const args = argv.slice(2);

  if (args.includes('--version') || args.includes('-v')) {
    console.log(version);
    process.exit(0);
  }

  if (args.includes('--help') || args.includes('-h') || args.length === 0) {
    console.log(`
cert-peek — Check SSL certificate expiry and details for any domain

Usage:
  cert-peek <domain> [domain2 ...]

Options:
  --help,    -h  Show this help message and exit
  --version, -v  Print the version and exit

Examples:
  cert-peek github.com
  cert-peek google.com cloudflare.com api.stripe.com
  npx cert-peek mysite.example.com

Exit codes:
  0  All certs are healthy (more than ${WARN_DAYS} days remaining)
  1  At least one cert is expiring soon (< ${WARN_DAYS} days) or already expired
  2  Connection or resolution error for at least one domain
`);
    process.exit(0);
  }

  // Strip flag-style args; keep bare domains
  return args.filter(a => !a.startsWith('-'));
}

// ── TLS certificate check ─────────────────────────────────────────────────────

function checkCert(domain) {
  return new Promise((resolve) => {
    const options = {
      servername: domain,
      timeout: 10000,
      rejectUnauthorized: false, // we want to inspect even expired/self-signed certs
    };

    const socket = tls.connect(443, domain, options, () => {
      const cert = socket.getPeerCertificate();
      socket.destroy();

      if (!cert || !cert.valid_to) {
        return resolve({ domain, error: 'No certificate returned by server' });
      }

      const now = Date.now();
      const expires = new Date(cert.valid_to);
      const validFrom = new Date(cert.valid_from);
      const daysLeft = Math.floor((expires.getTime() - now) / (1000 * 60 * 60 * 24));

      const subject =
        (cert.subject && cert.subject.CN) ? cert.subject.CN : domain;
      const issuer =
        (cert.issuer && cert.issuer.O)
          ? cert.issuer.O
          : (cert.issuer && cert.issuer.CN ? cert.issuer.CN : 'Unknown');

      resolve({ domain, subject, issuer, validFrom, expires, daysLeft, error: null });
    });

    socket.on('error', (err) => {
      socket.destroy();
      resolve({ domain, error: err.message });
    });

    socket.setTimeout(10000, () => {
      socket.destroy();
      resolve({ domain, error: 'Connection timed out after 10s' });
    });
  });
}

// ── Output helpers ────────────────────────────────────────────────────────────

function color(text, code) {
  // Only colorize when writing to a real terminal
  if (!process.stdout.isTTY) return text;
  return `\x1b[${code}m${text}\x1b[0m`;
}

function bold(text)   { return color(text, '1'); }
function red(text)    { return color(text, '31'); }
function yellow(text) { return color(text, '33'); }
function green(text)  { return color(text, '32'); }

function formatDate(d) {
  return d.toISOString().slice(0, 10);
}

function statusLine(daysLeft) {
  if (daysLeft < 0)              return red(`✗ EXPIRED ${Math.abs(daysLeft)} days ago`);
  if (daysLeft < CRITICAL_DAYS)  return red(`⚠ CRITICAL — expires in ${daysLeft} day${daysLeft === 1 ? '' : 's'}`);
  if (daysLeft < WARN_DAYS)      return yellow(`⚠ WARNING — expires in ${daysLeft} days`);
  return green(`✓ OK — ${daysLeft} days remaining`);
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  const domains = parseArgs(process.argv);

  if (domains.length === 0) {
    console.error('Error: provide at least one domain name.');
    console.error('Usage: cert-peek <domain> [domain2 ...]');
    process.exit(2);
  }

  let exitCode = 0;

  for (const domain of domains) {
    const result = await checkCert(domain);

    if (result.error) {
      console.log(`\n${bold('Domain:')}  ${domain}`);
      console.log(`${red('Error:')}    ${result.error}`);
      exitCode = Math.max(exitCode, 2);
      continue;
    }

    const { subject, issuer, validFrom, expires, daysLeft } = result;

    console.log(`\n${bold('Domain:')}      ${domain}`);
    if (subject !== domain) {
      console.log(`Subject:      ${subject}`);
    }
    console.log(`Issuer:       ${issuer}`);
    console.log(`Valid from:   ${formatDate(validFrom)}`);
    console.log(`Expires:      ${formatDate(expires)}`);
    console.log(`Status:       ${statusLine(daysLeft)}`);

    if (daysLeft < WARN_DAYS) {
      exitCode = Math.max(exitCode, 1);
    }
  }

  console.log('');
  process.exit(exitCode);
}

main().catch((err) => {
  console.error('Unexpected error:', err.message);
  process.exit(2);
});
