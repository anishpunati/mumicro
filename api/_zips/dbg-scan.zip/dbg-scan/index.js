#!/usr/bin/env node
/**
 * dbg-scan — scan source files for leftover console.log, debugger,
 * and TODO statements before you ship.
 *
 * Zero dependencies. Works as a one-off check or a CI gate.
 * Usage: npx dbg-scan [options] [directory]
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ─── ANSI colours ─────────────────────────────────────────────────────────────
const C = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  red:    '\x1b[31m',
  yellow: '\x1b[33m',
  cyan:   '\x1b[36m',
  grey:   '\x1b[90m',
  green:  '\x1b[32m',
};

const VERSION = '1.0.0';

// ─── CLI parsing ───────────────────────────────────────────────────────────────
const args = process.argv.slice(2);

if (args.includes('--version') || args.includes('-v')) {
  console.log(VERSION);
  process.exit(0);
}

if (args.includes('--help') || args.includes('-h')) {
  console.log(`
${C.bold}dbg-scan${C.reset} v${VERSION}

  Scan source files for leftover console.log, debugger, and TODO
  statements before you ship. Exits non-zero in --strict mode if
  any issues are found — drop it into a CI step or pre-commit hook.

${C.bold}Usage${C.reset}
  dbg-scan [options] [directory]

${C.bold}Options${C.reset}
  --dir <path>         Directory to scan (default: current working dir)
  --ext <exts>         Comma-separated file extensions to scan
                       (default: js,ts,jsx,tsx,mjs,cjs)
  --ignore <patterns>  Comma-separated directory names to skip
                       (default: node_modules,dist,build,.git,coverage)
  --no-todos           Skip TODO / FIXME / HACK / XXX comment checks
  --no-debugger        Skip 'debugger' statement checks
  --no-console         Skip console.* checks
  --strict             Exit with code 1 if any issues found (for CI)
  --json               Output results as JSON
  -v, --version        Print version
  -h, --help           Print this help

${C.bold}Examples${C.reset}
  dbg-scan                          # scan current directory
  dbg-scan ./src                    # scan ./src
  dbg-scan --strict                 # fail CI if anything found
  dbg-scan --no-todos --strict      # only check console + debugger in CI
  dbg-scan --ext js,ts              # only scan .js and .ts files
  dbg-scan --ignore vendor,tmp      # add extra ignore dirs
`);
  process.exit(0);
}

// ─── Parse options ─────────────────────────────────────────────────────────────
function getFlag(flag, defaultVal) {
  const i = args.indexOf(flag);
  if (i === -1) return defaultVal;
  return args[i + 1] || defaultVal;
}

const strict      = args.includes('--strict');
const jsonOutput  = args.includes('--json');
const noTodos     = args.includes('--no-todos');
const noDebugger  = args.includes('--no-debugger');
const noConsole   = args.includes('--no-console');

const extArg      = getFlag('--ext', 'js,ts,jsx,tsx,mjs,cjs');
const extensions  = new Set(extArg.split(',').map(e => '.' + e.trim().replace(/^\./, '')));

const defaultIgnore = ['node_modules', 'dist', 'build', '.git', 'coverage', '.next', '.nuxt'];
const ignoreArg   = getFlag('--ignore', '');
const ignoreDirs  = new Set([
  ...defaultIgnore,
  ...(ignoreArg ? ignoreArg.split(',').map(s => s.trim()) : []),
]);

// Positional arg for directory (last non-flag arg)
let scanDir = process.cwd();
for (const arg of args) {
  if (!arg.startsWith('-') && arg !== getFlag('--ext', null) && arg !== getFlag('--ignore', null) && arg !== getFlag('--dir', null)) {
    scanDir = path.resolve(arg);
  }
}
if (args.includes('--dir')) {
  scanDir = path.resolve(getFlag('--dir', '.'));
}

// ─── Patterns ──────────────────────────────────────────────────────────────────
const PATTERNS = [];

if (!noConsole) {
  PATTERNS.push({
    label: 'console',
    color: C.red,
    re: /\bconsole\.(log|debug|info|warn|error|trace|dir|table|time|timeEnd|assert|count)\s*\(/g,
  });
}

if (!noDebugger) {
  PATTERNS.push({
    label: 'debugger',
    color: C.red,
    re: /\bdebugger\b/g,
  });
}

if (!noTodos) {
  PATTERNS.push({
    label: 'todo',
    color: C.yellow,
    re: /\/\/\s*(TODO|FIXME|HACK|XXX)\b[^\n]*/gi,
  });
}

// ─── File walker ───────────────────────────────────────────────────────────────
function walkDir(dir, fileList = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return fileList;
  }
  for (const entry of entries) {
    if (ignoreDirs.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkDir(full, fileList);
    } else if (entry.isFile() && extensions.has(path.extname(entry.name))) {
      fileList.push(full);
    }
  }
  return fileList;
}

// ─── Scanner ───────────────────────────────────────────────────────────────────
function scanFile(filePath) {
  let src;
  try {
    src = fs.readFileSync(filePath, 'utf8');
  } catch {
    return [];
  }

  const hits  = [];
  const lines = src.split('\n');

  for (const { label, color, re } of PATTERNS) {
    re.lastIndex = 0;
    let match;
    while ((match = re.exec(src)) !== null) {
      // Calculate line number from character offset
      const lineNum = src.slice(0, match.index).split('\n').length;
      const lineText = lines[lineNum - 1] ? lines[lineNum - 1].trim() : '';
      hits.push({ label, color, lineNum, lineText, match: match[0] });
    }
  }

  return hits.sort((a, b) => a.lineNum - b.lineNum);
}

// ─── Main ──────────────────────────────────────────────────────────────────────
function main() {
  if (!fs.existsSync(scanDir)) {
    console.error(`${C.red}error:${C.reset} directory not found: ${scanDir}`);
    process.exit(2);
  }

  const files = walkDir(scanDir);

  const results   = [];
  let totalIssues = 0;

  const counts = { console: 0, debugger: 0, todo: 0 };

  for (const file of files) {
    const hits = scanFile(file);
    if (hits.length === 0) continue;

    const relPath = path.relative(process.cwd(), file);
    results.push({ file: relPath, hits });
    totalIssues += hits.length;
    for (const h of hits) counts[h.label] = (counts[h.label] || 0) + 1;
  }

  if (jsonOutput) {
    console.log(JSON.stringify({ scanned: files.length, total: totalIssues, counts, results }, null, 2));
    if (strict && totalIssues > 0) process.exit(1);
    return;
  }

  // ── Pretty output ────────────────────────────────────────────────────────────
  const rel = path.relative(process.cwd(), scanDir) || '.';
  console.log(`\n${C.bold}dbg-scan${C.reset} · scanning ${C.cyan}${rel}${C.reset}\n`);

  if (results.length === 0) {
    console.log(`${C.green}✓ No issues found${C.reset} — scanned ${files.length} file${files.length !== 1 ? 's' : ''}.\n`);
    return;
  }

  for (const { file, hits } of results) {
    console.log(`${C.bold}${file}${C.reset}`);
    for (const { color, label, lineNum, lineText } of hits) {
      const tag = `[${label}]`.padEnd(10);
      console.log(`  ${C.grey}${String(lineNum).padStart(4)}:${C.reset}  ${color}${tag}${C.reset}  ${lineText}`);
    }
    console.log('');
  }

  // Summary bar
  const parts = [];
  if (counts.console)  parts.push(`${C.red}${counts.console} console${C.reset}`);
  if (counts.debugger) parts.push(`${C.red}${counts.debugger} debugger${C.reset}`);
  if (counts.todo)     parts.push(`${C.yellow}${counts.todo} todo${C.reset}`);

  console.log(`${C.bold}Summary:${C.reset} ${parts.join('  ·  ')}  ${C.grey}(${files.length} files scanned, ${results.length} with issues)${C.reset}\n`);

  if (strict) {
    console.error(`${C.red}${C.bold}FAIL${C.reset} — ${totalIssues} issue${totalIssues !== 1 ? 's' : ''} found. Fix before shipping.\n`);
    process.exit(1);
  }
}

main();
