#!/usr/bin/env node
'use strict';

// cron-human — translate a 5-field cron expression into plain English
// and print the next 5 scheduled run times (UTC).
// Zero dependencies. Requires Node.js >= 14.

const VERSION = '1.0.0';

const DAYS   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const DOW_NAMES = [
  'Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'
];

// ── Field parser ─────────────────────────────────────────────────────────────
// Parses a single cron field (with *, ranges, lists, steps) into a sorted
// array of concrete integer values within [min, max].
function parseField(field, min, max) {
  const values = new Set();

  for (const part of field.split(',')) {
    if (part === '*') {
      for (let i = min; i <= max; i++) values.add(i);
    } else if (part.includes('/')) {
      const [range, stepStr] = part.split('/');
      const step = parseInt(stepStr, 10);
      if (isNaN(step) || step < 1) throw new Error(`Invalid step in field: "${part}"`);
      const [lo, hi] = range === '*'
        ? [min, max]
        : range.split('-').map(Number);
      for (let i = lo; i <= (hi || max); i += step) values.add(i);
    } else if (part.includes('-')) {
      const [lo, hi] = part.split('-').map(Number);
      if (isNaN(lo) || isNaN(hi)) throw new Error(`Invalid range in field: "${part}"`);
      for (let i = lo; i <= hi; i++) values.add(i);
    } else {
      const n = parseInt(part, 10);
      if (isNaN(n)) throw new Error(`Invalid value in field: "${part}"`);
      values.add(n);
    }
  }

  // Filter to valid range
  return [...values].filter(v => v >= min && v <= max).sort((a, b) => a - b);
}

// ── Next-N scheduler ─────────────────────────────────────────────────────────
// Walks forward minute-by-minute (with fast-forward shortcuts) to find the
// next `count` UTC timestamps that match the cron expression.
function nextN(expr, from, count = 5) {
  const parts = expr.trim().split(/\s+/);
  if (parts.length !== 5) {
    throw new Error(`Expected 5 fields (minute hour day month weekday), got ${parts.length}.`);
  }

  const [minF, hourF, domF, monF, dowF] = parts;

  const minutes = parseField(minF,  0, 59);
  const hours   = parseField(hourF, 0, 23);
  const doms    = parseField(domF,  1, 31);
  const months  = parseField(monF,  1, 12);
  // day-of-week 7 is an alias for 0 (Sunday) in vixie-cron
  const rawDows = parseField(dowF,  0, 7);
  const dows    = [...new Set(rawDows.map(d => d === 7 ? 0 : d))].sort((a, b) => a - b);

  const dowStar = dowF === '*';
  const domStar = domF === '*';

  if (minutes.length === 0) throw new Error('minute field produced no valid values.');
  if (hours.length   === 0) throw new Error('hour field produced no valid values.');
  if (doms.length    === 0) throw new Error('day-of-month field produced no valid values.');
  if (months.length  === 0) throw new Error('month field produced no valid values.');
  if (dows.length    === 0) throw new Error('day-of-week field produced no valid values.');

  const results = [];

  // Start 1 minute after 'from' (cron fires at the start of the matching minute)
  let t = new Date(from);
  t.setUTCSeconds(0, 0);
  t.setUTCMinutes(t.getUTCMinutes() + 1);

  // Safety limit: search at most 1 year into the future
  const limit = new Date(t.getTime() + 366 * 24 * 60 * 60 * 1000);

  while (results.length < count && t < limit) {
    const mon = t.getUTCMonth() + 1; // 1–12
    const dom = t.getUTCDate();      // 1–31
    const dow = t.getUTCDay();       // 0 (Sun) – 6 (Sat)
    const hr  = t.getUTCHours();
    const min = t.getUTCMinutes();

    // Month check — skip to 1st of next month if not valid
    if (!months.includes(mon)) {
      t.setUTCMonth(t.getUTCMonth() + 1, 1);
      t.setUTCHours(0, 0, 0, 0);
      continue;
    }

    // DOM / DOW matching follows vixie-cron semantics:
    //   - if both dom and dow are unrestricted (*), day always matches
    //   - if only one is restricted, that one must match
    //   - if both are restricted, EITHER match is sufficient
    const domOk = domStar || doms.includes(dom);
    const dowOk = dowStar || dows.includes(dow);
    const dayOk = (domStar && dowStar) ? true
                : (!domStar && !dowStar) ? (domOk || dowOk)
                : domStar ? dowOk
                : domOk;

    if (!dayOk) {
      // Advance to next calendar day
      t.setUTCDate(t.getUTCDate() + 1);
      t.setUTCHours(0, 0, 0, 0);
      continue;
    }

    // Hour check
    if (!hours.includes(hr)) {
      const nextHr = hours.find(h => h > hr);
      if (nextHr === undefined) {
        t.setUTCDate(t.getUTCDate() + 1);
        t.setUTCHours(0, 0, 0, 0);
      } else {
        t.setUTCHours(nextHr, 0, 0, 0);
      }
      continue;
    }

    // Minute check
    if (!minutes.includes(min)) {
      const nextMin = minutes.find(m => m > min);
      if (nextMin === undefined) {
        const nextHr = hours.find(h => h > hr);
        if (nextHr === undefined) {
          t.setUTCDate(t.getUTCDate() + 1);
          t.setUTCHours(0, 0, 0, 0);
        } else {
          t.setUTCHours(nextHr, 0, 0, 0);
        }
      } else {
        t.setUTCMinutes(nextMin);
      }
      continue;
    }

    // All fields matched — record this timestamp
    results.push(new Date(t));
    t.setUTCMinutes(t.getUTCMinutes() + 1);
  }

  return results;
}

// ── Human-readable description ───────────────────────────────────────────────
function describeField(f, names) {
  if (f === '*') return null; // "every X" — handled by caller context
  if (f.startsWith('*/')) return `every ${f.slice(2)}`;

  const parts = f.split(',');

  const fmt = v => {
    const n = parseInt(v, 10);
    return names ? (names[n] || v) : v;
  };

  if (parts.length === 1 && f.includes('-')) {
    const [a, b] = f.split('-');
    return `${fmt(a)} through ${fmt(b)}`;
  }

  if (parts.length > 1) {
    const items = parts.map(p => {
      if (p.includes('-')) {
        const [a, b] = p.split('-');
        return `${fmt(a)}–${fmt(b)}`;
      }
      return fmt(p);
    });
    if (items.length === 2) return `${items[0]} and ${items[1]}`;
    return items.slice(0, -1).join(', ') + ', and ' + items[items.length - 1];
  }

  return fmt(f);
}

function describe(parts) {
  const [minF, hourF, domF, monF, dowF] = parts;
  const clauses = [];

  // Time clause
  const minDesc  = describeField(minF, null);
  const hourDesc = describeField(hourF, null);

  if (minF === '*' && hourF === '*') {
    clauses.push('every minute');
  } else if (minF.startsWith('*/') && hourF === '*') {
    clauses.push(`every ${minF.slice(2)} minutes`);
  } else if (minF === '0' && hourF !== '*') {
    const h = hourDesc || 'every hour';
    clauses.push(`at ${typeof h === 'string' && !h.startsWith('every') ? h.padStart(2,'0').replace(/(\d+)/g, m => m.padStart(2,'0')) + ':00' : 'the top of the hour'}`);
    // Redo with proper formatting
    clauses.pop();
    if (hourF.includes(',')) {
      const hrs = hourF.split(',').map(h => h.padStart(2,'0') + ':00');
      clauses.push(`at ${hrs.slice(0,-1).join(', ')} and ${hrs[hrs.length-1]}`);
    } else if (hourF.includes('-')) {
      const [a, b] = hourF.split('-');
      clauses.push(`at the top of each hour from ${a.padStart(2,'0')}:00 to ${b.padStart(2,'0')}:00`);
    } else if (hourF.startsWith('*/')) {
      clauses.push(`every ${hourF.slice(2)} hours, at minute 0`);
    } else {
      clauses.push(`at ${hourF.padStart(2,'0')}:00`);
    }
  } else if (!minF.includes('*') && !minF.includes('/') && !hourF.includes('*') && !hourF.includes('/') &&
             !minF.includes(',') && !hourF.includes(',') && !minF.includes('-') && !hourF.includes('-')) {
    clauses.push(`at ${hourF.padStart(2,'0')}:${minF.padStart(2,'0')}`);
  } else {
    if (minF.startsWith('*/')) {
      clauses.push(`every ${minF.slice(2)} minutes`);
    } else if (minF !== '*') {
      clauses.push(`at minute ${minDesc || minF}`);
    }
    if (hourF !== '*') {
      clauses.push(`past ${hourDesc ? 'hour ' + hourDesc : 'every hour'}`);
    }
  }

  // Day-of-week
  const dowDesc = describeField(dowF, DOW_NAMES);
  if (dowDesc) clauses.push(dowDesc.startsWith('every') ? dowDesc : dowDesc);

  // Day-of-month
  const domDesc = describeField(domF, null);
  if (domDesc) clauses.push(`on day-of-month ${domDesc}`);

  // Month
  const monDesc = describeField(monF, MONTHS);
  if (monDesc) clauses.push(`in ${monDesc}`);

  return clauses.join(', ') || 'every minute';
}

// ── Relative time ────────────────────────────────────────────────────────────
function relativeTime(from, to) {
  const ms       = to - from;
  const totalMin = Math.floor(ms / 60000);
  const days     = Math.floor(totalMin / 1440);
  const hrs      = Math.floor((totalMin % 1440) / 60);
  const mins     = totalMin % 60;

  if (days > 0 && hrs > 0)  return `in ~${days}d ${hrs}h`;
  if (days > 0)              return `in ~${days}d`;
  if (hrs > 0 && mins > 0)  return `in ~${hrs}h ${mins}m`;
  if (hrs > 0)               return `in ~${hrs}h`;
  return `in ~${mins}m`;
}

// ── Main ─────────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);

if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
  console.log(`
cron-human v${VERSION}
Translate a 5-field cron expression into plain English and print the next
5 scheduled run times in UTC.

Usage:
  npx cron-human "<expression>"     Explain a cron expression
  npx cron-human --help             Show this help
  npx cron-human --version          Print version

Fields:  <minute> <hour> <day-of-month> <month> <day-of-week>

Supported syntax:
  *          every value
  */N        every N values (step)
  A-B        range from A to B (inclusive)
  A,B,C      list of specific values
  Combinations: e.g. 1-5,15,30-35

Day-of-week: 0=Sunday, 1=Monday … 6=Saturday (7=Sunday alias)

Examples:
  npx cron-human "0 3 * * *"          Every day at 03:00
  npx cron-human "*/15 * * * *"       Every 15 minutes
  npx cron-human "0 9 * * 1-5"        Weekdays at 09:00
  npx cron-human "30 18 1 * *"        1st of each month at 18:30
  npx cron-human "0 0 * * 0"          Every Sunday at midnight
  npx cron-human "0 8,17 * * 1-5"     Mon-Fri at 08:00 and 17:00
  `.trim());
  process.exit(0);
}

if (args[0] === '--version' || args[0] === '-v') {
  console.log(VERSION);
  process.exit(0);
}

const expr  = args.join(' ');
const parts = expr.trim().split(/\s+/);

if (parts.length !== 5) {
  console.error(`\nError: expected 5 cron fields, got ${parts.length}.`);
  console.error('Usage: npx cron-human "<minute> <hour> <day> <month> <weekday>"\n');
  process.exit(1);
}

let runs;
try {
  runs = nextN(expr, new Date(), 5);
} catch (err) {
  console.error(`\nError parsing expression: ${err.message}\n`);
  process.exit(1);
}

if (runs.length === 0) {
  console.error('\nError: expression never fires (checked 1 year ahead).\n');
  process.exit(1);
}

const meaning = describe(parts);
const now     = new Date();

console.log('');
console.log(`Expression:  ${expr}`);
console.log(`Meaning:     ${meaning}`);
console.log(`Timezone:    UTC`);
console.log('');
console.log('Next 5 runs:');

for (let i = 0; i < runs.length; i++) {
  const d   = runs[i];
  const yr  = d.getUTCFullYear();
  const mon = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  const hr  = String(d.getUTCHours()).padStart(2, '0');
  const min = String(d.getUTCMinutes()).padStart(2, '0');
  const dow = DAYS[d.getUTCDay()];
  const rel = relativeTime(now, d);
  console.log(`  ${i + 1}  ${yr}-${mon}-${day} ${dow}  ${hr}:${min} UTC  (${rel})`);
}

console.log('');
