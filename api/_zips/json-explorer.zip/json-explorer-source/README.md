# json-explorer

> Visualize any JSON file as an interactive collapsible tree in your browser — with search, path tracking, and copy-to-clipboard.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd json-explorer-source
npm install -g .
```

Verify the install worked:

```bash
json-explorer --version
```

---

## Usage

```
json-explorer v1.0.0

Visualize any JSON file as an interactive collapsible tree in your browser.

Usage:
  json-explorer <file.json> [options]
  cat file.json | json-explorer -

Options:
  --port <n>   Port to listen on (default: 7777)
  --help       Show this help
  --version    Print version

Examples:
  json-explorer response.json
  json-explorer api.json --port 8080
  curl https://api.github.com/users/octocat | json-explorer -
```

### Examples

Run against a local file:

```bash
json-explorer response.json
```

Pipe from curl without saving to disk:

```bash
curl https://api.github.com/repos/nodejs/node | json-explorer -
```

Use a different port if 7777 is taken:

```bash
json-explorer big-payload.json --port 8888
```

The tool opens your browser automatically, serves a polished interactive dashboard, and shuts down after 60 seconds or when you press Enter.

---

## Why this exists

**Problem:** Debugging large or deeply nested JSON responses means pasting into online formatters (a privacy risk), squinting at jq output, or writing throwaway scripts — there is no instant zero-setup local tool that gives you a rich interactive view.

**Solution:** json-explorer parses any JSON file and serves a polished local web dashboard with a collapsible tree, live search, node path display, and one-click value copy — all in under a second.

**How it works:** Pure Node.js: reads the file, spins up an http.createServer on port 7777, serves a single self-contained HTML page with all CSS and JS inlined, then opens the default browser; server auto-closes after 60 seconds or on Enter.

---

## Support

Questions or issues? Email anishpunati@gmail.com
