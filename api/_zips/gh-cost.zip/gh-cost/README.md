# gh-cost

**GitHub Actions cost estimator.** See which workflows are eating your CI budget — per-workflow breakdown, trend by day count, CSV export. No config files, no external dependencies.

```
$ npx gh-cost

GitHub Actions cost — acme/api
Last 30 days · ubuntu pricing ($0.008/min) · 312 runs

WORKFLOW              RUNS   AVG DUR   FAILURES   EST COST
──────────────────────────────────────────────────────────
CI / Full test suite   148    12m34s      3/148     $14.77
Deploy to staging       52     4m12s      0/52       $1.74
Lint & typecheck       112      1m8s      1/112      $0.97
──────────────────────────────────────────────────────────
TOTAL                  312                          $17.48

Note: Estimates only — wall time × ubuntu rate.
Exact billable minutes: github.com/acme/api/settings/billing
```

## Install

```bash
# Run once without installing
npx gh-cost

# Install globally
npm install -g gh-cost
```

## Usage

```bash
gh-cost                          # auto-detects repo from git remote
gh-cost owner/repo               # explicit repo
gh-cost owner/repo --days=7      # last 7 days (default: 30)
gh-cost owner/repo --os=macos    # use macOS pricing ($0.080/min)
gh-cost owner/repo --csv         # CSV output for spreadsheets
gh-cost owner/repo --csv > report.csv
```

## Auth

gh-cost tries these in order:

1. `--token=<token>` flag
2. `GITHUB_TOKEN` environment variable
3. `gh auth token` (if you have the [GitHub CLI](https://cli.github.com/) installed)

Public repos with public Actions logs need no token.

```bash
# Quickest auth if you have gh CLI:
gh auth login

# Or export a classic PAT with repo + workflow read scopes:
export GITHUB_TOKEN=ghp_...
```

## Runner pricing

GitHub's 2025 public rates (Linux runners included in free tier minutes):

| OS      | $/min  |
|---------|--------|
| ubuntu  | $0.008 |
| windows | $0.016 |
| macos   | $0.080 |

Pass `--os=windows` or `--os=macos` to use the correct rate for your runners.

## Accuracy note

Costs are **estimates** based on wall time (`run_started_at` → `updated_at`) rounded up per minute, then multiplied by the runner rate. GitHub charges billable minutes (which exclude time waiting in queue and may differ slightly). For exact numbers, visit your repo's billing page.

## Why this exists

GitHub's billing UI shows total minutes consumed — but not which workflow is responsible for most of your spend. This tool gives you the per-workflow breakdown in seconds, scriptable and CSV-friendly.

## Buy / Support

If gh-cost saved you money (ironic, we know), you can buy me a coffee — link coming once Stripe is configured.

## License

MIT © Anish Punati
