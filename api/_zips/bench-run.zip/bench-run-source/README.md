# bench-run

> Benchmark any shell command with min/max/avg/median timing over N runs

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd bench-run-source
npm install -g .
```

Verify the install worked:

```bash
bench-run --version
```

---

## Usage

```
bench-run v1.0.0

Benchmark any shell command with timing statistics.

Usage:
  bench-run <command> [options]

Options:
  -n, --runs <N>      Number of benchmark runs (default: 5)
  -w, --warmup <N>    Number of warmup runs before measuring (default: 0)
  -h, --help          Show this help message
  -v, --version       Show version

Examples:
  npx bench-run "npm test"
  npx bench-run "node build.js" --runs 10
  npx bench-run "curl -s https://example.com" --runs 3 --warmup 1
```

### Examples

**Benchmark your test suite over 5 runs:**
```bash
npx bench-run "npm test" --runs 5
```

**Benchmark a build script with 1 warmup run:**
```bash
npx bench-run "npm run build" --runs 10 --warmup 1
```

**Compare script speed without install:**
```bash
npx bench-run "node script-v1.js" --runs 3
npx bench-run "node script-v2.js" --runs 3
```

**Sample output:**
```
bench-run: npm test
Runs: 5

  Run 1/5... 4.231s
  Run 2/5... 4.108s
  Run 3/5... 4.189s
  Run 4/5... 4.212s
  Run 5/5... 4.095s

──────────────────────────────────────
  min     4.095s
  max     4.231s
  avg     4.167s
  median  4.189s
  stddev  0.055s
──────────────────────────────────────
```

---

## Why this exists

**Problem:** Developers have no easy way to benchmark how long a shell command takes across multiple runs — `time` only runs once and `hyperfine` requires a Rust installation most Node developers don't have.

**Solution:** bench-run runs any command N times and prints min, max, average, median, and stddev timing — zero dependencies, works instantly via `npx`.

**How it works:** Pure Node.js using `child_process.execSync` with `process.hrtime.bigint()` for nanosecond-precision timing; results are aggregated after all runs complete and printed as a summary table.

---

## Support

Questions or issues? Email anishpunati@gmail.com
