#!/usr/bin/env node
'use strict';

/**
 * dep-age
 * Show when each npm dependency was last published.
 * Helps identify abandoned or unmaintained packages in your project.
 *
 * Zero dependencies — uses only Node.js built-ins.
 */

const https = require('https');
const path  = require('path');
const fs    = require('fs');

const VERSION      = '1.0.0';
const STALE_MONTHS = 12;   // default threshold
const CONCURRENCY  = 8;    // parallel registry requests

// ─── CLI parsing ────────────────────────────────────────────────────────────

const args = process.argv.slice(2);

if (args.includes('--version') || args.includes('-v')) {
  console.log(VERSION);
  process.exit(0);
}

if (args.includes('--help') || args.includes('-h')) {
  console.log(`
dep-age v${VERSION}
Show when each npm dependency was last published.

Usage:
  dep-age [options] [path/to/package.json]

Options:
  --dev            Include devDependencies (default: false)
  --stale <n>      Flag packages not updated in N months (default: ${STALE_MONTHS})
  --json           Output results as JSON
  --version        Print version and exit
  --help           Show this help

Examples:
  dep-age                       # check ./package.json
  dep-age --dev                 # include devDependencies
  dep-age --stale 6             # flag anything older than 6 months
  dep-age /path/to/package.json # check a specific file
  dep-age --json                # machine-readable output
`);
  process.exit(0);
}

// ─── ANSI colours ───────────────────────────────────────────────────────────

const NO_COLOUR = !process.stdout.isTTY || process.env.NO_COLOR;
const C = {
  red:    s => NO_COLOUR ? s : `\x1b[31m${s}\x1b[0m`,
  yellow: s => NO_COLOUR ? s : `\x1b[33m${s}\x1b[0m`,
  green:  s => NO_COLOUR ? s : `\x1b[32m${s}\x1b[0m`,
  gray:   s => NO_COLOUR ? s : `\x1b[90m${s}\x1b[0m`,
  bold:   s => NO_COLOUR ? s : `\x1b[1m${s}\x1b[0m`,
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Months between a date string and now (rounded). */
function monthsAgo(dateStr) {
  if (!dateStr) return null;
  const diffMs = Date.now() - new Date(dateStr).getTime();
  return Math.round(diffMs / (1000 * 60 * 60 * 24 * 30.44));
}

/** YYYY-MM-DD */
function fmtDate(dateStr) {
  if (!dateStr) return 'unknown';
  return new Date(dateStr).toISOString().slice(0, 10);
}

/** Coloured "N months ago" string. */
function fmtAge(months, threshold) {
  if (months === null) return C.gray('unknown');
  const label = `${months} mo ago`;
  if (months >= threshold)            return C.red(label);
  if (months >= Math.floor(threshold * 0.6)) return C.yellow(label);
  return C.green(label);
}

// ─── npm registry query ──────────────────────────────────────────────────────

/**
 * Fetch the last-published date for a package from the npm registry.
 * Uses the abbreviated packument endpoint (much smaller response).
 */
function fetchLastPublished(name) {
  return new Promise(resolve => {
    const encoded  = name.startsWith('@')
      ? name.replace('/', '%2F')   // scoped package
      : name;
    const options = {
      hostname: 'registry.npmjs.org',
      path:     `/${encoded}`,
      method:   'GET',
      headers: {
        'Accept':          'application/vnd.npm.install-v1+json', // abbreviated
        'Accept-Encoding': 'identity',
      },
    };

    const req = https.request(options, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        try {
          const body   = Buffer.concat(chunks).toString();
          const json   = JSON.parse(body);
          const latest = json['dist-tags'] && json['dist-tags'].latest;
          // 'modified' in json.time is set on every publish
          const date   = (latest && json.time && json.time[latest])
                      || (json.time && json.time.modified)
                      || null;
          resolve({ name, date, latest, error: null });
        } catch (e) {
          resolve({ name, date: null, latest: null, error: 'parse error' });
        }
      });
    });

    req.setTimeout(12000, () => {
      req.destroy();
      resolve({ name, date: null, latest: null, error: 'timeout' });
    });
    req.on('error', e => resolve({ name, date: null, latest: null, error: e.message }));
    req.end();
  });
}

// ─── Main ────────────────────────────────────────────────────────────────────

async function main() {
  // Options
  const includeDev  = args.includes('--dev');
  const jsonOutput  = args.includes('--json');
  const staleIdx    = args.indexOf('--stale');
  const threshold   = staleIdx !== -1 && args[staleIdx + 1]
    ? (parseInt(args[staleIdx + 1], 10) || STALE_MONTHS)
    : STALE_MONTHS;

  // package.json path — last non-flag argument, or default
  let pkgFile = './package.json';
  for (const arg of args) {
    if (!arg.startsWith('-') && (arg.endsWith('.json') || arg.endsWith('package.json'))) {
      pkgFile = arg;
    }
  }

  const resolved = path.resolve(pkgFile);
  if (!fs.existsSync(resolved)) {
    console.error(C.red(`Error: ${resolved} not found.`));
    process.exit(1);
  }

  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(resolved, 'utf8'));
  } catch (e) {
    console.error(C.red(`Error reading ${resolved}: ${e.message}`));
    process.exit(1);
  }

  const deps = {
    ...(pkg.dependencies    || {}),
    ...(includeDev ? (pkg.devDependencies || {}) : {}),
  };

  const names = Object.keys(deps);
  if (names.length === 0) {
    console.log('No dependencies found in package.json.');
    process.exit(0);
  }

  if (!jsonOutput) {
    const devNote = includeDev ? ' (incl. devDeps)' : '';
    process.stdout.write(
      `\n${C.bold('dep-age')} — checking ${C.bold(String(names.length))} package${names.length !== 1 ? 's' : ''}${devNote}...\n\n`
    );
  }

  // Fetch in batches to respect concurrency limit
  const results = [];
  for (let i = 0; i < names.length; i += CONCURRENCY) {
    const batch = names.slice(i, i + CONCURRENCY);
    const res   = await Promise.all(batch.map(fetchLastPublished));
    results.push(...res);
    if (!jsonOutput && i + CONCURRENCY < names.length) {
      process.stdout.write(
        C.gray(`  fetched ${Math.min(i + CONCURRENCY, names.length)}/${names.length}...\r`)
      );
    }
  }

  // Sort oldest-first
  results.sort((a, b) => {
    const ma = monthsAgo(a.date);
    const mb = monthsAgo(b.date);
    if (ma === null && mb === null) return 0;
    if (ma === null) return  1;
    if (mb === null) return -1;
    return mb - ma;
  });

  // ── JSON output ──────────────────────────────────────────────────────────
  if (jsonOutput) {
    const out = results.map(r => ({
      name:          r.name,
      specifiedAs:   deps[r.name],
      latestVersion: r.latest,
      lastPublished: fmtDate(r.date),
      monthsAgo:     monthsAgo(r.date),
      stale:         (monthsAgo(r.date) ?? 0) >= threshold,
      error:         r.error,
    }));
    console.log(JSON.stringify(out, null, 2));
    process.exit(0);
  }

  // ── Table output ─────────────────────────────────────────────────────────
  const nameW = Math.min(40, Math.max(20, ...names.map(n => n.length))) + 2;
  const staleResults = results.filter(r => (monthsAgo(r.date) ?? 0) >= threshold);

  // Clear the progress line
  process.stdout.write('\x1b[2K\r');

  for (const r of results) {
    const mo  = monthsAgo(r.date);
    const row = [
      r.name.padEnd(nameW),
      fmtDate(r.date).padEnd(13),
      fmtAge(mo, threshold),
    ];
    if (r.error) row.push(C.gray(`(${r.error})`));
    console.log('  ' + row.join('  '));
  }

  console.log('');
  if (staleResults.length > 0) {
    console.log(
      C.red(C.bold(`⚠  ${staleResults.length} package${staleResults.length !== 1 ? 's' : ''} stale`)) +
      C.red(` — not updated in ${threshold}+ months.`)
    );
  } else {
    console.log(C.green(`✓  All packages updated within ${threshold} months.`));
  }
  console.log('');
}

main().catch(e => {
  console.error(C.red(`Fatal: ${e.message}`));
  process.exit(1);
});
