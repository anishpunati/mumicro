# json-check

> Recursively validate all JSON files in a directory and report syntax errors with file and line numbers.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd json-check-source
npm install -g .
```

Verify the install worked:

```bash
json-check --version
```

---

## Usage

```
json-check v1.0.0
Recursively validate all JSON files in a directory and report syntax errors.

Usage:
  npx json-check [directory] [options]

Arguments:
  directory          Directory to scan (default: current directory)

Options:
  --ext <ext>        File extension to check (default: .json)
  --ignore <name>    Directory name to skip (default: node_modules)
  --quiet            Only print failures, not passing files
  --help, -h         Show this help
  --version, -v      Show version

Examples:
  npx json-check .
  npx json-check ./src --ignore dist
  npx json-check . --quiet
  npx json-check . --ext .jsonc

Exit code: 0 if all files pass, 1 if any file has a syntax error.
```

### Examples

Scan the current project and see all results:

```bash
npx json-check .
# ✓ package.json
# ✓ tsconfig.json
# ✗ src/config.json — Unexpected token } in JSON at position 187 (line 12)
# ✗ data/users.json — Unexpected end of JSON input (line 45)
#
# 2 of 4 files failed.
```

Only show failures (useful in CI output):

```bash
npx json-check . --quiet
# ✗ src/config.json — Unexpected token } in JSON at position 187 (line 12)
#
# 1 of 6 files failed.
```

Check a specific subdirectory, skipping a build folder:

```bash
npx json-check ./src --ignore dist
```

Add to a pre-commit hook or CI step — exits non-zero on any failure:

```bash
npx json-check . --quiet || exit 1
```

---

## Why this exists

**Problem:** When a JSON config or data file has a syntax error, `JSON.parse` tells you it failed but not which file or line — you end up opening files one by one to find the typo. `jsonlint` requires installing dependencies and only takes a single file at a time.

**Solution:** `json-check` walks your project recursively, parses every `.json` file, and prints a pass/fail report with the exact file path and line number of each syntax error — exiting non-zero so it can gate CI or pre-commit hooks.

**How it works:** Pure Node.js, zero dependencies. Uses `fs.readdirSync` to walk directories, `JSON.parse` for validation, and parses V8's error message to extract the character position and convert it to a line number.

---

## Support

Questions or issues? Email anishpunati@gmail.com
