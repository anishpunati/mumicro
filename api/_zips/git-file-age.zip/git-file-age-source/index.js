#!/usr/bin/env node

'use strict';

const { execSync } = require('child_process');

const VERSION = '1.0.0';

// ─── Help ────────────────────────────────────────────────────────────────────

function printHelp() {
  process.stdout.write(`
git-file-age v${VERSION}

Shows how long ago each tracked file in your git repo was last committed.
Helps you spot stale or abandoned code without digging through git log.

Usage:
  git-file-age [options]

Options:
  --sort <field>   Sort by: age (default), name, author
  --stale <days>   Days threshold for "stale" label (default: 365)
  --aging <days>   Days threshold for "aging" label (default: 90)
  --limit <n>      Show only the N oldest files
  --no-color       Disable ANSI color output
  --version        Print version
  --help           Show this help

Examples:
  git-file-age
  git-file-age --sort name
  git-file-age --limit 20
  git-file-age --stale 180 --aging 60
  git-file-age --no-color | tee report.txt
\n`);
}

// ─── Utilities ───────────────────────────────────────────────────────────────

function daysSince(isoDate) {
  return Math.floor((Date.now() - Date.parse(isoDate)) / 86_400_000);
}

function pad(str, len) {
  const s = String(str == null ? '' : str);
  return s.length >= len ? s.slice(0, len - 1) + ' ' : s.padEnd(len);
}

function pickArg(args, flag, def) {
  const i = args.indexOf(flag);
  return i !== -1 && args[i + 1] !== undefined ? args[i + 1] : def;
}

// ─── Main ────────────────────────────────────────────────────────────────────

function main() {
  const args = process.argv.slice(2);

  if (args.includes('--help') || args.includes('-h')) { printHelp(); return; }
  if (args.includes('--version') || args.includes('-v')) { console.log(VERSION); return; }

  const noColor = args.includes('--no-color');
  const GREEN  = noColor ? '' : '\x1b[32m';
  const YELLOW = noColor ? '' : '\x1b[33m';
  const RED    = noColor ? '' : '\x1b[31m';
  const BOLD   = noColor ? '' : '\x1b[1m';
  const DIM    = noColor ? '' : '\x1b[2m';
  const RESET  = noColor ? '' : '\x1b[0m';

  const staleThreshold = parseInt(pickArg(args, '--stale', '365'), 10) || 365;
  const agingThreshold = parseInt(pickArg(args, '--aging', '90'),  10) || 90;
  const sortBy         = pickArg(args, '--sort', 'age');
  const limitRaw       = pickArg(args, '--limit', null);
  const limit          = limitRaw !== null ? (parseInt(limitRaw, 10) || 20) : Infinity;

  // ── Git sanity check ─────────────────────────────────────────────────────
  try {
    execSync('git rev-parse --git-dir', { stdio: 'ignore' });
  } catch (_) {
    process.stderr.write('Error: not a git repository. Run git-file-age from inside a git project.\n');
    process.exit(1);
  }

  // ── One-pass git log: newest commits first ────────────────────────────────
  // Sentinel format: "|~|<date>|<author>" so we can split on | safely.
  // --name-only emits the list of changed files after each commit block.
  // --no-merges skips merge commits (they don't represent real file changes).
  let log;
  try {
    log = execSync(
      'git log --no-merges --pretty=format:"|~|%ad|%an" --date=short --name-only',
      { encoding: 'utf8', maxBuffer: 128 * 1024 * 1024, stdio: ['ignore', 'pipe', 'ignore'] }
    );
  } catch (err) {
    process.stderr.write(`Error running git log: ${err.message}\n`);
    process.exit(1);
  }

  // ── Parse git log output ──────────────────────────────────────────────────
  // Iterate lines; sentinel lines update current commit metadata,
  // non-empty non-sentinel lines are file paths. First occurrence of
  // each file = most recent commit (since we're iterating newest-first).
  const fileMap = {}; // path → { date, author }
  let curDate = '';
  let curAuthor = '?';

  for (const raw of log.split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith('|~|')) {
      const parts = line.split('|');
      // ['', '~', date, author] — author may contain | so rejoin remainder
      curDate   = parts[2] || '';
      curAuthor = parts.slice(3).join('|').trim() || '?';
    } else {
      // It's a file path — only record the first (most recent) occurrence.
      if (!Object.prototype.hasOwnProperty.call(fileMap, line)) {
        fileMap[line] = { date: curDate, author: curAuthor };
      }
    }
  }

  // ── Get authoritative list of tracked files ───────────────────────────────
  let trackedFiles;
  try {
    trackedFiles = execSync('git ls-files', { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
      .split('\n').map(f => f.trim()).filter(Boolean);
  } catch (_) {
    // Fall back to whatever we parsed from the log
    trackedFiles = Object.keys(fileMap);
  }

  if (trackedFiles.length === 0) {
    console.log('No tracked files found in this repository.');
    return;
  }

  // ── Build result rows ─────────────────────────────────────────────────────
  const results = trackedFiles.map(file => {
    const info = fileMap[file];
    const days = info && info.date ? daysSince(info.date) : null;
    return { file, date: info ? info.date : null, days, author: info ? info.author : '?' };
  });

  // ── Sort ──────────────────────────────────────────────────────────────────
  const sorters = {
    age:    (a, b) => (b.days == null ? -1 : b.days) - (a.days == null ? -1 : a.days),
    name:   (a, b) => a.file.localeCompare(b.file),
    author: (a, b) => a.author.localeCompare(b.author),
  };
  results.sort(sorters[sortBy] || sorters.age);

  const display = isFinite(limit) ? results.slice(0, limit) : results;

  // ── Column widths ─────────────────────────────────────────────────────────
  const maxFileLen = Math.max(...display.map(r => r.file.length), 4);
  const W_FILE   = Math.min(54, maxFileLen + 2);
  const W_DATE   = 13;
  const W_AGE    = 8;
  const W_AUTHOR = 18;

  // ── Header ────────────────────────────────────────────────────────────────
  process.stderr.write(`Scanning git history... (${trackedFiles.length} files)\n\n`);

  process.stdout.write(
    BOLD +
    pad('File', W_FILE) +
    pad('Last Commit', W_DATE) +
    pad('Age', W_AGE) +
    'Author' +
    RESET + '\n'
  );
  process.stdout.write('─'.repeat(W_FILE + W_DATE + W_AGE + W_AUTHOR) + '\n');

  // ── Rows ──────────────────────────────────────────────────────────────────
  let nRecent = 0, nAging = 0, nStale = 0;

  for (const r of display) {
    if (r.days === null) {
      process.stdout.write(
        DIM +
        pad(r.file, W_FILE) +
        pad('unknown', W_DATE) +
        pad('?', W_AGE) +
        r.author +
        RESET + '\n'
      );
      continue;
    }

    let color, symbol;
    if (r.days < agingThreshold) {
      color = GREEN; symbol = '✓'; nRecent++;           // ✓
    } else if (r.days < staleThreshold) {
      color = YELLOW; symbol = '⚠'; nAging++;           // ⚠
    } else {
      color = RED; symbol = '🔴'; nStale++;        // 🔴
    }

    process.stdout.write(
      color +
      pad(r.file, W_FILE) +
      pad(r.date, W_DATE) +
      pad(`${r.days}d`, W_AGE) +
      pad(r.author, W_AUTHOR - 2) + ' ' + symbol +
      RESET + '\n'
    );
  }

  // ── Summary ───────────────────────────────────────────────────────────────
  process.stdout.write('\n');
  process.stdout.write(
    `${DIM}✓ recent (<${agingThreshold}d)   ⚠ aging (${agingThreshold}-${staleThreshold}d)   🔴 stale (>${staleThreshold}d)${RESET}\n`
  );

  const summaryParts = [];
  if (nRecent) summaryParts.push(`${GREEN}${nRecent} recent${RESET}`);
  if (nAging)  summaryParts.push(`${YELLOW}${nAging} aging${RESET}`);
  if (nStale)  summaryParts.push(`${RED}${nStale} stale${RESET}`);
  process.stdout.write(summaryParts.join(', ') + '\n\n');

  if (isFinite(limit) && limit < results.length) {
    process.stdout.write(
      `${DIM}Showing ${limit} of ${results.length} files. Use --limit to adjust.${RESET}\n`
    );
  }
}

try {
  main();
} catch (err) {
  process.stderr.write(`Unexpected error: ${err.message}\n`);
  process.exit(1);
}
