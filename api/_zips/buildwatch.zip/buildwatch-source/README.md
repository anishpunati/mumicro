# buildwatch

> Watch your build output directory and report file size changes on every rebuild.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd buildwatch-source
npm install -g .
```

Verify the install worked:

```bash
buildwatch --version
```

---

## Usage

```
buildwatch v1.0.0

Watch a build output directory and report file size changes on every rebuild.

Usage:
  buildwatch [directory] [options]

Arguments:
  directory              Directory to watch (default: ./dist)

Options:
  --threshold <bytes>    Only report files that changed by more than N bytes (default: 0)
  --help                 Show this help message
  --version              Show version number

Examples:
  buildwatch
  buildwatch ./build
  buildwatch ./dist --threshold 1024
```

### Examples

Watch the default `./dist` directory (run alongside your dev server):

```bash
buildwatch
```

Watch a custom output directory:

```bash
buildwatch ./build
```

Only report files that grew or shrank by more than 1 KB (useful for noisy builds with many small files):

```bash
buildwatch ./dist --threshold 1024
```

---

## Why this exists

**Problem:** During development, bundle size creep goes unnoticed — there is no fast way to see that a code change just added 50 KB to your dist folder until it surfaces in a PR review or a production performance regression.

**Solution:** `buildwatch` sits alongside your dev server and logs a colored size report every time files change, flagging growth and shrinkage with delta percentages so you catch regressions the moment they happen.

**How it works:** Pure Node.js using `fs.watch()` for directory monitoring and `fs.stat()` for file sizes, with 300ms debouncing to handle rapid build events. Prints ANSI-colored output showing per-file and total size deltas. Zero dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
