#!/usr/bin/env node
// stale-deps — find npm dependencies that haven't been published in a long time
// Zero runtime dependencies. Queries the public npm registry JSON API.

'use strict';

const https = require('https');
const path  = require('path');
const fs    = require('fs');

const VERSION      = '1.0.0';
const DEFAULT_DAYS = 365;
const BATCH_SIZE   = 10;  // concurrent registry requests

// ── CLI help ──────────────────────────────────────────────────────────────────
function usage() {
  console.log(`
stale-deps v${VERSION}

Scan your package.json dependencies for packages that haven't been updated
in a while — helping you spot potentially abandoned npm packages.

Usage:
  npx stale-deps [options]

Options:
  --days <n>      Flag packages not updated in N days (default: ${DEFAULT_DAYS})
  --include-dev   Also check devDependencies (default: production only)
  --json          Output results as JSON
  --help          Show this help
  --version       Show version

Examples:
  npx stale-deps
  npx stale-deps --days 180 --include-dev
  npx stale-deps --json > stale-report.json
`);
}

// ── npm registry fetch (no external deps) ────────────────────────────────────
function fetchLatest(pkg) {
  return new Promise((resolve, reject) => {
    const encoded = encodeURIComponent(pkg).replace(/^%40/, '@');
    const url = `https://registry.npmjs.org/${encoded}/latest`;
    https.get(url, { headers: { Accept: 'application/json' } }, (res) => {
      let body = '';
      res.on('data', chunk => (body += chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(body));
        } catch {
          reject(new Error(`Bad JSON from registry for "${pkg}"`));
        }
      });
    }).on('error', reject);
  });
}

// ── Formatting helpers ────────────────────────────────────────────────────────
function humanAge(days) {
  if (days >= 730) {
    const y = Math.floor(days / 365);
    const m = Math.floor((days % 365) / 30);
    return `${y}y ${m}m`;
  }
  const m = Math.floor(days / 30);
  const d = days % 30;
  return `${m}m ${d}d`;
}

// ── Main ──────────────────────────────────────────────────────────────────────
async function main() {
  const args = process.argv.slice(2);

  if (args.includes('--help') || args.includes('-h')) { usage(); process.exit(0); }
  if (args.includes('--version') || args.includes('-v')) { console.log(VERSION); process.exit(0); }

  const includeDev = args.includes('--include-dev');
  const jsonOutput = args.includes('--json');

  const daysIdx   = args.indexOf('--days');
  const threshold = daysIdx !== -1 && args[daysIdx + 1]
    ? parseInt(args[daysIdx + 1], 10)
    : DEFAULT_DAYS;

  if (isNaN(threshold) || threshold < 1) {
    console.error('Error: --days must be a positive integer');
    process.exit(1);
  }

  // Locate package.json in cwd
  const pkgPath = path.join(process.cwd(), 'package.json');
  if (!fs.existsSync(pkgPath)) {
    console.error(`Error: No package.json found in ${process.cwd()}`);
    process.exit(1);
  }

  let pkgJson;
  try {
    pkgJson = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  } catch {
    console.error('Error: Could not parse package.json — is it valid JSON?');
    process.exit(1);
  }

  const deps = { ...(pkgJson.dependencies || {}) };
  if (includeDev) Object.assign(deps, pkgJson.devDependencies || {});
  const names = Object.keys(deps);

  if (names.length === 0) {
    console.log('No dependencies found in package.json.');
    process.exit(0);
  }

  if (!jsonOutput) {
    process.stdout.write(
      `\nChecking ${names.length} package${names.length !== 1 ? 's' : ''} against npm registry (threshold: ${threshold} days)...\n\n`
    );
  }

  const now     = Date.now();
  const results = [];
  const errors  = [];

  // Batch concurrent requests to avoid overwhelming the registry
  for (let i = 0; i < names.length; i += BATCH_SIZE) {
    const batch   = names.slice(i, i + BATCH_SIZE);
    const settled = await Promise.allSettled(batch.map(n => fetchLatest(n)));

    settled.forEach((outcome, idx) => {
      const name = batch[idx];
      if (outcome.status === 'rejected') {
        errors.push({ name, error: outcome.reason.message });
        return;
      }

      const info = outcome.value;
      // The registry puts the publish time in _npmPublishTime on /latest
      const raw  = info._npmPublishTime || null;
      if (!raw) {
        errors.push({ name, error: 'Could not determine last publish date from registry' });
        return;
      }

      const daysSince    = Math.floor((now - new Date(raw).getTime()) / 86_400_000);
      const lastPublished = new Date(raw).toISOString().slice(0, 10);

      results.push({
        name,
        version: info.version || deps[name],
        daysSince,
        lastPublished,
        stale: daysSince >= threshold
      });
    });
  }

  const stale = results.filter(r => r.stale).sort((a, b) => b.daysSince - a.daysSince);
  const fresh = results.filter(r => !r.stale);

  // ── JSON mode ───────────────────────────────────────────────────────────────
  if (jsonOutput) {
    console.log(JSON.stringify({ threshold, checked: results.length, stale, fresh, errors }, null, 2));
    process.exit(stale.length > 0 ? 1 : 0);
  }

  // ── Human-readable mode ─────────────────────────────────────────────────────
  if (stale.length === 0) {
    console.log(`✓ All ${results.length} packages updated within the last ${threshold} days.\n`);
  } else {
    console.log(`⚠  ${stale.length} stale package${stale.length !== 1 ? 's' : ''} found (not updated in ${threshold}+ days):\n`);

    const nameW = Math.max(7, ...stale.map(r => r.name.length));
    const verW  = Math.max(7, ...stale.map(r => (r.version || '').length));

    console.log(`  ${'PACKAGE'.padEnd(nameW)}  ${'VERSION'.padEnd(verW)}  LAST UPDATED   DAYS AGO`);
    console.log(`  ${'─'.repeat(nameW)}  ${'─'.repeat(verW)}  ─────────────  ────────`);

    stale.forEach(r => {
      console.log(
        `  ${r.name.padEnd(nameW)}  ${(r.version || '?').padEnd(verW)}  ${r.lastPublished}   ${String(r.daysSince).padStart(5)}d  (${humanAge(r.daysSince)})`
      );
    });
    console.log();
  }

  if (fresh.length > 0) {
    console.log(`✓ ${fresh.length} package${fresh.length !== 1 ? 's' : ''} recently updated.\n`);
  }

  if (errors.length > 0) {
    console.log(`⚠  Could not check ${errors.length} package${errors.length !== 1 ? 's' : ''}:`);
    errors.forEach(e => console.log(`   - ${e.name}: ${e.error}`));
    console.log();
  }

  process.exit(stale.length > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Unexpected error:', err.message);
  process.exit(1);
});
