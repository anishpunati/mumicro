#!/usr/bin/env node
'use strict';

const VERSION = '1.0.0';

function printHelp() {
  console.log(`cronread v${VERSION}

Explain a cron expression and show the next N scheduled run times.

Usage:
  cronread "<expression>" [options]

Options:
  -n, --next <N>   Number of upcoming runs to show (default: 5, max: 20)
  -u, --utc        Show times in UTC instead of local time
  -h, --help       Show this help
  -v, --version    Show version

Examples:
  cronread "*/15 9-17 * * 1-5"        every 15 min, weekdays 9 to 5
  cronread "0 9 * * 1-5"              every weekday at 9am
  cronread "0 0 1 * *"                first day of every month
  cronread "*/5 * * * *" -n 10        every 5 min, next 10 runs
  cronread "0 9 * * 1-5" --utc        weekday 9am in UTC`);
}

// Parse a single cron field into a Set of valid integer values
function parseField(field, min, max) {
  const values = new Set();
  for (const part of field.split(',')) {
    if (part === '*') {
      for (let i = min; i <= max; i++) values.add(i);
      continue;
    }
    if (part.includes('/')) {
      const [rng, stepStr] = part.split('/');
      const step = parseInt(stepStr, 10);
      if (isNaN(step) || step < 1) throw new Error(`Invalid step value "${stepStr}"`);
      let lo = min, hi = max;
      if (rng !== '*') {
        if (rng.includes('-')) { [lo, hi] = rng.split('-').map(Number); }
        else { lo = parseInt(rng, 10); }
      }
      for (let i = lo; i <= hi; i += step) values.add(i);
    } else if (part.includes('-')) {
      const [a, b] = part.split('-').map(Number);
      for (let i = a; i <= b; i++) values.add(i);
    } else {
      const n = parseInt(part, 10);
      if (isNaN(n)) throw new Error(`Invalid value "${part}"`);
      values.add(n);
    }
  }
  return values;
}

const DAY_NAMES  = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const FULL_DAYS  = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const MON_NAMES  = [null,'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// Produce a plain-English summary of the 5-field cron expression
function humanize([minF, hrF, domF, monF, dowF]) {
  const parts = [];

  // --- time / frequency ---
  if (minF === '*' && hrF === '*') {
    parts.push('every minute');
  } else if (minF.startsWith('*/')) {
    const step = minF.slice(2);
    if (hrF === '*') {
      parts.push(`every ${step} minutes`);
    } else {
      const hrDesc = describeRange(hrF, FULL_DAYS, null);
      parts.push(`every ${step} minutes, between ${hrF.replace('-', ':00 and ')}:00`);
    }
  } else if (minF === '0') {
    if (hrF === '*') {
      parts.push('at the top of every hour');
    } else {
      parts.push(`at ${describeHours(hrF)}`);
    }
  } else {
    const minDesc = describeRange(minF, null, null);
    if (hrF === '*') {
      parts.push(`at minute ${minDesc} of every hour`);
    } else {
      parts.push(`at minute ${minDesc} of ${describeHours(hrF)}`);
    }
  }

  // --- date constraints ---
  if (domF !== '*') parts.push(`on day ${describeRange(domF, null, null)} of the month`);
  if (monF !== '*') parts.push(`in ${describeRange(monF, null, MON_NAMES)}`);
  if (dowF !== '*') parts.push(`on ${describeRange(dowF, null, FULL_DAYS)}`);

  return parts.join(', ');
}

function describeHours(field) {
  if (field.includes('-')) {
    const [a, b] = field.split('-').map(Number);
    return `${pad(a)}:00 to ${pad(b)}:00`;
  }
  if (field.includes('/')) {
    const [rng, step] = field.split('/');
    if (rng === '*') return `every ${step} hours`;
  }
  if (field.includes(',')) {
    return field.split(',').map(h => `${pad(parseInt(h,10))}:00`).join(', ');
  }
  return `${pad(parseInt(field,10))}:00`;
}

function describeRange(field, _unused, labelMap) {
  const parts = [];
  for (const part of field.split(',')) {
    if (part.includes('/')) {
      const [rng, stepStr] = part.split('/');
      const step = parseInt(stepStr, 10);
      if (rng === '*') { parts.push(`every ${step}`); continue; }
      if (rng.includes('-')) {
        const [a, b] = rng.split('-').map(Number);
        const la = labelMap ? (labelMap[a] || a) : a;
        const lb = labelMap ? (labelMap[b] || b) : b;
        parts.push(`every ${step} from ${la} to ${lb}`);
      } else {
        parts.push(`every ${step} starting at ${rng}`);
      }
    } else if (part.includes('-')) {
      const [a, b] = part.split('-').map(Number);
      const la = labelMap ? (labelMap[a] || a) : a;
      const lb = labelMap ? (labelMap[b] || b) : b;
      parts.push(`${la} to ${lb}`);
    } else {
      const n = parseInt(part, 10);
      parts.push(labelMap ? (labelMap[n] || n) : n);
    }
  }
  return parts.join(', ');
}

function pad(n) { return String(n).padStart(2, '0'); }

// Walk forward minute-by-minute to find the next `count` matching timestamps
function nextRuns(sets, from, count, useUtc) {
  const [minuteSet, hourSet, domSet, monthSet, dowSet] = sets;
  const runs = [];
  // Advance to the start of the next minute
  const d = new Date(Math.ceil((from.getTime() + 1) / 60000) * 60000);
  d.setSeconds(0, 0);
  const limit = d.getTime() + 366 * 24 * 60 * 60 * 1000;

  while (runs.length < count && d.getTime() < limit) {
    const mi = useUtc ? d.getUTCMinutes()   : d.getMinutes();
    const h  = useUtc ? d.getUTCHours()     : d.getHours();
    const dm = useUtc ? d.getUTCDate()      : d.getDate();
    const mo = useUtc ? d.getUTCMonth() + 1 : d.getMonth() + 1;
    const dw = useUtc ? d.getUTCDay()       : d.getDay();

    if (monthSet.has(mo) && domSet.has(dm) && dowSet.has(dw) && hourSet.has(h) && minuteSet.has(mi)) {
      runs.push(new Date(d));
    }
    d.setTime(d.getTime() + 60000);
  }
  return runs;
}

function fmtDate(d, useUtc) {
  const p = n => String(n).padStart(2, '0');
  if (useUtc) {
    return `${d.getUTCFullYear()}-${p(d.getUTCMonth()+1)}-${p(d.getUTCDate())} ${DAY_NAMES[d.getUTCDay()]} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())} UTC`;
  }
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${DAY_NAMES[d.getDay()]} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

// ── CLI entry point ──────────────────────────────────────────────────────────
const argv = process.argv.slice(2);

if (argv.length === 0 || argv.includes('-h') || argv.includes('--help')) {
  printHelp();
  process.exit(0);
}
if (argv.includes('-v') || argv.includes('--version')) {
  console.log(VERSION);
  process.exit(0);
}

let expr = null;
let count = 5;
let useUtc = false;

for (let i = 0; i < argv.length; i++) {
  if ((argv[i] === '-n' || argv[i] === '--next') && argv[i + 1]) {
    count = Math.min(20, Math.max(1, parseInt(argv[++i], 10) || 5));
  } else if (argv[i] === '-u' || argv[i] === '--utc') {
    useUtc = true;
  } else if (!expr) {
    expr = argv[i];
  }
}

if (!expr) {
  console.error('Error: no cron expression provided. Run cronread --help for usage.');
  process.exit(1);
}

const fields = expr.trim().split(/\s+/);
if (fields.length !== 5) {
  console.error(`Error: expected 5 space-separated fields, got ${fields.length}.`);
  console.error('Format: "minute hour day-of-month month day-of-week"');
  console.error('Example: "*/15 9-17 * * 1-5"');
  process.exit(1);
}

const ranges = [[0, 59], [0, 23], [1, 31], [1, 12], [0, 6]];
let sets;
try {
  sets = fields.map((f, i) => parseField(f, ranges[i][0], ranges[i][1]));
} catch (e) {
  console.error(`Parse error: ${e.message}`);
  process.exit(1);
}

const schedule = humanize(fields);

console.log('');
console.log(`  Pattern : ${expr}`);
console.log(`  Schedule: ${schedule}`);
console.log('');

const runs = nextRuns(sets, new Date(), count, useUtc);
if (runs.length === 0) {
  console.log('  No upcoming runs found within the next year — check your expression.');
} else {
  const tz = useUtc ? 'UTC' : 'local time';
  console.log(`  Next ${runs.length} run${runs.length !== 1 ? 's' : ''} (${tz}):`);
  runs.forEach((d, i) => console.log(`    ${i + 1}. ${fmtDate(d, useUtc)}`));
}
console.log('');
