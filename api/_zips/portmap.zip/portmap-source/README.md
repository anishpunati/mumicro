# portmap

> Scan all listening ports on localhost and visualise them in a browser dashboard with process names and PIDs

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd portmap-source
npm install -g .
```

Verify the install worked:

```bash
portmap --version
```

---

## Usage

```
portmap v1.0.0 — visualise all listening ports in a browser dashboard

USAGE
  portmap [options]

OPTIONS
  --port <n>     Port to run the dashboard server on (default: 7777)
  --no-open      Print URL but do not auto-open the browser
  --help         Show this help and exit
  --version      Print version and exit

EXAMPLES
  portmap                   scan ports and open browser dashboard
  portmap --no-open         start server, print URL, skip browser open
  portmap --port 9000       serve dashboard on port 9000
```

### Examples

Scan and open the dashboard in one command:

```bash
portmap
# portmap dashboard → http://127.0.0.1:7777
# Press Enter to stop.
```

Start the server without auto-opening the browser (useful in CI or remote sessions):

```bash
portmap --no-open
# portmap dashboard → http://127.0.0.1:7777
# Press Enter to stop.
```

Run on a specific port (if 7777 is already taken):

```bash
portmap --port 9000
# portmap dashboard → http://127.0.0.1:9000
# Press Enter to stop.
```

---

## Why this exists

**Problem:** Developers running multiple local services — API servers, databases, webpack dev servers — frequently need to know what is listening on which port. The standard fix is running `lsof -iTCP -sTCP:LISTEN -n -P` or `netstat -an`, both of which produce walls of unformatted text that are slow to read and impossible to scan at a glance.

**Solution:** portmap runs a single system command, parses the output, and opens a clean browser dashboard showing every listening port with its process name and PID — refreshable on demand and auto-closing after 60 seconds of inactivity.

**How it works:** Uses Node.js `child_process.execSync` to run `lsof -iTCP -sTCP:LISTEN -n -P` (macOS/Linux) or `netstat -ano` (Windows), parses port/PID/process-name triples with a regex, then serves a self-contained HTML dashboard via the built-in `http` module and opens the browser automatically via the platform's default open command.

---

## Support

Questions or issues? Email anishpunati@gmail.com
