# cron-human

> Translate a cron expression into plain English and print the next 5 scheduled run times

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd cron-human-source
npm install -g .
```

Verify the install worked:

```bash
cron-human --version
```

---

## Usage

```
cron-human v1.0.0
Translate a 5-field cron expression into plain English and print the next
5 scheduled run times in UTC.

Usage:
  npx cron-human "<expression>"     Explain a cron expression
  npx cron-human --help             Show this help
  npx cron-human --version          Print version

Fields:  <minute> <hour> <day-of-month> <month> <day-of-week>

Supported syntax:
  *          every value
  */N        every N values (step)
  A-B        range from A to B (inclusive)
  A,B,C      list of specific values
  Combinations: e.g. 1-5,15,30-35

Day-of-week: 0=Sunday, 1=Monday … 6=Saturday (7=Sunday alias)

Examples:
  npx cron-human "0 3 * * *"          Every day at 03:00
  npx cron-human "*/15 * * * *"       Every 15 minutes
  npx cron-human "0 9 * * 1-5"        Weekdays at 09:00
  npx cron-human "30 18 1 * *"        1st of each month at 18:30
  npx cron-human "0 0 * * 0"          Every Sunday at midnight
  npx cron-human "0 8,17 * * 1-5"     Mon-Fri at 08:00 and 17:00
```

### Examples

Decode a job that runs on weekday mornings:

```bash
$ cron-human "0 9 * * 1-5"

Expression:  0 9 * * 1-5
Meaning:     at 09:00, Monday through Friday
Timezone:    UTC

Next 5 runs:
  1  2026-05-18 Mon  09:00 UTC  (in ~23h)
  2  2026-05-19 Tue  09:00 UTC  (in ~1d 23h)
  3  2026-05-20 Wed  09:00 UTC  (in ~2d 23h)
  4  2026-05-21 Thu  09:00 UTC  (in ~3d 23h)
  5  2026-05-22 Fri  09:00 UTC  (in ~4d 23h)
```

Verify a nightly backup job fires at the right time:

```bash
$ cron-human "30 2 * * *"

Expression:  30 2 * * *
Meaning:     at 02:30
Timezone:    UTC

Next 5 runs:
  1  2026-05-17 Sun  02:30 UTC  (in ~16h)
  2  2026-05-18 Mon  02:30 UTC  (in ~1d 16h)
  3  2026-05-19 Tue  02:30 UTC  (in ~2d 16h)
  4  2026-05-20 Wed  02:30 UTC  (in ~3d 16h)
  5  2026-05-21 Thu  02:30 UTC  (in ~4d 16h)
```

Check a heartbeat that runs every 15 minutes:

```bash
$ cron-human "*/15 * * * *"

Expression:  */15 * * * *
Meaning:     every 15 minutes
Timezone:    UTC

Next 5 runs:
  1  2026-05-16 Sat  10:15 UTC  (in ~7m)
  2  2026-05-16 Sat  10:30 UTC  (in ~22m)
  3  2026-05-16 Sat  10:45 UTC  (in ~37m)
  4  2026-05-16 Sat  11:00 UTC  (in ~52m)
  5  2026-05-16 Sat  11:15 UTC  (in ~1h 7m)
```

---

## Why this exists

**Problem:** Developers and DevOps engineers frequently copy-paste cron expressions from docs or colleagues without a quick way to verify what they actually do — you have to either memorize the 5-field format or open a third-party web tool.

**Solution:** cron-human takes any standard 5-field cron expression and instantly prints a plain-English description plus the next 5 run times so you can verify correctness without leaving the terminal.

**How it works:** Pure Node.js cron parser — splits the expression into 5 fields (minute, hour, day-of-month, month, day-of-week), evaluates each field including ranges, lists, and steps, then walks forward from the current UTC time to find the next 5 matching timestamps. No network calls, no dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
