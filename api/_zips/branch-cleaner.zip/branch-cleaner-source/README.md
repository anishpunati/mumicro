# branch-cleaner

> Interactively browse and delete stale git branches with arrow keys — see merge status, age, and last commit at a glance.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd branch-cleaner-source
npm install -g .
```

Verify the install worked:

```bash
branch-cleaner --version
```

---

## Usage

```
branch-cleaner v1.0.0

Interactively browse and delete stale git branches.

USAGE
  branch-cleaner [options]

OPTIONS
  --help, -h      Show this help message
  --version, -v   Print version number

KEYS
  ↑ / k           Move up
  ↓ / j           Move down
  d               Toggle branch for deletion
  Enter           Delete all marked branches
  r               Refresh branch list
  q / Ctrl+C      Quit without deleting

COLUMNS
  BRANCH          Local branch name (* = current)
  AGE             Days since last commit on that branch
  MERGED          Whether the branch is merged into current HEAD
  LAST COMMIT     Most recent commit message (truncated)

NOTES
  - The current branch is never deletable.
  - Merged branches are deleted with 'git branch -d' (safe).
  - Unmerged branches are deleted with 'git branch -D' (force) — you are warned.
  - Run from anywhere inside a git repository.
```

### Examples

**Browse branches in any git repo:**

```bash
cd ~/projects/my-app
branch-cleaner
```

**What you see:**

```
  branch-cleaner  ↑↓ navigate · d mark · Enter delete · r refresh · q quit
  ────────────────────────────────────────────────────────────────
  BRANCH                    AGE  MERGED  LAST COMMIT
  ────────────────────────────────────────────────────────────────
▶ feat/auth-refactor         42d    yes  add JWT refresh logic
  fix/login-redirect         38d    yes  redirect after oauth callback
  feat/payment-v2            15d     no  WIP: stripe webhook handler
  chore/update-deps           8d    yes  bump eslint to 8.57
  main              (current) 0d    yes  release v2.4.1
  ────────────────────────────────────────────────────────────────
  No branches marked. Press d to mark the highlighted branch.
```

**Mark merged branches for deletion (press `d` on each), then press `Enter`:**

```
  2 branches marked for deletion. Press Enter to confirm.
  → Deleted 2 branches.
```

**Non-interactive output (pipe-friendly):**

```bash
branch-cleaner | grep merged
# feat/auth-refactor (merged) [42d ago] — add JWT refresh logic
# fix/login-redirect (merged) [38d ago] — redirect after oauth callback
```

---

## Why this exists

**Problem:** Developers accumulate dozens of stale local git branches and cleaning them up requires manually running `git log --merged`, inspecting each branch, and issuing `git branch -d` repeatedly — there is no fast interactive way to review and bulk-delete branches in one pass.

**Solution:** branch-cleaner launches a full-screen TUI showing every local branch with its age, merge status, and last commit message; press `d` to mark branches for deletion, `Enter` to delete them all, no flags or manual git commands required.

**How it works:** Pure Node.js using `child_process.execSync` to call `git branch -v --sort=-committerdate` and `git branch --merged`, then renders a live arrow-key-navigable list with ANSI escape codes and raw terminal mode — zero dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
