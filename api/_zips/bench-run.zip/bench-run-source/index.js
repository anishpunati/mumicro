#!/usr/bin/env node
'use strict';

/**
 * bench-run — Benchmark any shell command with timing statistics.
 * Zero dependencies. Uses only Node.js built-ins.
 */

const { execSync } = require('child_process');

const VERSION = '1.0.0';

function parseArgs(argv) {
  const args = argv.slice(2);
  const opts = { runs: 5, warmup: 0 };
  let command = null;

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--help' || a === '-h') { opts.help = true; }
    else if (a === '--version' || a === '-v') { opts.version = true; }
    else if ((a === '--runs' || a === '-n') && args[i + 1]) { opts.runs = parseInt(args[++i], 10); }
    else if ((a === '--warmup' || a === '-w') && args[i + 1]) { opts.warmup = parseInt(args[++i], 10); }
    else if (!command) { command = a; }
  }

  opts.command = command;
  return opts;
}

function printHelp() {
  console.log([
    '',
    'bench-run v' + VERSION,
    '',
    'Benchmark any shell command with timing statistics.',
    '',
    'Usage:',
    '  bench-run <command> [options]',
    '',
    'Options:',
    '  -n, --runs <N>      Number of benchmark runs (default: 5)',
    '  -w, --warmup <N>    Number of warmup runs before measuring (default: 0)',
    '  -h, --help          Show this help message',
    '  -v, --version       Show version',
    '',
    'Examples:',
    '  npx bench-run "npm test"',
    '  npx bench-run "node build.js" --runs 10',
    '  npx bench-run "curl -s https://example.com" --runs 3 --warmup 1',
    '',
  ].join('\n'));
}

function runOnce(command) {
  const start = process.hrtime.bigint();
  try {
    execSync(command, { stdio: 'ignore', shell: true });
    const end = process.hrtime.bigint();
    return { ok: true, ms: Number(end - start) / 1e6 };
  } catch (err) {
    const end = process.hrtime.bigint();
    return { ok: false, ms: Number(end - start) / 1e6, code: err.status };
  }
}

function formatMs(ms) {
  if (ms >= 60000) return (ms / 60000).toFixed(2) + 'm';
  if (ms >= 1000)  return (ms / 1000).toFixed(3) + 's';
  return ms.toFixed(1) + 'ms';
}

function median(arr) {
  const sorted = arr.slice().sort(function(a, b) { return a - b; });
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function stddev(arr, avg) {
  return Math.sqrt(arr.map(function(t) { return Math.pow(t - avg, 2); }).reduce(function(a, b) { return a + b; }, 0) / arr.length);
}

function main() {
  const opts = parseArgs(process.argv);

  if (opts.version) {
    console.log(VERSION);
    process.exit(0);
  }

  if (opts.help || !opts.command) {
    printHelp();
    process.exit(opts.help ? 0 : 1);
  }

  if (isNaN(opts.runs) || opts.runs < 1) {
    console.error('Error: --runs must be a positive integer');
    process.exit(1);
  }

  if (isNaN(opts.warmup) || opts.warmup < 0) {
    console.error('Error: --warmup must be a non-negative integer');
    process.exit(1);
  }

  console.log('\nbench-run: ' + opts.command);
  console.log('Runs: ' + opts.runs + (opts.warmup > 0 ? ' (+' + opts.warmup + ' warmup)' : '') + '\n');

  // Warmup runs (results discarded)
  if (opts.warmup > 0) {
    process.stdout.write('Warming up... ');
    for (let i = 0; i < opts.warmup; i++) {
      runOnce(opts.command);
    }
    console.log('done\n');
  }

  const times = [];
  const failedRuns = [];

  for (let i = 0; i < opts.runs; i++) {
    process.stdout.write('  Run ' + (i + 1) + '/' + opts.runs + '... ');
    const result = runOnce(opts.command);
    times.push(result.ms);
    if (!result.ok) failedRuns.push(i + 1);
    const suffix = result.ok ? '' : ' [exit ' + result.code + ']';
    console.log(formatMs(result.ms) + suffix);
  }

  // Compute stats over successful runs; fall back to all runs if all failed
  const goodTimes = times.filter(function(_, i) { return !failedRuns.includes(i + 1); });
  const stat = goodTimes.length > 0 ? goodTimes : times;

  const minT  = Math.min.apply(null, stat);
  const maxT  = Math.max.apply(null, stat);
  const avgT  = stat.reduce(function(a, b) { return a + b; }, 0) / stat.length;
  const medT  = median(stat);
  const sdT   = stddev(stat, avgT);

  console.log('\n' + '─'.repeat(38));
  console.log('  min     ' + formatMs(minT));
  console.log('  max     ' + formatMs(maxT));
  console.log('  avg     ' + formatMs(avgT));
  console.log('  median  ' + formatMs(medT));
  console.log('  stddev  ' + formatMs(sdT));
  if (failedRuns.length > 0) {
    console.log('  failed  ' + failedRuns.length + '/' + opts.runs + ' runs (non-zero exit)');
  }
  console.log('─'.repeat(38) + '\n');
}

main();
