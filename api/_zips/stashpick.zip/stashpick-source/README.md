# stashpick

> Interactive arrow-key git stash browser — preview diffs and apply, pop, or drop stashes without memorizing stash IDs

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd stashpick-source
npm install -g .
```

Verify the install worked:

```bash
stashpick --version
```

---

## Usage

```
stashpick v1.0.0

  Interactive git stash browser — arrow-key through stashes,
  preview diffs, and apply / pop / drop with a single keypress.

USAGE
  npx stashpick

KEYS
  ↑ / k     move up
  ↓ / j     move down
  a         apply selected stash (keeps it in the list)
  p         pop selected stash (apply + remove from list)
  d         drop selected stash (permanently delete)
  q / Esc   quit without changing anything

REQUIREMENTS
  Must be run inside a git repository.
  Requires git 2.x+.
```

### Examples

Run from any git repository with stashes:

```bash
# Launch the interactive browser
npx stashpick
```

Navigate with arrow keys (or j/k). The right pane shows a live diff preview of
the selected stash. Press `a` to apply it without removing it from the list,
`p` to pop it (apply and remove), or `d` to permanently drop it.

```bash
# Just check the version
stashpick --version
# 1.0.0

# Print help and exit
stashpick --help
```

---

## Why this exists

**Problem:** `git stash list` shows cryptic IDs and short commit messages — finding the right stash requires running `git stash show -p stash@{N}` repeatedly for each candidate until you find what you need.

**Solution:** stashpick renders a full-screen TUI with all stashes listed on the left and a live diff preview on the right. Arrow-key navigation and single-key actions (apply / pop / drop) mean you never need to remember a stash ID again.

**How it works:** Pure Node.js — shells out to `git stash list` and `git stash show -p` using the built-in `child_process` module, caches diff output to avoid redundant git calls, and renders a two-pane terminal UI using raw ANSI escape codes and stdin raw mode. Zero npm dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
