# cronread

> Explain a cron expression in plain English and show the next N scheduled run times.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd cronread-source
npm install -g .
```

Verify the install worked:

```bash
cronread --version
```

---

## Usage

```
cronread v1.0.0

Explain a cron expression and show the next N scheduled run times.

Usage:
  cronread "<expression>" [options]

Options:
  -n, --next <N>   Number of upcoming runs to show (default: 5, max: 20)
  -u, --utc        Show times in UTC instead of local time
  -h, --help       Show this help
  -v, --version    Show version

Examples:
  cronread "*/15 9-17 * * 1-5"        every 15 min, weekdays 9 to 5
  cronread "0 9 * * 1-5"              every weekday at 9am
  cronread "0 0 1 * *"                first day of every month
  cronread "*/5 * * * *" -n 10        every 5 min, next 10 runs
  cronread "0 9 * * 1-5" --utc        weekday 9am in UTC
```

### Examples

Explain a standard business-hours schedule and show the next 5 runs:

```bash
$ cronread "*/15 9-17 * * 1-5"

  Pattern : */15 9-17 * * 1-5
  Schedule: every 15 minutes, between 9:00 and 17:00, on Monday to Friday

  Next 5 runs (local time):
    1. 2026-05-12 Tue 09:15
    2. 2026-05-12 Tue 09:30
    3. 2026-05-12 Tue 09:45
    4. 2026-05-12 Tue 10:00
    5. 2026-05-12 Tue 10:15
```

Show the next 10 runs of a "every 5 minutes" schedule:

```bash
$ cronread "*/5 * * * *" -n 10

  Pattern : */5 * * * *
  Schedule: every 5 minutes

  Next 10 runs (local time):
    1. 2026-05-12 Tue 09:20
    2. 2026-05-12 Tue 09:25
    ...
```

Check a monthly billing job in UTC:

```bash
$ cronread "0 0 1 * *" --utc

  Pattern : 0 0 1 * *
  Schedule: at 00:00, on day 1 of the month

  Next 5 runs (UTC):
    1. 2026-06-01 Mon 00:00 UTC
    2. 2026-07-01 Wed 00:00 UTC
    3. 2026-08-01 Sat 00:00 UTC
    4. 2026-09-01 Tue 00:00 UTC
    5. 2026-10-01 Thu 00:00 UTC
```

---

## Why this exists

**Problem:** Developers routinely have to leave the terminal and visit crontab.guru or similar websites to verify what a cron expression actually schedules — there is no zero-dependency CLI tool that explains cron syntax and shows upcoming run times inline.

**Solution:** cronread parses any standard 5-field cron expression, prints a plain-English schedule description, and lists the next N trigger times in local or UTC — all in under 50ms with zero dependencies.

**How it works:** Pure Node.js with no dependencies: parses each field (ranges, steps, lists, wildcards) into value sets, walks forward minute by minute from the current time to find the next N matching timestamps, and renders the results as a clean terminal output.

---

## Support

Questions or issues? Email anishpunati@gmail.com
