# port-peek

> Interactive TUI for browsing all listening ports and killing the process behind any port with a keypress

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd port-peek-source
npm install -g .
```

Verify the install worked:

```bash
port-peek --version
```

---

## Usage

```
port-peek v1.0.0

  Interactive TUI for browsing all listening ports and killing the
  process behind any port with a single keypress.

Usage
  port-peek

Keys
  ↑ / k     move up
  ↓ / j     move down
  Enter     kill selected process (SIGKILL)
  r         refresh port list
  q / ^C    quit

Notes
  Requires lsof (macOS) or ss/netstat (Linux).
  Some system processes may require sudo to kill.
  Zero dependencies — pure Node.js built-ins only.
```

### Examples

Launch the interactive port browser:

```bash
port-peek
```

If you need to kill a privileged process:

```bash
sudo port-peek
```

Refresh the list without quitting (press `r` inside the TUI — useful after starting a new dev server):

```
port-peek v1.0.0 — Listening ports

  PORT    PID       PROCESS
  ────────────────────────────────────────────────────────
  3000    91234     node
▶ 5432    823       postgres
  8080    45612     python3
  8888    45990     node
  ────────────────────────────────────────────────────────
  ↑↓ navigate  Enter kill  r refresh  q quit
```

---

## Why this exists

**Problem:** When a port is already in use, developers have to chain together `lsof`, `grep`, and `kill` commands to find and stop the offending process — there is no interactive way to scan all listening ports and act on them in one place.

**Solution:** port-peek renders a live table of all listening ports, their PIDs, and process names; pressing Enter on any row sends SIGKILL to that process immediately.

**How it works:** Pure Node.js using `child_process.execSync` to run `lsof -iTCP -sTCP:LISTEN` on macOS (with `ss`/`netstat` fallback on Linux), then renders a full-screen ANSI TUI with raw mode stdin for arrow-key navigation and Enter-to-kill. No dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
