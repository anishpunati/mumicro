#!/usr/bin/env node

'use strict';

const VERSION = '1.0.0';
const args = process.argv.slice(2);

if (args.includes('--version') || args.includes('-v')) {
  process.stdout.write(VERSION + '\n');
  process.exit(0);
}

if (args.includes('--help') || args.includes('-h')) {
  process.stdout.write(`
croncheck v${VERSION}
Parse and preview cron expressions interactively.

Usage:
  croncheck [expression]

Options:
  --help, -h     Show this help
  --version, -v  Show version

Examples:
  croncheck                    # Launch interactive TUI
  croncheck "0 */4 * * *"      # Preview a specific expression and exit
  croncheck "30 9 * * 1-5"     # Mon-Fri at 9:30am
  croncheck "0 0 1 * *"        # First day of every month

Cron format:
  ┌─────── minute (0-59)
  │ ┌───── hour (0-23)
  │ │ ┌─── day of month (1-31)
  │ │ │ ┌─ month (1-12)
  │ │ │ │ ┌ day of week (0-6, Sun=0)
  │ │ │ │ │
  * * * * *
`);
  process.exit(0);
}

// ─── Cron parser ─────────────────────────────────────────────────────────────

const FIELD_RANGES = [
  { name: 'minute',   min: 0, max: 59 },
  { name: 'hour',     min: 0, max: 23 },
  { name: 'day',      min: 1, max: 31 },
  { name: 'month',    min: 1, max: 12 },
  { name: 'weekday',  min: 0, max: 6  },
];

function parseField(token, min, max) {
  const values = new Set();
  const parts = token.split(',');
  for (const part of parts) {
    if (part === '*') {
      for (let i = min; i <= max; i++) values.add(i);
    } else if (part.includes('/')) {
      const [rangePart, stepStr] = part.split('/');
      const step = parseInt(stepStr, 10);
      if (isNaN(step) || step < 1) throw new Error(`Invalid step in "${part}"`);
      let start = min, end = max;
      if (rangePart !== '*') {
        if (rangePart.includes('-')) {
          [start, end] = rangePart.split('-').map(Number);
        } else {
          start = parseInt(rangePart, 10);
        }
      }
      for (let i = start; i <= end; i += step) values.add(i);
    } else if (part.includes('-')) {
      const [a, b] = part.split('-').map(Number);
      if (isNaN(a) || isNaN(b)) throw new Error(`Invalid range "${part}"`);
      for (let i = a; i <= b; i++) values.add(i);
    } else {
      const n = parseInt(part, 10);
      if (isNaN(n)) throw new Error(`Invalid value "${part}"`);
      values.add(n);
    }
  }
  for (const v of values) {
    if (v < min || v > max) throw new Error(`Value ${v} out of range [${min}-${max}] in "${token}"`);
  }
  return [...values].sort((a, b) => a - b);
}

function parseCron(expr) {
  const fields = expr.trim().split(/\s+/);
  if (fields.length !== 5) throw new Error(`Expected 5 fields, got ${fields.length}`);
  return fields.map((f, i) => parseField(f, FIELD_RANGES[i].min, FIELD_RANGES[i].max));
}

function nextRunTimes(expr, from, count = 10) {
  const [minutes, hours, days, months, weekdays] = parseCron(expr);
  const results = [];
  const d = new Date(from);
  d.setSeconds(0, 0);
  d.setMinutes(d.getMinutes() + 1);

  let iterations = 0;
  while (results.length < count && iterations < 200000) {
    iterations++;
    const mo = d.getMonth() + 1;
    const dy = d.getDate();
    const hr = d.getHours();
    const mi = d.getMinutes();
    const wd = d.getDay();

    if (!months.includes(mo)) {
      d.setMonth(d.getMonth() + 1, 1);
      d.setHours(0, 0, 0, 0);
      continue;
    }
    if (!days.includes(dy) || !weekdays.includes(wd)) {
      d.setDate(d.getDate() + 1);
      d.setHours(0, 0, 0, 0);
      continue;
    }
    if (!hours.includes(hr)) {
      d.setHours(d.getHours() + 1, 0, 0, 0);
      continue;
    }
    if (!minutes.includes(mi)) {
      d.setMinutes(d.getMinutes() + 1, 0, 0);
      continue;
    }
    results.push(new Date(d));
    d.setMinutes(d.getMinutes() + 1, 0, 0);
  }

  if (results.length === 0) throw new Error('Expression matches no dates in the foreseeable future');
  return results;
}

// ─── Format helpers ───────────────────────────────────────────────────────────

const DAYS_SHORT  = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MONTHS_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function formatDate(d) {
  const pad = n => String(n).padStart(2, '0');
  const day = DAYS_SHORT[d.getDay()];
  const mo  = MONTHS_SHORT[d.getMonth()];
  const dt  = String(d.getDate()).padStart(2, ' ');
  const yr  = d.getFullYear();
  const hr  = pad(d.getHours());
  const mi  = pad(d.getMinutes());
  return `${day} ${mo} ${dt} ${yr}  ${hr}:${mi}`;
}

function relTime(from, to) {
  const diff = to - from;
  const mins = Math.floor(diff / 60000);
  const hrs  = Math.floor(mins / 60);
  const dys  = Math.floor(hrs / 24);
  if (dys > 0)  return `in ${dys}d ${hrs % 24}h`;
  if (hrs > 0)  return `in ${hrs}h ${mins % 60}m`;
  return `in ${mins}m`;
}

function describeField(token, idx) {
  const { name } = FIELD_RANGES[idx];
  if (token === '*') return `every ${name}`;
  if (token.startsWith('*/')) return `every ${token.slice(2)} ${name}s`;
  if (/^\d+-\d+$/.test(token)) {
    const [a, b] = token.split('-');
    return `${name}s ${a}–${b}`;
  }
  if (token.includes(',')) return `${name}s ${token}`;
  return `${name} ${token}`;
}

function annotate(expr) {
  const fields = expr.trim().split(/\s+/);
  if (fields.length !== 5) return null;
  return fields.map((f, i) => describeField(f, i)).join(', ');
}

// ─── Non-interactive one-shot mode ───────────────────────────────────────────

if (args.length > 0 && !args[0].startsWith('-')) {
  const expr = args.join(' ');
  try {
    const times = nextRunTimes(expr, new Date());
    const desc  = annotate(expr);
    const now   = new Date();
    process.stdout.write(`\n  Expression: \x1b[36m${expr}\x1b[0m\n`);
    if (desc) process.stdout.write(`  Meaning:    ${desc}\n`);
    process.stdout.write(`\n  Next ${times.length} run times:\n`);
    times.forEach((t, i) => {
      process.stdout.write(
        `  ${String(i + 1).padStart(2)}. ${formatDate(t)}  \x1b[2m${relTime(now, t)}\x1b[0m\n`
      );
    });
    process.stdout.write('\n');
    process.exit(0);
  } catch (e) {
    process.stderr.write(`\x1b[31mError:\x1b[0m ${e.message}\n`);
    process.exit(1);
  }
}

// ─── Interactive TUI ──────────────────────────────────────────────────────────

const C = {
  reset:      '\x1b[0m',
  bold:       '\x1b[1m',
  dim:        '\x1b[2m',
  cyan:       '\x1b[36m',
  green:      '\x1b[32m',
  red:        '\x1b[31m',
  yellow:     '\x1b[33m',
  clear:      '\x1b[2J\x1b[H',
  hideCursor: '\x1b[?25l',
  showCursor: '\x1b[?25h',
};

const EXAMPLES = ['*/5 * * * *', '0 9 * * 1-5', '30 18 * * 5', '0 0 1 * *', '0 */4 * * *'];
let exampleIdx = 0;

let input       = '';
let cursorPos   = 0;
let history     = [];
let histIdx     = -1;
let lastError   = '';
let lastResults = [];
let lastAnnot   = '';

function render() {
  const now = new Date();
  let out = C.clear;
  out += C.bold + '  croncheck' + C.reset + C.dim + '  cron expression previewer' + C.reset + '\n';
  out += C.dim + '  ' + '─'.repeat(50) + C.reset + '\n\n';

  // Prompt
  const placeholder = input.length === 0
    ? C.dim + 'e.g. ' + EXAMPLES[exampleIdx % EXAMPLES.length] + C.reset
    : '';
  out += '  › ' + C.cyan + input + C.reset + placeholder + '\n\n';

  if (lastAnnot) {
    out += C.dim + '  ' + lastAnnot + C.reset + '\n\n';
  }

  if (lastError) {
    out += '  ' + C.red + '✗ ' + lastError + C.reset + '\n';
  }

  if (lastResults.length > 0) {
    out += C.dim + '  Next ' + lastResults.length + ' run times:\n' + C.reset;
    lastResults.forEach((t, i) => {
      out += '  ' + C.dim + String(i + 1).padStart(2) + '. ' + C.reset
           + formatDate(t) + '  ' + C.dim + relTime(now, t) + C.reset + '\n';
    });
  }

  if (!input && !lastError && !lastResults.length) {
    out += C.dim + '  Type a cron expression to see when it fires\n' + C.reset;
  }

  out += '\n' + C.dim + '  ↑↓ history · Enter preview · Tab cycle examples · q / Ctrl+C quit' + C.reset + '\n';
  process.stdout.write(out);
}

function evaluate() {
  const expr = input.trim();
  if (!expr) { lastError = ''; lastResults = []; lastAnnot = ''; return; }
  try {
    lastResults = nextRunTimes(expr, new Date());
    lastAnnot   = annotate(expr) || '';
    lastError   = '';
    if (!history.includes(expr)) { history.unshift(expr); if (history.length > 30) history.pop(); }
  } catch (e) {
    lastError   = e.message;
    lastResults = [];
    lastAnnot   = '';
  }
}

// Guard: must have a TTY to run interactive mode
if (!process.stdin.isTTY) {
  process.stderr.write('croncheck: no TTY detected. Provide an expression as an argument:\n');
  process.stderr.write('  croncheck "30 9 * * 1-5"\n');
  process.exit(1);
}

process.stdout.write(C.hideCursor);
process.stdin.setRawMode(true);
process.stdin.resume();
process.stdin.setEncoding('utf8');

function cleanup() {
  process.stdout.write(C.showCursor + C.reset + '\n');
  try { process.stdin.setRawMode(false); } catch (_) {}
  process.stdin.pause();
  process.exit(0);
}
process.on('SIGINT', cleanup);

render();

process.stdin.on('data', (key) => {
  if (key === '\x03' || key === 'q') { cleanup(); return; }

  if (key === '\r' || key === '\n') {
    evaluate();
    histIdx = -1;
    render();
    return;
  }

  if (key === '\t') {
    // Tab: cycle through examples
    exampleIdx++;
    input     = EXAMPLES[exampleIdx % EXAMPLES.length];
    cursorPos = input.length;
    evaluate();
    render();
    return;
  }

  if (key === '\x7f' || key === '\x08') {
    // Backspace
    if (cursorPos > 0) {
      input     = input.slice(0, cursorPos - 1) + input.slice(cursorPos);
      cursorPos--;
      evaluate();
    }
    render();
    return;
  }

  // Arrow keys
  if (key === '\x1b[A') {
    // Up — history
    if (history.length > 0) {
      histIdx   = Math.min(histIdx + 1, history.length - 1);
      input     = history[histIdx];
      cursorPos = input.length;
      evaluate();
    }
    render();
    return;
  }
  if (key === '\x1b[B') {
    // Down — history
    if (histIdx > 0) {
      histIdx--;
      input     = history[histIdx];
      cursorPos = input.length;
      evaluate();
    } else if (histIdx === 0) {
      histIdx   = -1;
      input     = '';
      cursorPos = 0;
      lastResults = []; lastError = ''; lastAnnot = '';
    }
    render();
    return;
  }
  if (key === '\x1b[C') { if (cursorPos < input.length) cursorPos++; render(); return; }
  if (key === '\x1b[D') { if (cursorPos > 0) cursorPos--;            render(); return; }

  // Printable characters
  if (key.charCodeAt(0) >= 32 && !key.startsWith('\x1b')) {
    input     = input.slice(0, cursorPos) + key + input.slice(cursorPos);
    cursorPos += key.length;
    evaluate();
    render();
  }
});
