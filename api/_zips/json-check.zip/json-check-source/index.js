#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '1.0.0';
const SLUG = 'json-check';

// ─── CLI args ────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);

if (args.includes('--version') || args.includes('-v')) {
  console.log(VERSION);
  process.exit(0);
}

if (args.includes('--help') || args.includes('-h')) {
  console.log(`
${SLUG} v${VERSION}
Recursively validate all JSON files in a directory and report syntax errors.

Usage:
  npx ${SLUG} [directory] [options]

Arguments:
  directory          Directory to scan (default: current directory)

Options:
  --ext <ext>        File extension to check (default: .json)
  --ignore <name>    Directory name to skip (default: node_modules)
  --quiet            Only print failures, not passing files
  --help, -h         Show this help
  --version, -v      Show version

Examples:
  npx json-check .
  npx json-check ./src --ignore dist
  npx json-check . --quiet
  npx json-check . --ext .jsonc

Exit code: 0 if all files pass, 1 if any file has a syntax error.
`);
  process.exit(0);
}

// ─── Parse flags ─────────────────────────────────────────────────────────────
let targetDir = '.';
let ext = '.json';
let ignoreDir = 'node_modules';
let quiet = false;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--ext' && args[i + 1])    { ext = args[++i]; }
  else if (args[i] === '--ignore' && args[i + 1]) { ignoreDir = args[++i]; }
  else if (args[i] === '--quiet')             { quiet = true; }
  else if (!args[i].startsWith('--'))         { targetDir = args[i]; }
}

// ─── Color helpers ───────────────────────────────────────────────────────────
const isTTY = process.stdout.isTTY;
const green = s => isTTY ? `\x1b[32m${s}\x1b[0m` : s;
const red   = s => isTTY ? `\x1b[31m${s}\x1b[0m` : s;
const dim   = s => isTTY ? `\x1b[2m${s}\x1b[0m`  : s;
const bold  = s => isTTY ? `\x1b[1m${s}\x1b[0m`  : s;

// ─── Estimate line number from error message ──────────────────────────────────
function estimateLine(source, errorMsg) {
  // V8 / modern engines: "Unexpected token X at position NNN"
  const posMatch = errorMsg.match(/position\s+(\d+)/i);
  if (posMatch) {
    const pos = Math.min(parseInt(posMatch[1], 10), source.length);
    return source.slice(0, pos).split('\n').length;
  }
  // Some engines: "at line N column M"
  const lineMatch = errorMsg.match(/\bline\s+(\d+)/i);
  if (lineMatch) return parseInt(lineMatch[1], 10);
  return null;
}

// ─── Walk directory ───────────────────────────────────────────────────────────
function walk(dir, results = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (_) {
    return results; // permission denied or non-directory — skip silently
  }
  for (const entry of entries) {
    // Skip hidden dirs, node_modules, and the user-specified ignore dir
    if (entry.name === ignoreDir || entry.name === '.git' || entry.name.startsWith('.')) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full, results);
    } else if (entry.isFile() && entry.name.endsWith(ext)) {
      results.push(full);
    }
  }
  return results;
}

// ─── Main ─────────────────────────────────────────────────────────────────────
const resolvedDir = path.resolve(targetDir);

if (!fs.existsSync(resolvedDir)) {
  console.error(red(`Error: directory not found: ${targetDir}`));
  process.exit(1);
}

const stat = fs.statSync(resolvedDir);
const files = stat.isFile()
  ? [resolvedDir]           // single file passed directly
  : walk(resolvedDir);

if (files.length === 0) {
  console.log(dim(`No ${ext} files found in ${path.resolve(targetDir)}`));
  process.exit(0);
}

let passed = 0;
let failed = 0;

for (const file of files) {
  const rel = path.relative(resolvedDir, file) || path.basename(file);
  let source;
  try {
    source = fs.readFileSync(file, 'utf8');
  } catch (e) {
    console.log(red(`✗ ${rel}`) + dim(` — could not read file: ${e.message}`));
    failed++;
    continue;
  }

  try {
    JSON.parse(source);
    if (!quiet) console.log(green(`✓`) + ` ${rel}`);
    passed++;
  } catch (e) {
    const line = estimateLine(source, e.message);
    const lineInfo = line ? ` (line ${line})` : '';
    console.log(red(`✗ ${rel}`) + dim(` — ${e.message}${lineInfo}`));
    failed++;
  }
}

console.log('');
if (failed === 0) {
  console.log(bold(green(`All ${passed} file${passed !== 1 ? 's' : ''} valid.`)));
  process.exit(0);
} else {
  const total = passed + failed;
  console.log(bold(red(`${failed} of ${total} file${total !== 1 ? 's' : ''} failed.`)));
  process.exit(1);
}
