#!/usr/bin/env node

'use strict';

const http = require('http');
const { execSync } = require('child_process');
const { exec } = require('child_process');

const VERSION = '1.0.0';
const SLUG = 'portmap';

function showHelp() {
  console.log(`
${SLUG} v${VERSION} — visualise all listening ports in a browser dashboard

USAGE
  portmap [options]

OPTIONS
  --port <n>     Port to run the dashboard server on (default: 7777)
  --no-open      Print URL but do not auto-open the browser
  --help         Show this help and exit
  --version      Print version and exit

EXAMPLES
  portmap                   scan ports and open browser dashboard
  portmap --no-open         start server, print URL, skip browser open
  portmap --port 9000       serve dashboard on port 9000
`);
}

function getPorts() {
  try {
    let output = '';
    if (process.platform === 'darwin' || process.platform === 'linux') {
      try {
        output = execSync('lsof -iTCP -sTCP:LISTEN -n -P 2>/dev/null', {
          encoding: 'utf8',
          stdio: ['pipe', 'pipe', 'pipe'],
        });
      } catch (e) {
        output = (e.stdout || '') + (e.stderr || '');
      }
    } else {
      // Windows fallback
      try {
        output = execSync('netstat -ano | findstr LISTENING', {
          encoding: 'utf8',
          stdio: ['pipe', 'pipe', 'pipe'],
        });
        return parseWindowsPorts(output);
      } catch (e) {
        return [];
      }
    }
    return parseLsofPorts(output);
  } catch (e) {
    return [];
  }
}

function parseLsofPorts(output) {
  const ports = new Map();
  const lines = output.split('\n').slice(1); // skip header line
  for (const line of lines) {
    if (!line.trim()) continue;
    const parts = line.trim().split(/\s+/);
    // lsof columns: COMMAND PID USER FD TYPE DEVICE SIZE/OFF NODE NAME
    if (parts.length < 9) continue;
    const command = parts[0];
    const pid = parts[1];
    const addressPort = parts[8];
    const portMatch = addressPort.match(/:(\d+)$/);
    if (!portMatch) continue;
    const port = parseInt(portMatch[1], 10);
    if (!ports.has(port)) {
      ports.set(port, { port, pid, command, address: addressPort });
    }
  }
  return Array.from(ports.values()).sort((a, b) => a.port - b.port);
}

function parseWindowsPorts(output) {
  const ports = new Map();
  for (const line of output.split('\n')) {
    if (!line.trim()) continue;
    const m = line.match(/TCP\s+[\d.:]+:(\d+)\s+.*LISTENING\s+(\d+)/i);
    if (!m) continue;
    const port = parseInt(m[1], 10);
    if (!ports.has(port)) {
      ports.set(port, { port, pid: m[2], command: 'unknown', address: `*:${m[1]}` });
    }
  }
  return Array.from(ports.values()).sort((a, b) => a.port - b.port);
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderHTML(ports, scanTime) {
  const rows = ports.length === 0
    ? '<tr><td colspan="4" class="empty">No listening ports found. Try running with <code>sudo portmap</code>.</td></tr>'
    : ports.map(p => `
    <tr>
      <td class="port">${p.port}</td>
      <td class="process">${escHtml(p.command)}</td>
      <td class="pid">${escHtml(p.pid)}</td>
      <td class="addr">${escHtml(p.address)}</td>
    </tr>`).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>portmap — local port dashboard</title>
<style>
  :root {
    --bg: #0f1117;
    --surface: #1a1d2e;
    --border: #2a2d3e;
    --text: #e2e8f0;
    --muted: #718096;
    --accent: #7c6af7;
    --green: #68d391;
    --blue: #63b3ed;
    --red: #fc8181;
    --font: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --mono: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--font);
    min-height: 100vh;
    padding: 2.5rem 2rem;
  }
  .container { max-width: 860px; margin: 0 auto; }
  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 2rem;
    padding-bottom: 1.25rem;
    border-bottom: 1px solid var(--border);
  }
  .title-row { display: flex; align-items: baseline; gap: 0.75rem; }
  h1 {
    font-size: 1.6rem;
    font-weight: 800;
    letter-spacing: -0.5px;
  }
  h1 .hi { color: var(--accent); }
  .badge {
    display: inline-flex;
    align-items: center;
    background: var(--accent);
    color: #fff;
    border-radius: 9999px;
    padding: 2px 12px;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.02em;
  }
  .meta { font-size: 0.78rem; color: var(--muted); margin-top: 3px; }
  .refresh-btn {
    background: var(--surface);
    color: var(--text);
    border: 1px solid var(--border);
    padding: 0.45rem 1.1rem;
    border-radius: 7px;
    cursor: pointer;
    font-size: 0.85rem;
    font-family: var(--font);
    transition: border-color 0.15s;
  }
  .refresh-btn:hover { border-color: var(--accent); }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.9rem;
  }
  thead th {
    text-align: left;
    padding: 0.55rem 1rem;
    font-size: 0.68rem;
    text-transform: uppercase;
    letter-spacing: 0.09em;
    color: var(--muted);
    border-bottom: 1px solid var(--border);
    font-weight: 600;
  }
  tbody tr { border-bottom: 1px solid var(--border); transition: background 0.12s; }
  tbody tr:last-child { border-bottom: none; }
  tbody tr:hover { background: var(--surface); }
  tbody td { padding: 0.8rem 1rem; vertical-align: middle; }
  .port {
    font-family: var(--mono);
    font-weight: 700;
    color: var(--blue);
    font-size: 1.05rem;
    min-width: 72px;
  }
  .process {
    font-weight: 600;
    color: var(--green);
  }
  .pid {
    font-family: var(--mono);
    color: var(--muted);
    font-size: 0.82rem;
  }
  .addr {
    font-family: var(--mono);
    color: var(--muted);
    font-size: 0.82rem;
  }
  .empty {
    text-align: center;
    color: var(--muted);
    padding: 3rem 1rem;
    font-size: 0.9rem;
  }
  .empty code {
    background: var(--surface);
    padding: 2px 6px;
    border-radius: 4px;
    font-family: var(--mono);
    font-size: 0.85rem;
    color: var(--text);
  }
  .footer {
    margin-top: 2rem;
    font-size: 0.75rem;
    color: var(--muted);
    text-align: center;
  }
  .footer a { color: var(--accent); text-decoration: none; }
  .footer a:hover { text-decoration: underline; }
</style>
</head>
<body>
<div class="container">
  <header>
    <div>
      <div class="title-row">
        <h1><span class="hi">port</span>map</h1>
        <span class="badge">${ports.length} listening</span>
      </div>
      <div class="meta">Scanned at ${escHtml(scanTime)}</div>
    </div>
    <button class="refresh-btn" onclick="location.reload()">&#x21bb; Refresh</button>
  </header>
  <table>
    <thead>
      <tr>
        <th>Port</th>
        <th>Process</th>
        <th>PID</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">
    Built with <a href="https://anishpunati.github.io/mumicro/" target="_blank">&#x00b5; micro</a>
    &nbsp;&middot;&nbsp; press Enter in your terminal to stop the server
  </div>
</div>
</body>
</html>`;
}

// ── CLI entry point ──────────────────────────────────────────────────────────

const args = process.argv.slice(2);

if (args.includes('--help') || args.includes('-h')) {
  showHelp();
  process.exit(0);
}
if (args.includes('--version') || args.includes('-v')) {
  console.log(VERSION);
  process.exit(0);
}

const noOpen = args.includes('--no-open');
let preferredPort = 7777;
const portFlagIdx = args.indexOf('--port');
if (portFlagIdx !== -1 && args[portFlagIdx + 1]) {
  const n = parseInt(args[portFlagIdx + 1], 10);
  if (!isNaN(n) && n > 0 && n < 65536) preferredPort = n;
}

let inactivityTimer;

function resetInactivityTimer(server) {
  clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(() => {
    process.stdout.write('\n\nAuto-closing after 60s of inactivity.\n');
    server.close(() => process.exit(0));
  }, 60000);
}

const server = http.createServer((req, res) => {
  if (req.url === '/favicon.ico') {
    res.writeHead(204);
    res.end();
    return;
  }
  const ports = getPorts();
  const html = renderHTML(ports, new Date().toLocaleTimeString());
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(html);
  resetInactivityTimer(server);
});

function startListening(port) {
  server.listen(port, '127.0.0.1', () => {
    const addr = server.address();
    const url = `http://127.0.0.1:${addr.port}`;
    console.log(`\nportmap dashboard → ${url}`);
    console.log('Press Enter to stop.\n');
    if (!noOpen) {
      const openCmd = process.platform === 'darwin' ? 'open' : 'xdg-open';
      exec(`${openCmd} "${url}"`, () => {});
    }
    resetInactivityTimer(server);
  });
}

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    // Fall back to random OS-assigned port
    startListening(0);
  } else {
    console.error(`[portmap] server error: ${err.message}`);
    process.exit(1);
  }
});

startListening(preferredPort);

// Allow Enter / Ctrl-C to quit cleanly
if (process.stdin.isTTY) {
  process.stdin.setRawMode(true);
}
process.stdin.resume();
process.stdin.setEncoding('utf8');
process.stdin.on('data', (key) => {
  if (key === '\r' || key === '\n' || key === '' /* Ctrl-C */) {
    process.stdout.write('Stopped.\n');
    server.close(() => process.exit(0));
  }
});
