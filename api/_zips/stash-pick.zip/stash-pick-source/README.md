# stash-pick

> Browse, apply, pop, and drop git stashes interactively with arrow-key navigation and inline diff preview

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd stash-pick-source
npm install -g .
```

Verify the install worked:

```bash
stash-pick --version
```

---

## Usage

```
stash-pick v1.0.0
Interactive git stash browser

Usage: stash-pick

Controls:
  Up/k    Move selection up
  Down/j  Move selection down
  Enter   Apply selected stash (keeps it in stash list)
  p       Pop selected stash (apply and remove from list)
  d       Drop selected stash permanently
  q/Esc   Quit without changes

Options:
  --version  Print version and exit
  --help     Show this help message
```

### Examples

Run from inside any git repository:

```bash
cd my-project
stash-pick
```

Browse your stashes with arrow keys. The bottom panel shows a stat summary and colorized diff of the selected stash — so you know what's in it before applying.

```bash
# Apply the selected stash and keep it in the list
# (press Enter in the TUI)

# Pop — apply and remove from stash list
# (press p in the TUI)

# Permanently drop a stash you no longer need
# (press d in the TUI)
```

---

## Why this exists

**Problem:** `git stash list` only shows a cryptic index and branch name — to see what's actually inside `stash@{2}` you have to run a separate `git stash show -p stash@{2}` command. Applying or dropping any stash means typing out the full `stash@{N}` reference every time.

**Solution:** `stash-pick` renders all your stashes in an arrow-key menu with the diff preview shown inline, so you can see exactly what each stash contains and act on it with a single keypress — no typing stash references, no switching between `git stash list` and `git stash show`.

**How it works:** Pure Node.js using `process.stdin` raw mode and ANSI escape codes to render a full-screen TUI. `child_process.execSync` shells out to `git stash list`, `git stash show`, `git stash apply`, `git stash pop`, and `git stash drop`. Zero runtime dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
