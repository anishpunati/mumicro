#!/usr/bin/env node
'use strict';

const fs = require('fs');
const http = require('http');
const path = require('path');
const { exec } = require('child_process');
const readline = require('readline');

const VERSION = '1.0.0';
const DEFAULT_PORT = 7777;

const HELP = [
  'json-explorer v' + VERSION,
  '',
  'Visualize any JSON file as an interactive collapsible tree in your browser.',
  '',
  'Usage:',
  '  json-explorer <file.json> [options]',
  '  cat file.json | json-explorer -',
  '',
  'Options:',
  '  --port <n>   Port to listen on (default: ' + DEFAULT_PORT + ')',
  '  --help       Show this help',
  '  --version    Print version',
  '',
  'Examples:',
  '  json-explorer response.json',
  '  json-explorer api.json --port 8080',
  '  curl https://api.github.com/users/octocat | json-explorer -'
].join('\n');

const argv = process.argv.slice(2);

if (argv.includes('--help') || argv.includes('-h')) { console.log(HELP); process.exit(0); }
if (argv.includes('--version') || argv.includes('-v')) { console.log(VERSION); process.exit(0); }

let port = DEFAULT_PORT;
const portIdx = argv.indexOf('--port');
if (portIdx !== -1) {
  port = parseInt(argv[portIdx + 1], 10);
  if (!port || port < 1 || port > 65535) {
    console.error('Error: invalid port number');
    process.exit(1);
  }
}

const positionals = argv.filter(function(a, i) {
  return !a.startsWith('-') && (i === 0 || argv[i - 1] !== '--port');
});
const fileArg = positionals[0];

if (!fileArg) {
  console.error('Error: no file specified.\n\n' + HELP);
  process.exit(1);
}

let raw;
try {
  const src = fileArg === '-' ? '/dev/stdin' : path.resolve(fileArg);
  raw = fs.readFileSync(src, 'utf8');
} catch (e) {
  console.error('Error reading "' + fileArg + '": ' + e.message);
  process.exit(1);
}

let data;
try {
  data = JSON.parse(raw);
} catch (e) {
  console.error('Invalid JSON: ' + e.message);
  process.exit(1);
}

const fileName = fileArg === '-' ? 'stdin' : path.basename(fileArg);

// ── Server-side HTML tree builder ──────────────────────────────────────────

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function typeOf(v) {
  if (v === null) return 'null';
  if (Array.isArray(v)) return 'array';
  return typeof v;
}

function leafHtml(v) {
  const t = typeOf(v);
  if (t === 'string')  return '<span class="vs">' + esc(JSON.stringify(v)) + '</span>';
  if (t === 'number')  return '<span class="vn">' + esc(String(v)) + '</span>';
  if (t === 'boolean') return '<span class="vb">' + esc(String(v)) + '</span>';
  if (t === 'null')    return '<span class="vz">null</span>';
  return '';
}

let nodeId = 0;
let nodeCount = 0;

function buildNode(v, depth, nodePath) {
  nodeCount++;
  const t = typeOf(v);
  const isContainer = t === 'array' || t === 'object';
  const ind = depth * 14;
  const dp = esc(nodePath !== undefined ? nodePath : '');
  const dv = esc(JSON.stringify(v));

  // Leaf node
  if (!isContainer) {
    return '<div class="node">'
      + '<div class="row" data-path="' + dp + '" data-val="' + dv + '">'
      + '<span class="ind" style="width:' + ind + 'px"></span>'
      + '<span class="spc"></span>'
      + leafHtml(v)
      + '<button class="cp">copy</button>'
      + '</div>'
      + '</div>';
  }

  // Container node
  const entries = t === 'array'
    ? v.map(function(x, i) { return [String(i), x]; })
    : Object.keys(v).map(function(k) { return [k, v[k]]; });

  const count = entries.length;
  const ob = t === 'array' ? '[' : '{';
  const cb = t === 'array' ? ']' : '}';
  const lbl = count + (count === 1 ? ' item' : ' items');
  const nid = 'n' + (nodeId++);
  const childClass = depth < 2 ? 'ch' : 'ch hd';

  const childHtml = entries.map(function(pair) {
    const ck = pair[0];
    const cv = pair[1];
    nodeCount++;
    const ct = typeOf(cv);
    const isCC = ct === 'array' || ct === 'object';
    const cid = 'n' + (nodeId++);
    const childPath = nodePath
      ? (t === 'array' ? nodePath + '[' + ck + ']' : nodePath + '.' + ck)
      : ck;
    const cdp = esc(childPath);
    const cdv = esc(JSON.stringify(cv));
    const cvHtml = isCC ? null : leafHtml(cv);
    const ccount = isCC ? (Array.isArray(cv) ? cv.length : Object.keys(cv).length) : 0;
    const cob = Array.isArray(cv) ? '[' : '{';
    const ccb = Array.isArray(cv) ? ']' : '}';
    const cLbl = ccount + (ccount === 1 ? ' item' : ' items');

    return '<div class="node" id="' + cid + '">'
      + '<div class="row" data-path="' + cdp + '" data-val="' + cdv + '">'
      + '<span class="ind" style="width:' + ((depth + 1) * 14) + 'px"></span>'
      + (isCC
        ? '<span class="tog" data-ch="' + cid + '-ch">&#9658;</span>'
        : '<span class="spc"></span>')
      + '<span class="k">' + esc(JSON.stringify(ck)) + '</span>'
      + '<span class="sep">:</span>'
      + (cvHtml
        ? cvHtml + '<button class="cp">copy</button>'
        : '<span class="br">' + cob + '</span><span class="cnt">' + cLbl + '</span><span class="br">' + ccb + '</span>')
      + '</div>'
      + (isCC
        ? '<div class="ch hd" id="' + cid + '-ch">' + buildNode(cv, depth + 1, childPath) + '</div>'
        : '')
      + '</div>';
  }).join('');

  return '<div class="node" id="' + nid + '">'
    + '<div class="row" data-path="' + dp + '" data-val="' + dv + '">'
    + '<span class="ind" style="width:' + ind + 'px"></span>'
    + '<span class="tog" data-ch="' + nid + '-ch">&#9660;</span>'
    + '<span class="br">' + ob + '</span>'
    + '<span class="cnt">' + lbl + '</span>'
    + '<span class="br">' + cb + '</span>'
    + '<button class="cp">copy all</button>'
    + '</div>'
    + '<div class="' + childClass + '" id="' + nid + '-ch">' + childHtml + '</div>'
    + '</div>';
}

const treeHtml = buildNode(data, 0, '');
const statsText = nodeCount + ' nodes rendered';

// ── Client-side JS (uses event delegation — no inline onclick, no quoting issues) ─

/* jshint ignore:start */
const CLIENT_JS = `(function(){
  var tree = document.getElementById('tree');

  // Toggle + copy via event delegation
  tree.addEventListener('click', function(e) {
    var el = e.target;

    if (el.classList.contains('tog')) {
      var chId = el.getAttribute('data-ch');
      var ch = document.getElementById(chId);
      if (!ch) return;
      var hidden = ch.classList.toggle('hd');
      el.innerHTML = hidden ? '&#9658;' : '&#9660;';
      return;
    }

    if (el.classList.contains('cp')) {
      var row = el.closest('.row');
      if (!row) return;
      var rawVal = row.getAttribute('data-val');
      var parsed;
      try { parsed = JSON.parse(rawVal); } catch(ex) { parsed = rawVal; }
      var text = typeof parsed === 'string' ? parsed : JSON.stringify(parsed, null, 2);
      navigator.clipboard.writeText(text).then(function() {
        var orig = el.textContent;
        el.textContent = 'copied!';
        setTimeout(function() { el.textContent = orig; }, 1200);
      });
    }
  });

  // Hover path display
  tree.addEventListener('mouseover', function(e) {
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (!row) return;
    var p = row.getAttribute('data-path');
    if (p === null) return;
    var bar = document.getElementById('path-bar');
    if (p) {
      bar.innerHTML = '<span class="pv">' + p.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</span>';
    } else {
      bar.innerHTML = '<em>(root)</em>';
    }
  });

  // Expand all
  document.getElementById('btn-expand').addEventListener('click', function() {
    tree.querySelectorAll('.ch.hd').forEach(function(ch) {
      ch.classList.remove('hd');
      var tid = ch.id.replace('-ch', '');
      var tog = document.querySelector('#' + tid + ' > .row .tog');
      if (tog) tog.innerHTML = '&#9660;';
    });
  });

  // Collapse all
  document.getElementById('btn-collapse').addEventListener('click', function() {
    tree.querySelectorAll('.ch:not(.hd)').forEach(function(ch) {
      ch.classList.add('hd');
      var tid = ch.id.replace('-ch', '');
      var tog = document.querySelector('#' + tid + ' > .row .tog');
      if (tog) tog.innerHTML = '&#9658;';
    });
  });

  // Search
  var searchTimer;
  document.getElementById('search').addEventListener('input', function() {
    clearTimeout(searchTimer);
    var q = this.value.trim();
    searchTimer = setTimeout(function() { doSearch(q); }, 200);
  });

  function doSearch(q) {
    tree.querySelectorAll('.row').forEach(function(r) { r.classList.remove('hl'); });
    if (!q) return;
    var ql = q.toLowerCase();
    tree.querySelectorAll('.row').forEach(function(row) {
      var p = (row.getAttribute('data-path') || '').toLowerCase();
      var v = (row.getAttribute('data-val') || '').toLowerCase();
      if (p.indexOf(ql) === -1 && v.indexOf(ql) === -1) return;
      row.classList.add('hl');
      // Expand ancestors
      var el = row.parentElement;
      while (el && el !== tree) {
        if (el.classList && el.classList.contains('ch') && el.classList.contains('hd')) {
          el.classList.remove('hd');
          var tid = el.id.replace('-ch', '');
          var tog = document.querySelector('#' + tid + ' > .row .tog');
          if (tog) tog.innerHTML = '&#9660;';
        }
        el = el.parentElement;
      }
    });
  }
})();`;
/* jshint ignore:end */

// ── Assemble the final HTML page ───────────────────────────────────────────

const CSS = [
  ':root{--bg:#0f1117;--surface:#1a1d27;--border:#2a2e47;--text:#e2e8f0;--muted:#64748b;',
  '--accent:#6366f1;--accent-dim:#1e1b4b;--vs:#86efac;--vn:#67e8f9;--vb:#f9a8d4;',
  '--vz:#94a3b8;--key:#c4b5fd;--hover:#1e2235;--path-bg:#13162a;}',
  '*{box-sizing:border-box;margin:0;padding:0;}',
  'body{background:var(--bg);color:var(--text);font-family:"SF Mono","Fira Code","Consolas",monospace;font-size:13px;line-height:1.7;min-height:100vh;}',
  '#header{background:var(--surface);border-bottom:1px solid var(--border);padding:10px 20px;display:flex;align-items:center;gap:10px;position:sticky;top:0;z-index:10;}',
  '#header h1{font-size:14px;font-weight:700;flex-shrink:0;}',
  '.badge{background:var(--accent-dim);color:var(--accent);font-size:11px;padding:2px 8px;border-radius:4px;flex-shrink:0;}',
  '#controls{display:flex;gap:6px;flex-shrink:0;}',
  '.ctrl-btn{background:var(--surface);border:1px solid var(--border);color:var(--muted);padding:3px 9px;border-radius:5px;font-size:11px;cursor:pointer;font-family:inherit;}',
  '.ctrl-btn:hover{color:var(--text);border-color:var(--accent);}',
  '#search{margin-left:auto;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:5px 10px;color:var(--text);font-family:inherit;font-size:12px;width:230px;outline:none;}',
  '#search:focus{border-color:var(--accent);}',
  '#path-bar{background:var(--path-bg);border-bottom:1px solid var(--border);padding:4px 20px;font-size:11px;color:var(--muted);min-height:24px;}',
  '#path-bar .pv{color:var(--accent);}',
  '#tree{padding:10px 20px 40px;}',
  '.row{display:flex;align-items:baseline;padding:1px 4px;border-radius:3px;}',
  '.row:hover{background:var(--hover);}',
  '.row.hl{background:var(--accent-dim);}',
  '.ind,.spc{display:inline-block;flex-shrink:0;}',
  '.spc{width:14px;}',
  '.tog{display:inline-block;width:14px;flex-shrink:0;cursor:pointer;color:var(--muted);user-select:none;text-align:center;font-size:9px;}',
  '.tog:hover{color:var(--accent);}',
  '.k{color:var(--key);}',
  '.sep{color:var(--muted);margin:0 3px;}',
  '.br{color:var(--muted);}',
  '.vs{color:var(--vs);}',
  '.vn{color:var(--vn);}',
  '.vb{color:var(--vb);}',
  '.vz{color:var(--vz);}',
  '.cnt{color:var(--muted);font-size:11px;margin-left:5px;}',
  '.cp{display:none;margin-left:8px;padding:0 5px;background:var(--accent-dim);color:var(--accent);border:none;border-radius:3px;font-size:10px;cursor:pointer;font-family:inherit;}',
  '.row:hover .cp{display:inline;}',
  '.cp:hover{background:var(--accent);color:#fff;}',
  '.ch{display:block;}',
  '.ch.hd{display:none;}',
  '#stats{color:var(--muted);font-size:11px;padding:4px 20px 20px;}'
].join('');

const HTML = '<!DOCTYPE html>\n'
  + '<html lang="en">\n'
  + '<head>\n'
  + '<meta charset="UTF-8">\n'
  + '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  + '<title>json-explorer — ' + esc(fileName) + '</title>\n'
  + '<style>' + CSS + '</style>\n'
  + '</head>\n'
  + '<body>\n'
  + '<div id="header">\n'
  + '  <h1>json-explorer</h1>\n'
  + '  <span class="badge">' + esc(fileName) + '</span>\n'
  + '  <div id="controls">\n'
  + '    <button class="ctrl-btn" id="btn-expand">expand all</button>\n'
  + '    <button class="ctrl-btn" id="btn-collapse">collapse all</button>\n'
  + '  </div>\n'
  + '  <input id="search" type="text" placeholder="Search keys or values..." autocomplete="off" spellcheck="false">\n'
  + '</div>\n'
  + '<div id="path-bar">hover any row to see its path</div>\n'
  + '<div id="tree">' + treeHtml + '</div>\n'
  + '<div id="stats">' + esc(statsText) + '</div>\n'
  + '<script>' + CLIENT_JS + '</script>\n'
  + '</body>\n'
  + '</html>';

// ── HTTP server ────────────────────────────────────────────────────────────

const server = http.createServer(function(req, res) {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(HTML);
});

server.on('error', function(e) {
  if (e.code === 'EADDRINUSE') {
    console.error('Error: port ' + port + ' is already in use. Try: json-explorer <file> --port <n>');
  } else {
    console.error('Server error: ' + e.message);
  }
  process.exit(1);
});

server.listen(port, '127.0.0.1', function() {
  const addr = server.address();
  const url = 'http://localhost:' + addr.port;
  console.log('\njson-explorer');
  console.log('  file:   ' + (fileArg === '-' ? 'stdin' : path.resolve(fileArg)));
  console.log('  server: ' + url);
  console.log('\nOpening browser... press Enter to stop the server.\n');
  const opener = process.platform === 'darwin' ? 'open' : 'xdg-open';
  exec(opener + ' "' + url + '"');
});

const shutdownTimer = setTimeout(function() {
  console.log('Auto-closing after 60 seconds.');
  server.close(function() { process.exit(0); });
}, 60000);

const rl = readline.createInterface({ input: process.stdin });
rl.on('line', function() {
  clearTimeout(shutdownTimer);
  server.close(function() { process.exit(0); });
});
rl.on('close', function() {
  clearTimeout(shutdownTimer);
  server.close(function() { process.exit(0); });
});
