# cert-peek

> Check SSL certificate expiry and details for any domain in seconds from your terminal

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd cert-peek-source
npm install -g .
```

Verify the install worked:

```bash
cert-peek --version
```

---

## Usage

```
cert-peek — Check SSL certificate expiry and details for any domain

Usage:
  cert-peek <domain> [domain2 ...]

Options:
  --help,    -h  Show this help message and exit
  --version, -v  Print the version and exit

Examples:
  cert-peek github.com
  cert-peek google.com cloudflare.com api.stripe.com
  npx cert-peek mysite.example.com

Exit codes:
  0  All certs are healthy (more than 30 days remaining)
  1  At least one cert is expiring soon (< 30 days) or already expired
  2  Connection or resolution error for at least one domain
```

### Examples

Check a single domain:

```bash
cert-peek github.com
```

```
Domain:      github.com
Issuer:      DigiCert Inc
Valid from:  2025-03-12
Expires:     2026-03-12
Status:      ✓ OK — 303 days remaining
```

Check multiple domains at once:

```bash
cert-peek google.com api.stripe.com expired.badssl.com
```

```
Domain:      google.com
Issuer:      Google Trust Services
Valid from:  2025-04-07
Expires:     2025-06-30
Status:      ✓ OK — 48 days remaining

Domain:      api.stripe.com
Issuer:      Amazon
Valid from:  2025-02-10
Expires:     2026-03-11
Status:      ✓ OK — 271 days remaining

Domain:      expired.badssl.com
Issuer:      COMODO CA Limited
Valid from:  2015-04-09
Expires:     2015-04-12
Status:      ✗ EXPIRED 3957 days ago
```

Use in a CI pre-flight check (exits 1 if any cert is within 30 days of expiry):

```bash
cert-peek myproduction.site || echo "WARNING: cert expiring soon"
```

---

## Why this exists

**Problem:** Developers and ops teams get blindsided by expired SSL certificates because checking expiry requires remembering a multi-flag `openssl s_client` command and parsing its dense output — so certs get forgotten until the site goes red.

**Solution:** cert-peek uses Node's built-in TLS stack to connect to any domain, extract certificate details, and print a color-coded summary with days-remaining and an at-a-glance status indicator.

**How it works:** Pure Node.js using the built-in `tls` module — no dependencies. Opens a raw TLS socket to port 443, calls `getPeerCertificate()`, parses validity dates, and computes days remaining. Color-coded output (green/yellow/red) and a non-zero exit code make it CI-friendly.

---

## Support

Questions or issues? Email anishpunati@gmail.com
