# stale-deps

> Scan your package.json dependencies for packages that haven't been updated in a while — spot potentially abandoned npm packages instantly.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd stale-deps-source
npm install -g .
```

Verify the install worked:

```bash
stale-deps --version
```

---

## Usage

```
stale-deps v1.0.0

Scan your package.json dependencies for packages that haven't been updated
in a while — helping you spot potentially abandoned npm packages.

Usage:
  npx stale-deps [options]

Options:
  --days <n>      Flag packages not updated in N days (default: 365)
  --include-dev   Also check devDependencies (default: production only)
  --json          Output results as JSON
  --help          Show this help
  --version       Show version

Examples:
  npx stale-deps
  npx stale-deps --days 180 --include-dev
  npx stale-deps --json > stale-report.json
```

### Examples

**Check production dependencies for packages not updated in over a year:**

```bash
$ npx stale-deps

Checking 12 packages against npm registry (threshold: 365 days)...

⚠  3 stale packages found (not updated in 365+ days):

  PACKAGE         VERSION  LAST UPDATED   DAYS AGO
  ──────────────  ───────  ─────────────  ────────
  node-uuid       1.4.8    2017-03-11      2982d  (8y 1m)
  request         2.88.2   2020-02-14      1912d  (5y 3m)
  colors          1.4.0    2021-01-16      1576d  (4y 3m)

✓ 9 packages recently updated.
```

**Check everything including devDependencies, with a tighter 6-month window:**

```bash
$ npx stale-deps --days 180 --include-dev
```

**Export a JSON report for CI or further processing:**

```bash
$ npx stale-deps --json > stale-report.json
```

---

## Why this exists

**Problem:** Developers often don't realize their project dependencies have been abandoned — `npm outdated` shows version lag but not how long ago a package was last published, leaving stale and potentially vulnerable packages silently lurking in codebases.

**Solution:** `stale-deps` reads your package.json, queries the npm registry for each package's last publish date, and flags any package that hasn't been updated in over a configurable number of days.

**How it works:** The tool reads package.json, then hits the npm registry's public JSON API (no auth, no dependencies) for each package to get its `_npmPublishTime` field, computes the age in days, and outputs a formatted table of stale packages sorted by staleness. Requests are batched 10 at a time to avoid hammering the registry.

---

## Support

Questions or issues? Email anishpunati@gmail.com
