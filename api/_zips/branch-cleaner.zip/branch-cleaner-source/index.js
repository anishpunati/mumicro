#!/usr/bin/env node
'use strict';

const { execSync } = require('child_process');

const VERSION = '1.0.0';

const RESET = '\x1b[0m';
const BOLD = '\x1b[1m';
const DIM = '\x1b[2m';
const RED = '\x1b[31m';
const GREEN = '\x1b[32m';
const YELLOW = '\x1b[33m';
const CYAN = '\x1b[36m';
const CLEAR = '\x1b[2J';
const HOME = '\x1b[H';
const HIDE_CURSOR = '\x1b[?25l';
const SHOW_CURSOR = '\x1b[?25h';
const SEL_BG = '\x1b[48;5;237m';
const SEL_BG_MARKED = '\x1b[48;5;52m';

if (process.argv.includes('--version') || process.argv.includes('-v')) {
  console.log(VERSION);
  process.exit(0);
}

if (process.argv.includes('--help') || process.argv.includes('-h')) {
  console.log(`
${BOLD}branch-cleaner${RESET} v${VERSION}

Interactively browse and delete stale git branches.

${BOLD}USAGE${RESET}
  branch-cleaner [options]

${BOLD}OPTIONS${RESET}
  --help, -h      Show this help message
  --version, -v   Print version number

${BOLD}KEYS${RESET}
  ↑ / k           Move up
  ↓ / j           Move down
  d               Toggle branch for deletion
  Enter           Delete all marked branches
  r               Refresh branch list
  q / Ctrl+C      Quit without deleting

${BOLD}COLUMNS${RESET}
  BRANCH          Local branch name (* = current)
  AGE             Days since last commit on that branch
  MERGED          Whether the branch is merged into current HEAD
  LAST COMMIT     Most recent commit message (truncated)

${BOLD}NOTES${RESET}
  - The current branch is never deletable.
  - Merged branches are deleted with 'git branch -d' (safe).
  - Unmerged branches are deleted with 'git branch -D' (force) — you are warned.
  - Run from anywhere inside a git repository.
`);
  process.exit(0);
}

// Verify we're in a git repo
try {
  execSync('git rev-parse --git-dir', { stdio: 'ignore' });
} catch (e) {
  console.error(`${RED}Error:${RESET} Not a git repository.\nRun branch-cleaner from inside a git project directory.`);
  process.exit(1);
}

// ── Data loading ─────────────────────────────────────────────────────────────

function getBranches() {
  const currentBranch = execSync('git rev-parse --abbrev-ref HEAD', { encoding: 'utf8' }).trim();

  // Merged into HEAD
  const mergedSet = new Set();
  try {
    execSync('git branch --merged HEAD', { encoding: 'utf8' })
      .split('\n')
      .forEach(b => {
        const name = b.replace(/^\*?\s+/, '').trim();
        if (name) mergedSet.add(name);
      });
  } catch (_) {}

  // All branches with last commit info
  const raw = execSync('git branch -v --sort=-committerdate', { encoding: 'utf8' });

  return raw.split('\n').filter(Boolean).map(line => {
    const isCurrent = line.startsWith('*');
    const stripped = line.replace(/^\*?\s+/, '');
    const m = stripped.match(/^(\S+)\s+([a-f0-9]+)\s+(.*)$/);
    if (!m) return null;

    const name = m[1];
    const hash = m[2];
    // strip (HEAD -> ...) or (origin/...) prefix from message
    const message = m[3].replace(/^\(.*?\)\s*/, '');

    let ageDays = '?';
    try {
      const ts = parseInt(
        execSync(`git log -1 --format="%at" -- "${name}" 2>/dev/null || git log -1 --format="%at" "${name}"`,
          { encoding: 'utf8', shell: true }).trim(), 10);
      if (!isNaN(ts)) {
        ageDays = Math.floor((Date.now() / 1000 - ts) / 86400);
      }
    } catch (_) {}

    return { name, hash, message, isCurrent, isMerged: mergedSet.has(name), ageDays, marked: false };
  }).filter(Boolean);
}

// ── Rendering ─────────────────────────────────────────────────────────────────

function padRight(str, len) {
  const s = String(str);
  if (s.length >= len) return s.slice(0, len);
  return s + ' '.repeat(len - s.length);
}

function render(branches, cursor, statusMsg) {
  const cols = Math.max(60, process.stdout.columns || 80);
  const rows = Math.max(10, process.stdout.rows || 24);

  const nameW = Math.max(22, Math.floor(cols * 0.35));
  const msgW  = Math.max(15, cols - nameW - 26);

  let out = CLEAR + HOME;

  // Header
  out += `  ${BOLD}branch-cleaner${RESET}  ${DIM}↑↓ navigate · d mark · Enter delete · r refresh · q quit${RESET}\n`;
  out += `  ${DIM}${'─'.repeat(Math.min(cols - 4, nameW + msgW + 22))}${RESET}\n`;

  // Column headers
  out += `  ${BOLD}${DIM}${padRight('BRANCH', nameW)} ${'AGE'.padStart(5)}  ${padRight('MERGED', 6)}  ${padRight('LAST COMMIT', msgW)}${RESET}\n`;
  out += `  ${DIM}${'─'.repeat(Math.min(cols - 4, nameW + msgW + 22))}${RESET}\n`;

  // Branch rows
  const maxVisible = Math.max(1, rows - 10);
  const scrollOffset = Math.max(0, cursor - Math.floor(maxVisible / 2));
  const visible = branches.slice(scrollOffset, scrollOffset + maxVisible);

  if (branches.length === 0) {
    out += `  ${YELLOW}No branches found.${RESET}\n`;
  }

  visible.forEach((branch, i) => {
    const idx = i + scrollOffset;
    const isSelected = idx === cursor;

    const mark   = branch.marked ? `${RED}✗${RESET}` : ' ';
    const merged = branch.isMerged ? `${GREEN}  yes${RESET}` : `${DIM}   no${RESET}`;
    const ageStr = branch.ageDays === '?' ? '   ?' : String(branch.ageDays).padStart(4) + 'd';

    let nameDisplay;
    if (branch.isCurrent) {
      nameDisplay = `${CYAN}${padRight(branch.name, nameW - 10)}${RESET}${DIM}(current)${RESET}`;
    } else if (branch.marked) {
      nameDisplay = `${RED}${padRight(branch.name, nameW)}${RESET}`;
    } else {
      nameDisplay = padRight(branch.name, nameW);
    }

    const msgDisplay = `${DIM}${padRight(branch.message.slice(0, msgW - 1), msgW)}${RESET}`;
    const rowBold = isSelected ? BOLD : '';
    const content = `${mark} ${rowBold}${nameDisplay} ${ageStr}  ${merged}  ${msgDisplay}${RESET}`;

    if (isSelected && branch.marked) {
      out += `${SEL_BG_MARKED}\x1b[K ${content}${RESET}\n`;
    } else if (isSelected) {
      out += `${SEL_BG}\x1b[K ${content}${RESET}\n`;
    } else {
      out += `  ${content}${RESET}\n`;
    }
  });

  // Footer
  out += `\n  ${DIM}${'─'.repeat(Math.min(cols - 4, nameW + msgW + 22))}${RESET}\n`;
  const marked = branches.filter(b => b.marked);
  if (marked.length > 0) {
    const hasUnmerged = marked.some(b => !b.isMerged);
    out += `  ${RED}${BOLD}${marked.length} branch${marked.length !== 1 ? 'es' : ''} marked for deletion.${RESET}`;
    if (hasUnmerged) out += ` ${YELLOW}(includes unmerged — will use -D)${RESET}`;
    out += ` Press ${BOLD}Enter${RESET} to confirm.\n`;
  } else {
    out += `  ${DIM}No branches marked. Press ${BOLD}d${DIM} to mark the highlighted branch.${RESET}\n`;
  }
  if (statusMsg) {
    out += `  ${statusMsg}\n`;
  }

  process.stdout.write(out);
}

// ── Deletion ──────────────────────────────────────────────────────────────────

function deleteBranches(branches) {
  const toDelete = branches.filter(b => b.marked && !b.isCurrent);
  if (toDelete.length === 0) return { msg: `${YELLOW}Nothing to delete.${RESET}`, branches };

  let deleted = 0, failed = 0, failMsg = '';
  toDelete.forEach(branch => {
    try {
      const flag = branch.isMerged ? '-d' : '-D';
      execSync(`git branch ${flag} "${branch.name}"`, { stdio: 'ignore' });
      deleted++;
    } catch (e) {
      failed++;
      failMsg += ` ${branch.name}`;
    }
  });

  let msg = deleted > 0 ? `${GREEN}Deleted ${deleted} branch${deleted !== 1 ? 'es' : ''}.${RESET}` : '';
  if (failed > 0) msg += ` ${RED}Failed:${failMsg}${RESET}`;

  const freshBranches = getBranches();
  return { msg, branches: freshBranches };
}

// ── Main ──────────────────────────────────────────────────────────────────────

let branches = [];
let cursor = 0;
let statusMsg = '';

try {
  branches = getBranches();
} catch (e) {
  console.error(`${RED}Error:${RESET} ${e.message}`);
  process.exit(1);
}

if (!process.stdout.isTTY || !process.stdin.isTTY) {
  // Non-interactive: just list branches
  branches.forEach(b => {
    const cur = b.isCurrent ? ' (current)' : '';
    const merged = b.isMerged ? ' [merged]' : '';
    const age = b.ageDays === '?' ? '' : ` [${b.ageDays}d ago]`;
    console.log(`${b.name}${cur}${merged}${age} — ${b.message}`);
  });
  process.exit(0);
}

function cleanup() {
  process.stdout.write(SHOW_CURSOR + CLEAR + HOME);
  try { process.stdin.setRawMode(false); } catch (_) {}
}

process.on('exit', cleanup);
process.on('SIGINT', () => { cleanup(); process.exit(0); });
process.on('SIGTERM', () => { cleanup(); process.exit(0); });

process.stdout.write(HIDE_CURSOR);
process.stdin.setRawMode(true);
process.stdin.resume();
process.stdin.setEncoding('utf8');

render(branches, cursor, statusMsg);

process.stdin.on('data', key => {
  if (key === '') { cleanup(); process.exit(0); }   // Ctrl+C
  if (key === 'q' || key === 'Q') { cleanup(); process.exit(0); }

  if (key === '[A' || key === 'k') {   // Up / k
    cursor = Math.max(0, cursor - 1);
  } else if (key === '[B' || key === 'j') {  // Down / j
    cursor = Math.min(branches.length - 1, cursor + 1);
  } else if (key === 'd' || key === 'D') {
    const b = branches[cursor];
    if (b) {
      if (b.isCurrent) {
        statusMsg = `${YELLOW}Cannot delete the current branch.${RESET}`;
      } else {
        b.marked = !b.marked;
        statusMsg = '';
        if (cursor < branches.length - 1) cursor++;
      }
    }
  } else if (key === '\r' || key === '\n') {
    const result = deleteBranches(branches);
    branches = result.branches;
    statusMsg = result.msg;
    cursor = Math.min(cursor, Math.max(0, branches.length - 1));
  } else if (key === 'r' || key === 'R') {
    try {
      branches = getBranches();
      cursor = Math.min(cursor, Math.max(0, branches.length - 1));
      statusMsg = `${GREEN}Refreshed.${RESET}`;
    } catch (e) {
      statusMsg = `${RED}Refresh failed: ${e.message}${RESET}`;
    }
  } else {
    return; // ignore other keys without re-render
  }

  render(branches, cursor, statusMsg);
});
