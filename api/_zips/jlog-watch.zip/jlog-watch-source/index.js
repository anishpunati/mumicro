#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '1.0.0';

const LEVEL_COLORS = {
  10: '\x1b[37m',  // TRACE  - grey
  20: '\x1b[36m',  // DEBUG  - cyan
  30: '\x1b[32m',  // INFO   - green
  40: '\x1b[33m',  // WARN   - yellow
  50: '\x1b[31m',  // ERROR  - red
  60: '\x1b[35m',  // FATAL  - magenta
};

const LEVEL_NAMES = {
  10: 'TRACE', 20: 'DEBUG', 30: 'INFO ',
  40: 'WARN ', 50: 'ERROR', 60: 'FATAL',
};

const RESET  = '\x1b[0m';
const DIM    = '\x1b[2m';
const BOLD   = '\x1b[1m';

function formatLine(raw) {
  const line = raw.trim();
  if (!line) return null;

  let obj;
  try {
    obj = JSON.parse(line);
  } catch (_) {
    // Not JSON — print dim so it doesn't drown signal
    return `${DIM}${line}${RESET}`;
  }

  const level  = typeof obj.level === 'number' ? obj.level : 30;
  const color  = LEVEL_COLORS[level] || '\x1b[37m';
  const lname  = LEVEL_NAMES[level]  || `L${level} `;
  const msg    = obj.msg || obj.message || '';

  // Timestamp: accept epoch-ms (pino default) or ISO string
  let ts = '';
  if (obj.time) {
    const d = typeof obj.time === 'number' ? new Date(obj.time) : new Date(obj.time);
    ts = d.toISOString().replace('T', ' ').slice(0, 23);
  }

  // Extra fields: skip the standard pino/bunyan envelope keys
  const skip = new Set(['level', 'time', 'msg', 'message', 'pid', 'hostname', 'name', 'v']);
  const extras = Object.entries(obj)
    .filter(([k]) => !skip.has(k))
    .map(([k, v]) => {
      const val = typeof v === 'object' ? JSON.stringify(v) : String(v);
      return `${DIM}${k}${RESET}=${val}`;
    })
    .join(' ');

  const parts = [
    ts ? `${DIM}${ts}${RESET}` : '',
    `${color}${BOLD}${lname}${RESET}`,
    msg,
    extras,
  ].filter(Boolean);

  return parts.join('  ');
}

function watchFile(filePath) {
  const absPath = path.resolve(filePath);

  if (!fs.existsSync(absPath)) {
    console.error(`\x1b[31mError:\x1b[0m file not found: ${absPath}`);
    process.exit(1);
  }

  let pos        = fs.statSync(absPath).size;  // start at EOF — show only new lines
  let errorCount = 0;
  let debounce   = null;

  process.stdout.write(
    `\x1b[36m●\x1b[0m \x1b[1mjlog-watch\x1b[0m watching \x1b[2m${absPath}\x1b[0m\n` +
    `\x1b[2mPress Ctrl+C to stop\x1b[0m\n\n`
  );

  function readNew() {
    let stat;
    try { stat = fs.statSync(absPath); } catch (_) { return; }

    if (stat.size < pos) {
      // File rotated / truncated
      process.stdout.write(`\x1b[33m↻ file rotated — resetting position\x1b[0m\n`);
      pos = 0;
    }
    if (stat.size === pos) return;

    const len = stat.size - pos;
    const buf = Buffer.alloc(len);
    const fd  = fs.openSync(absPath, 'r');
    fs.readSync(fd, buf, 0, len, pos);
    fs.closeSync(fd);
    pos = stat.size;

    const lines = buf.toString('utf8').split('\n');
    for (const line of lines) {
      const out = formatLine(line);
      if (out !== null) {
        // Track error/fatal count for exit summary
        try {
          const o = JSON.parse(line.trim());
          if (typeof o.level === 'number' && o.level >= 50) errorCount++;
        } catch (_) {}
        console.log(out);
      }
    }
  }

  fs.watchFile(absPath, { interval: 150 }, () => {
    if (debounce) clearTimeout(debounce);
    debounce = setTimeout(readNew, 100);
  });

  process.on('SIGINT', () => {
    fs.unwatchFile(absPath);
    const errColor = errorCount > 0 ? '\x1b[31m' : '\x1b[32m';
    process.stdout.write(
      `\n\x1b[2m${'─'.repeat(42)}\x1b[0m\n` +
      `\x1b[36mStopped.\x1b[0m  errors seen: ${errColor}${errorCount}\x1b[0m\n`
    );
    process.exit(0);
  });
}

// ── CLI entry point ──────────────────────────────────────────────────────────

const args = process.argv.slice(2);

if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
  console.log(`
jlog-watch v${VERSION}

  Watch a JSON log file and pretty-print each new line with ANSI colors,
  aligned log levels, and readable timestamps.

  Works with pino, bunyan, winston (JSON transport), and any log that
  writes one JSON object per line.

Usage:
  jlog-watch <logfile>        Watch a file for new JSON log lines
  jlog-watch --version        Print version
  jlog-watch --help           Show this help

Examples:
  jlog-watch app.log
  jlog-watch /var/log/myapp/current
  node server.js | tee app.log & jlog-watch app.log

Log levels:
  10 TRACE   20 DEBUG   30 INFO   40 WARN   50 ERROR   60 FATAL
`.trim());
  process.exit(0);
}

if (args.includes('--version') || args.includes('-v')) {
  console.log(VERSION);
  process.exit(0);
}

watchFile(args[0]);
