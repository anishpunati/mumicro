# envsync

> Spot missing, extra, and empty keys between `.env` and `.env.example` instantly

Purchased from [µ micro](https://mumicro.vercel.app) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd envsync
npm install -g .
```

Verify the install worked:

```bash
envsync --version
```

---

## Usage

```
envsync v1.0.0 — diff .env against .env.example

Usage:
  envsync [options] [example-file] [env-file]

Arguments:
  example-file   Path to the reference file  (default: .env.example)
  env-file       Path to the active env file (default: .env)

Options:
  --strict       Exit 1 if any keys are missing or empty
  --no-color     Disable color output
  --version      Print version
  --help         Show this help
```

### Examples

```bash
# Check .env against .env.example in the current directory
envsync

# Compare a custom template against a specific env file
envsync .env.example .env.local

# Use in CI — exits non-zero if anything is missing or empty
envsync --strict

# Compare a production env file against a template
envsync .env.template .env.production --strict
```

---

## Why this exists

**Problem:** Developers routinely ship with missing or mismatched environment variables because there is no fast CLI way to compare `.env` against `.env.example` — you either inspect both files by hand or wire up `dotenv-safe` inside application code.

**Solution:** `envsync` reads both files, computes a diff in milliseconds, and prints a color-coded report of missing keys, extra keys, and keys present but empty — with a non-zero exit code so it can gate CI or pre-commit hooks.

**How it works:** Pure Node.js with no dependencies — reads both files line-by-line, parses `KEY=VALUE` pairs while ignoring comments and blank lines, then computes set differences and emptiness checks, printing results with ANSI color codes.

---

## Support

Questions or issues? Email anishpunati@gmail.com
