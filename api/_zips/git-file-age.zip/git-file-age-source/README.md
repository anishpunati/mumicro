# git-file-age

> Shows how long ago each tracked file in your git repo was last committed, so you can spot stale or abandoned code at a glance.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd git-file-age-source
npm install -g .
```

Verify the install worked:

```bash
git-file-age --version
```

---

## Usage

```
git-file-age v1.0.0

Shows how long ago each tracked file in your git repo was last committed.
Helps you spot stale or abandoned code without digging through git log.

Usage:
  git-file-age [options]

Options:
  --sort <field>   Sort by: age (default), name, author
  --stale <days>   Days threshold for "stale" label (default: 365)
  --aging <days>   Days threshold for "aging" label (default: 90)
  --limit <n>      Show only the N oldest files
  --no-color       Disable ANSI color output
  --version        Print version
  --help           Show this help
```

### Examples

Show all files sorted by age (oldest first):

```bash
git-file-age
```

Show only the 20 oldest files:

```bash
git-file-age --limit 20
```

Use tighter thresholds and sort by file name:

```bash
git-file-age --stale 180 --aging 60 --sort name
```

Pipe to a file (auto-disables color):

```bash
git-file-age --no-color > stale-report.txt
```

Sample output:

```
Scanning git history... (47 files)

File                     Last Commit    Age     Author
────────────────────────────────────────────────────────────────
src/legacy/auth.js       2023-08-14     1005d   Dan     🔴
src/utils/format.js      2025-11-03     193d    Carol   ⚠
src/api/users.js         2026-04-22     23d     Bob     ✓
src/auth/Login.js        2026-05-10     5d      Alice   ✓

✓ recent (<90d)   ⚠ aging (90-365d)   🔴 stale (>365d)
2 recent, 1 aging, 1 stale
```

---

## Why this exists

**Problem:** There is no quick way to see which files in your codebase are actively maintained versus untouched for years — `git log` per file is tedious, and `ls -la` shows checkout dates that reset on every clone.

**Solution:** `git-file-age` runs a single `git log` command across your entire repository and renders a color-coded table of every tracked file with its last commit date, age in days, and committer.

**How it works:** Uses Node.js built-in `child_process` to run one `git log --name-only` call across all tracked files, parses the output in a single pass (newest commit first) to find each file's most recent commit, then renders a sortable table with configurable staleness thresholds.

---

## Support

Questions or issues? Email anishpunati@gmail.com
