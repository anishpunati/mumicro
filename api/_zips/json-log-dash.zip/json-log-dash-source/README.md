# json-log-dash

> Spin up a local web dashboard to browse, filter, and inspect JSON-structured log files

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd json-log-dash-source
npm install -g .
```

Verify the install worked:

```bash
json-log-dash --version
```

---

## Usage

```
json-log-dash v1.0.0

Spin up a local web dashboard to browse, filter, and inspect JSON log files.

Usage:
  json-log-dash <file>             Read from a .log file
  cat app.log | json-log-dash      Read from stdin
  json-log-dash <file> --port 8080 Use a custom port

Options:
  --port <n>    Port to listen on (default: 7777)
  --help        Show this help
  --version     Show version

Supported formats:
  Newline-delimited JSON (ndjson) — pino, winston, bunyan, and most
  structured loggers output this format. Each line must be a valid
  JSON object with optional fields: level, msg/message, time/timestamp.

Press Enter in this terminal to shut down the server.
```

### Examples

Read a pino log file:

```bash
json-log-dash server.log
```

Pipe from a running process:

```bash
node app.js | json-log-dash
```

Use a different port if 7777 is taken:

```bash
json-log-dash server.log --port 8080
```

Filter a Docker log stream in real time (saved to file first):

```bash
docker logs my-container > container.log 2>&1
json-log-dash container.log
```

**What you see in the browser:**
- A filterable table of every log entry with timestamp, level badge, and message
- Level filter buttons (trace / debug / info / warn / error / fatal)
- Full-text search across all fields
- Click any row to expand and see the full JSON record with syntax highlighting
- Handles up to 3,000 visible rows; refine filters to narrow results

---

## Why this exists

**Problem:** JSON-structured logs from node servers (pino, winston, bunyan) are unreadable as raw text — developers pipe through `jq` one query at a time or squint at minified lines, with no way to filter by level or expand nested fields without a paid cloud service.

**Solution:** `json-log-dash` reads a `.log` file or stdin, starts a local HTTP server, and opens a clean browser dashboard with level filters, full-text search, and expandable JSON record detail — all with zero dependencies.

**How it works:** Pure Node.js with no dependencies: reads newline-delimited JSON with `readline`, serves a self-contained HTML page via `http.createServer` (port 7777), inlines all CSS and JavaScript as a template literal, and opens the browser with `child_process.exec`. Server shuts down automatically after 60 seconds of inactivity or on Enter.

---

## Support

Questions or issues? Email anishpunati@gmail.com
