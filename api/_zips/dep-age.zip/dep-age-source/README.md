# dep-age

> Show when each of your npm dependencies was last published to spot abandoned packages.

Purchased from [µ micro](https://mumicro.vercel.app) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd dep-age-source
npm install -g .
```

Verify the install worked:

```bash
dep-age --version
```

---

## Usage

```
dep-age v1.0.0
Show when each npm dependency was last published.

Usage:
  dep-age [options] [path/to/package.json]

Options:
  --dev            Include devDependencies (default: false)
  --stale <n>      Flag packages not updated in N months (default: 12)
  --json           Output results as JSON
  --version        Print version and exit
  --help           Show this help

Examples:
  dep-age                       # check ./package.json
  dep-age --dev                 # include devDependencies
  dep-age --stale 6             # flag anything older than 6 months
  dep-age /path/to/package.json # check a specific file
  dep-age --json                # machine-readable output
```

### Examples

Check your project's dependencies for staleness:

```bash
$ dep-age

dep-age — checking 8 packages...

  express           2021-11-15   29 mo ago   ← red (stale)
  lodash            2022-03-07   26 mo ago   ← red (stale)
  chalk             2023-08-21   9 mo ago    ← yellow
  dotenv            2024-11-03   6 mo ago    ← green
  axios             2025-02-14   3 mo ago    ← green

⚠  2 packages stale — not updated in 12+ months.
```

Flag anything abandoned for more than 6 months and include devDependencies:

```bash
$ dep-age --dev --stale 6
```

Get JSON output for use in CI scripts or dashboards:

```bash
$ dep-age --json > dep-report.json
```

---

## Why this exists

**Problem:** When you inherit a codebase, there's no quick way to see which dependencies haven't had a release in years. You only discover abandoned packages after they cause security or compatibility issues.

**Solution:** dep-age reads your package.json and queries the npm registry for each dependency's last publish date, highlighting packages that haven't been updated in over a year.

**How it works:** Reads package.json, fires parallel HTTPS requests to registry.npmjs.org for each package, extracts the latest version's publish timestamp, and renders a colour-coded table sorted by staleness — oldest packages at the top.

---

## Support

Questions or issues? Email anishpunati@gmail.com
