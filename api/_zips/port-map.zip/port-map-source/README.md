# port-map

> Scan all listening TCP ports on your machine and open a filterable web dashboard

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd port-map-source
npm install -g .
```

Verify the install worked:

```bash
port-map --version
```

---

## Usage

```
port-map v1.0.0

  Scan all listening TCP ports on this machine and open a live web dashboard.

Usage:
  npx port-map          Open the dashboard in your default browser
  npx port-map --json   Print port data as JSON and exit (pipe-friendly)
  npx port-map --help   Show this help
  npx port-map --version Show version

Examples:
  npx port-map
  npx port-map --json
  npx port-map --json | grep '"process"'
```

### Examples

Open the interactive dashboard:

```bash
npx port-map
# port-map — 23 listening ports found
# Dashboard: http://localhost:7777
# Press Enter to close...
```

Get raw JSON for scripting:

```bash
npx port-map --json
# [
#   { "port": 22,   "pid": 412,  "process": "sshd",   "address": "*" },
#   { "port": 3000, "pid": 8821, "process": "node",   "address": "127.0.0.1" },
#   { "port": 5432, "pid": 1204, "process": "postgres","address": "127.0.0.1" },
#   ...
# ]
```

Filter to ports below 9000:

```bash
npx port-map --json | python3 -c "import json,sys; [print(r['port'], r['process']) for r in json.load(sys.stdin) if r['port'] < 9000]"
```

---

## Why this exists

**Problem:** When you hit "address already in use" or need to audit what's running on your machine, you end up squinting at `lsof -iTCP` or `ss -tlnp` output — walls of text with no filtering, no sorting, and process names truncated mid-word.

**Solution:** port-map scans all TCP listeners in under a second and opens a filterable, sortable web dashboard showing port numbers, process names, PIDs, and bind addresses — all in one glance.

**How it works:** Pure Node.js — runs `lsof` on macOS or `ss` on Linux via `child_process.execSync`, parses the output into structured JSON, serves a self-contained HTML page via `http.createServer`, then auto-opens it in the default browser. Zero dependencies, works on macOS and Linux.

---

## Support

Questions or issues? Email anishpunati@gmail.com
