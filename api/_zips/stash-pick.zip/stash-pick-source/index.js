#!/usr/bin/env node

// stash-pick — Interactive git stash browser and manager
// Navigate stashes with arrow keys, preview diffs inline, apply/pop/drop with a keypress.

'use strict';

const { execSync } = require('child_process');

const VERSION = '1.0.0';
const args = process.argv.slice(2);

if (args.includes('--version')) {
  console.log(VERSION);
  process.exit(0);
}

if (args.includes('--help')) {
  console.log(`stash-pick v${VERSION}
Interactive git stash browser

Usage: stash-pick

Controls:
  Up/k    Move selection up
  Down/j  Move selection down
  Enter   Apply selected stash (keeps it in stash list)
  p       Pop selected stash (apply and remove from list)
  d       Drop selected stash permanently
  q/Esc   Quit without changes

Options:
  --version  Print version and exit
  --help     Show this help message`);
  process.exit(0);
}

// ── ANSI helpers ─────────────────────────────────────────────────────────────
const ESC       = '\x1b[';
const RESET     = '\x1b[0m';
const BOLD      = '\x1b[1m';
const DIM       = '\x1b[2m';
const GREEN     = '\x1b[32m';
const RED       = '\x1b[31m';
const CYAN      = '\x1b[36m';
const YELLOW    = '\x1b[33m';
const BG_BLUE   = '\x1b[44m';
const WHITE     = '\x1b[37m';
const CLEAR     = '\x1b[2J\x1b[H';
const HIDE_CUR  = '\x1b[?25l';
const SHOW_CUR  = '\x1b[?25h';

// ── Git helpers ───────────────────────────────────────────────────────────────
function run(cmd) {
  try {
    return execSync(cmd, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }).trim();
  } catch (e) {
    return (e.stdout || '').trim();
  }
}

function assertGitRepo() {
  try {
    execSync('git rev-parse --git-dir', { stdio: 'ignore' });
  } catch (_) {
    console.error('stash-pick: not inside a git repository.');
    process.exit(1);
  }
}

function getStashes() {
  const raw = run('git stash list');
  if (!raw) return [];
  return raw.split('\n').map((line) => {
    const m = line.match(/^stash@\{(\d+)\}:\s*(.+)$/);
    if (!m) return null;
    return { ref: `stash@{${m[1]}}`, index: parseInt(m[1], 10), label: m[2] };
  }).filter(Boolean);
}

function getPreview(ref) {
  const stat = run(`git stash show --stat ${ref} 2>/dev/null`);
  const diff = run(`git stash show -p ${ref} 2>/dev/null`);
  return { stat, diff };
}

// ── Renderer ──────────────────────────────────────────────────────────────────
function colorDiffLine(line) {
  if (line.startsWith('+') && !line.startsWith('+++')) return GREEN + line + RESET;
  if (line.startsWith('-') && !line.startsWith('---')) return RED + line + RESET;
  if (line.startsWith('@@'))                            return CYAN + line + RESET;
  if (/^(diff|index|\+\+\+|---)/.test(line))           return YELLOW + line + RESET;
  return DIM + line + RESET;
}

function render(stashes, selected, message) {
  const cols = process.stdout.columns || 80;
  const rows = process.stdout.rows || 24;
  const divider = DIM + '  ' + '─'.repeat(Math.max(cols - 4, 4)) + RESET + '\n';

  let out = CLEAR + HIDE_CUR;

  // Header
  out += BOLD + CYAN + '  stash-pick' + RESET;
  out += DIM + '   ↑/↓ navigate   Enter apply   p pop   d drop   q quit\n' + RESET;
  out += divider;

  if (stashes.length === 0) {
    out += '\n  ' + DIM + 'No stashes found.' + RESET + '\n';
    process.stdout.write(out);
    return;
  }

  // Stash list
  const listHeight = stashes.length;
  stashes.forEach((s, i) => {
    const isSel = i === selected;
    const cursor = isSel ? BG_BLUE + WHITE + ' ▶ ' + RESET + ' ' : '   ';
    const idStr  = YELLOW + `stash@{${s.index}}` + RESET + ' ';
    const label  = isSel ? BOLD + s.label + RESET : DIM + s.label + RESET;
    out += cursor + idStr + label + '\n';
  });

  out += divider;

  // Preview panel
  const previewRows = Math.max(6, rows - listHeight - 7);
  const { stat, diff } = getPreview(stashes[selected].ref);

  if (stat) {
    out += BOLD + '  Stat:\n' + RESET;
    stat.split('\n').forEach(l => { out += '  ' + DIM + l + RESET + '\n'; });
    out += '\n';
  }

  if (diff) {
    const lines = diff.split('\n').slice(0, previewRows);
    lines.forEach(l => { out += '  ' + colorDiffLine(l) + '\n'; });
  }

  // Status message
  if (message) {
    out += '\n  ' + BOLD + message + RESET + '\n';
  }

  process.stdout.write(out);
}

// ── Cleanup ───────────────────────────────────────────────────────────────────
function cleanup() {
  process.stdout.write(SHOW_CUR + CLEAR);
  try { process.stdin.setRawMode(false); } catch (_) {}
  process.stdin.pause();
}

// ── Main ──────────────────────────────────────────────────────────────────────
function main() {
  assertGitRepo();

  let stashes = getStashes();

  if (stashes.length === 0) {
    console.log('No stashes in this repository.');
    process.exit(0);
  }

  if (!process.stdin.isTTY) {
    console.error('stash-pick requires an interactive terminal (TTY).');
    process.exit(1);
  }

  let selected = 0;
  let message  = '';

  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding('utf8');

  render(stashes, selected, message);

  process.stdin.on('data', (key) => {
    message = '';

    // Quit
    if (key === '' || key === 'q' || key === '') {
      cleanup();
      process.exit(0);
    }

    // Up
    if (key === '[A' || key === 'k') {
      selected = Math.max(0, selected - 1);
    }

    // Down
    if (key === '[B' || key === 'j') {
      selected = Math.min(stashes.length - 1, selected + 1);
    }

    // Apply (keep in list)
    if (key === '\r' || key === '\n') {
      const ref = stashes[selected].ref;
      const result = run(`git stash apply ${ref} 2>&1`);
      if (/error|conflict/i.test(result)) {
        message = `\x1b[31m✗ Conflict applying ${ref} — resolve manually\x1b[0m`;
      } else {
        message = `\x1b[32m✓ Applied ${ref}\x1b[0m`;
        stashes = getStashes();
        selected = Math.min(selected, Math.max(0, stashes.length - 1));
      }
    }

    // Pop (apply + remove)
    if (key === 'p') {
      const ref = stashes[selected].ref;
      const result = run(`git stash pop ${ref} 2>&1`);
      if (/error|conflict/i.test(result)) {
        message = `\x1b[31m✗ Conflict popping ${ref} — resolve manually\x1b[0m`;
      } else {
        message = `\x1b[32m✓ Popped ${ref}\x1b[0m`;
        stashes = getStashes();
        selected = Math.min(selected, Math.max(0, stashes.length - 1));
      }
    }

    // Drop
    if (key === 'd') {
      const ref = stashes[selected].ref;
      run(`git stash drop ${ref}`);
      message = `\x1b[33m✓ Dropped ${ref}\x1b[0m`;
      stashes = getStashes();
      if (stashes.length === 0) {
        cleanup();
        console.log('All stashes dropped.');
        process.exit(0);
      }
      selected = Math.min(selected, Math.max(0, stashes.length - 1));
    }

    if (stashes.length > 0) {
      render(stashes, selected, message);
    }
  });

  process.on('exit', cleanup);
  process.on('SIGINT', () => { cleanup(); process.exit(0); });
}

main();
