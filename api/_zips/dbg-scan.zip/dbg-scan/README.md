# dbg-scan

> Scan source files for leftover console.log, debugger, and TODO statements before you ship.

Purchased from [µ micro](https://mumicro.vercel.app) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd dbg-scan-source
npm install -g .
```

Verify the install worked:

```bash
dbg-scan --version
```

---

## Usage

```
dbg-scan v1.0.0

  Scan source files for leftover console.log, debugger, and TODO
  statements before you ship. Exits non-zero in --strict mode if
  any issues are found — drop it into a CI step or pre-commit hook.

Usage
  dbg-scan [options] [directory]

Options
  --dir <path>         Directory to scan (default: current working dir)
  --ext <exts>         Comma-separated file extensions to scan
                       (default: js,ts,jsx,tsx,mjs,cjs)
  --ignore <patterns>  Comma-separated directory names to skip
                       (default: node_modules,dist,build,.git,coverage)
  --no-todos           Skip TODO / FIXME / HACK / XXX comment checks
  --no-debugger        Skip 'debugger' statement checks
  --no-console         Skip console.* checks
  --strict             Exit with code 1 if any issues found (for CI)
  --json               Output results as JSON
  -v, --version        Print version
  -h, --help           Print this help

Examples
  dbg-scan                          # scan current directory
  dbg-scan ./src                    # scan ./src
  dbg-scan --strict                 # fail CI if anything found
  dbg-scan --no-todos --strict      # only check console + debugger in CI
  dbg-scan --ext js,ts              # only scan .js and .ts files
  dbg-scan --ignore vendor,tmp      # add extra ignore dirs
```

### Examples

**Scan your project before opening a PR:**
```bash
dbg-scan ./src
```

**Gate a CI pipeline — fail the build if any console.log or debugger found:**
```bash
dbg-scan --no-todos --strict ./src
```

**Get a machine-readable JSON report:**
```bash
dbg-scan --json > debug-report.json
```

**Use as a pre-commit hook (add to `.git/hooks/pre-commit`):**
```bash
#!/bin/sh
dbg-scan --no-todos --strict ./src
```

---

## Why this exists

**Problem:** Developers routinely ship debug artifacts — console.log, debugger keywords, and stale TODO comments — because grep is clunky and ESLint requires full project setup; there's no fast zero-config CLI that runs in any project and returns a CI-friendly exit code.

**Solution:** dbg-scan recursively walks your source files, finds every console.log/debug/warn, debugger statement, and TODO/FIXME comment, and prints a color-coded report with file:line context — exiting non-zero when issues are found so it gates CI or pre-commit hooks.

**How it works:** Pure Node.js with no dependencies: uses fs.readdirSync to walk directories, regex matching against configurable patterns, ANSI color output, and process.exit(1) when violations are found — so it works as a pre-commit hook or CI step with no config files needed.

---

## Support

Questions or issues? Email anishpunati@gmail.com
