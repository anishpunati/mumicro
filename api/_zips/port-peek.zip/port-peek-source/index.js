#!/usr/bin/env node

'use strict';

const { execSync } = require('child_process');
const os = require('os');

const VERSION = '1.0.0';

// ── ANSI codes ────────────────────────────────────────────────────────────────
const ESC       = '\x1b';
const CLEAR     = ESC + '[2J';
const HOME      = ESC + '[H';
const HIDE_CUR  = ESC + '[?25l';
const SHOW_CUR  = ESC + '[?25h';
const RESET     = ESC + '[0m';
const BOLD      = ESC + '[1m';
const DIM       = ESC + '[2m';
const RED       = ESC + '[31m';
const GREEN     = ESC + '[32m';
const CYAN      = ESC + '[36m';
const BG_SEL    = ESC + '[44m';   // blue bg for selected row

// ── Port discovery ────────────────────────────────────────────────────────────

function getPorts() {
  const platform = os.platform();
  try {
    if (platform === 'darwin') {
      const raw = execSync('lsof -iTCP -sTCP:LISTEN -P -n 2>/dev/null', { encoding: 'utf8' });
      return parseLsof(raw.trim().split('\n').slice(1));
    }
    // Linux: try ss first, fall back to netstat
    try {
      const raw = execSync('ss -tlnp 2>/dev/null', { encoding: 'utf8' });
      return parseSs(raw);
    } catch (_) {
      const raw = execSync('netstat -tlnp 2>/dev/null', { encoding: 'utf8' });
      return parseNetstat(raw);
    }
  } catch (_) {
    return [];
  }
}

function parseLsof(lines) {
  const seen = new Set();
  const rows = [];
  for (const line of lines) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 9) continue;
    const addr = parts[8];
    const m = addr.match(/:(\d+)$/);
    if (!m) continue;
    const key = `${m[1]}:${parts[1]}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push({ port: parseInt(m[1]), pid: parts[1], proc: parts[0] });
  }
  return rows.sort((a, b) => a.port - b.port);
}

function parseSs(raw) {
  const rows = [];
  for (const line of raw.trim().split('\n').slice(1)) {
    const parts = line.trim().split(/\s+/);
    const addr  = parts[3] || '';
    const m     = addr.match(/:(\d+)$/);
    if (!m) continue;
    const pid  = (line.match(/pid=(\d+)/) || [])[1] || '?';
    const proc = (line.match(/,(\w[\w-]*)(?:,pid=|\s)/) || [])[1] || '?';
    rows.push({ port: parseInt(m[1]), pid, proc });
  }
  return rows.sort((a, b) => a.port - b.port);
}

function parseNetstat(raw) {
  const rows = [];
  for (const line of raw.trim().split('\n')) {
    if (!line.includes('LISTEN')) continue;
    const parts = line.trim().split(/\s+/);
    const addr  = parts[3] || '';
    const m     = addr.match(/:(\d+)$/);
    if (!m) continue;
    const last   = parts[parts.length - 1];
    const pid    = (last.match(/^(\d+)\//) || [])[1] || '?';
    const proc   = (last.match(/^\d+\/(\S+)/) || [])[1] || '?';
    rows.push({ port: parseInt(m[1]), pid, proc });
  }
  return rows.sort((a, b) => a.port - b.port);
}

function killPid(pid) {
  try { execSync(`kill -9 ${pid} 2>/dev/null`); return true; }
  catch (_) { return false; }
}

// ── Rendering ─────────────────────────────────────────────────────────────────

function pad(s, n) {
  s = String(s);
  return s.length >= n ? s.slice(0, n) : s + ' '.repeat(n - s.length);
}

function render(ports, sel, msg) {
  const w = Math.min((process.stdout.columns || 80) - 4, 62);
  const out = [];

  out.push(CLEAR + HOME);
  out.push(`  ${BOLD}${CYAN}port-peek${RESET} ${DIM}v${VERSION} — Listening ports${RESET}`);
  out.push(`  ${DIM}${'─'.repeat(w)}${RESET}`);
  out.push(`  ${BOLD}${pad('PORT', 8)}${pad('PID', 10)}${'PROCESS'}${RESET}`);
  out.push(`  ${DIM}${'─'.repeat(w)}${RESET}`);

  if (ports.length === 0) {
    out.push(`  ${DIM}No listening ports found.${RESET}`);
  } else {
    for (let i = 0; i < ports.length; i++) {
      const { port, pid, proc } = ports[i];
      const row = pad(port, 8) + pad(pid, 10) + proc;
      if (i === sel) {
        out.push(`  ${BOLD}${GREEN}▶ ${BG_SEL}${row}${RESET}`);
      } else {
        out.push(`    ${row}`);
      }
    }
  }

  out.push('');
  out.push(`  ${DIM}${'─'.repeat(w)}${RESET}`);

  if (msg) {
    out.push(`  ${msg}`);
  } else {
    out.push(
      `  ${DIM}↑↓ navigate  ${RESET}` +
      `${RED}${BOLD}Enter${RESET}${DIM} kill  ${RESET}` +
      `${BOLD}r${RESET}${DIM} refresh  ${RESET}` +
      `${BOLD}q${RESET}${DIM} quit${RESET}`
    );
  }

  process.stdout.write(out.join('\n') + '\n');
}

// ── Entry point ───────────────────────────────────────────────────────────────

function cleanup() {
  process.stdout.write(SHOW_CUR + CLEAR + HOME);
  try { if (process.stdin.isTTY) process.stdin.setRawMode(false); } catch (_) {}
  process.stdin.pause();
}

function main() {
  const args = process.argv.slice(2);

  if (args.includes('--version') || args.includes('-v')) {
    process.stdout.write(VERSION + '\n');
    process.exit(0);
  }

  if (args.includes('--help') || args.includes('-h')) {
    process.stdout.write(`
${BOLD}port-peek${RESET} v${VERSION}

  Interactive TUI for browsing all listening ports and killing the
  process behind any port with a single keypress.

${BOLD}Usage${RESET}
  port-peek

${BOLD}Keys${RESET}
  ↑ / k     move up
  ↓ / j     move down
  Enter     kill selected process (SIGKILL)
  r         refresh port list
  q / ^C    quit

${BOLD}Notes${RESET}
  Requires lsof (macOS) or ss/netstat (Linux).
  Some system processes may require sudo to kill.
  Zero dependencies — pure Node.js built-ins only.
`);
    process.exit(0);
  }

  if (!process.stdin.isTTY) {
    process.stderr.write('port-peek requires an interactive terminal (TTY).\n');
    process.exit(1);
  }

  let ports = getPorts();
  let sel   = 0;
  let msg   = '';
  let timer = null;

  process.stdout.write(HIDE_CUR);
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding('utf8');

  process.on('SIGINT', () => { cleanup(); process.exit(0); });

  function flash(m, ms = 2200) {
    msg = m;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => { msg = ''; render(ports, sel, msg); }, ms);
  }

  render(ports, sel, msg);

  process.stdin.on('data', key => {
    if (key === '') { cleanup(); process.exit(0); }  // Ctrl+C
    if (key === 'q' || key === 'Q') { cleanup(); process.exit(0); }

    if (key === '\x1b[A' || key === 'k') {  // up
      if (sel > 0) { sel--; msg = ''; render(ports, sel, msg); }
      return;
    }
    if (key === '\x1b[B' || key === 'j') {  // down
      if (sel < ports.length - 1) { sel++; msg = ''; render(ports, sel, msg); }
      return;
    }
    if (key === 'r' || key === 'R') {        // refresh
      ports = getPorts();
      if (sel >= ports.length) sel = Math.max(0, ports.length - 1);
      flash(`${DIM}Refreshed.${RESET}`);
      render(ports, sel, msg);
      return;
    }
    if (key === '\r' || key === '\n') {      // Enter — kill
      if (ports.length === 0) return;
      const t = ports[sel];
      const ok = killPid(t.pid);
      if (ok) {
        flash(`${GREEN}${BOLD}Killed PID ${t.pid} (${t.proc} :${t.port})${RESET}`);
        ports = getPorts();
        if (sel >= ports.length) sel = Math.max(0, ports.length - 1);
      } else {
        flash(`${RED}Failed to kill PID ${t.pid} — try running with sudo.${RESET}`);
      }
      render(ports, sel, msg);
    }
  });
}

main();
