#!/usr/bin/env node

'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '1.0.0';
const DEBOUNCE_MS = 300;

function help() {
  console.log(`buildwatch v${VERSION}

Watch a build output directory and report file size changes on every rebuild.

Usage:
  buildwatch [directory] [options]

Arguments:
  directory              Directory to watch (default: ./dist)

Options:
  --threshold <bytes>    Only report files that changed by more than N bytes (default: 0)
  --help                 Show this help message
  --version              Show version number

Examples:
  buildwatch
  buildwatch ./build
  buildwatch ./dist --threshold 1024`);
}

function formatSize(bytes) {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const USE_COLOR = process.stdout.isTTY;
const C = {
  reset:  USE_COLOR ? '\x1b[0m'  : '',
  bold:   USE_COLOR ? '\x1b[1m'  : '',
  dim:    USE_COLOR ? '\x1b[2m'  : '',
  green:  USE_COLOR ? '\x1b[32m' : '',
  red:    USE_COLOR ? '\x1b[31m' : '',
  yellow: USE_COLOR ? '\x1b[33m' : '',
  cyan:   USE_COLOR ? '\x1b[36m' : '',
};
function col(color, text) { return `${C[color]}${text}${C.reset}`; }

function scanDir(dir) {
  const sizes = {};
  function walk(d) {
    let entries;
    try { entries = fs.readdirSync(d, { withFileTypes: true }); }
    catch (_) { return; }
    for (const entry of entries) {
      const full = path.join(d, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        try {
          const stat = fs.statSync(full);
          sizes[path.relative(dir, full)] = stat.size;
        } catch (_) {}
      }
    }
  }
  walk(dir);
  return sizes;
}

function printReport(prev, curr, threshold) {
  const allKeys = new Set([...Object.keys(prev), ...Object.keys(curr)]);
  const rows = [];

  for (const key of [...allKeys].sort()) {
    const prevSize = prev[key] !== undefined ? prev[key] : null;
    const currSize = curr[key] !== undefined ? curr[key] : null;
    const delta = (currSize !== null ? currSize : 0) - (prevSize !== null ? prevSize : 0);
    if (Math.abs(delta) >= threshold || prevSize === null || currSize === null) {
      rows.push({ key, prevSize, currSize, delta });
    }
  }

  if (rows.length === 0) {
    console.log(col('dim', '  (no reportable changes)'));
    return;
  }

  const maxKeyLen = Math.max(...rows.map(r => r.key.length), 8);
  const maxSzLen  = Math.max(...rows.map(r => formatSize(r.currSize !== null ? r.currSize : 0).length), 8);

  for (const { key, prevSize, currSize, delta } of rows) {
    const isNew     = prevSize === null;
    const isRemoved = currSize === null;
    const displaySz = formatSize(isRemoved ? 0 : currSize);

    let deltaStr;
    let rowColor = 'reset';

    if (isNew) {
      deltaStr = col('green', '(new)');
      rowColor = 'green';
    } else if (isRemoved) {
      deltaStr = col('dim', '(removed)');
      rowColor = 'dim';
    } else if (delta === 0) {
      deltaStr = col('dim', 'no change');
    } else if (delta > 0) {
      const pct = prevSize > 0 ? `+${((delta / prevSize) * 100).toFixed(1)}%` : '∞%';
      deltaStr = col(delta > 50 * 1024 ? 'red' : 'yellow', `+${formatSize(delta)} (${pct})`);
      rowColor = delta > 50 * 1024 ? 'red' : 'yellow';
    } else {
      const pct = prevSize > 0 ? `-${((-delta / prevSize) * 100).toFixed(1)}%` : '∞%';
      deltaStr = col('green', `-${formatSize(-delta)} (${pct})`);
      rowColor = 'green';
    }

    const kPad = key.padEnd(maxKeyLen);
    const sPad = displaySz.padStart(maxSzLen);
    console.log(`  ${col(rowColor, kPad)}  ${sPad}  ${deltaStr}`);
  }

  // Totals
  let totalPrev = 0, totalCurr = 0;
  for (const v of Object.values(prev)) totalPrev += v;
  for (const v of Object.values(curr)) totalCurr += v;
  const totalDelta = totalCurr - totalPrev;

  let totalDeltaStr = '';
  if (totalDelta > 0) {
    totalDeltaStr = col('red', `  +${formatSize(totalDelta)} (+${totalPrev > 0 ? ((totalDelta / totalPrev) * 100).toFixed(1) : '∞'}%)`);
  } else if (totalDelta < 0) {
    totalDeltaStr = col('green', `  -${formatSize(-totalDelta)} (-${totalPrev > 0 ? ((-totalDelta / totalPrev) * 100).toFixed(1) : '∞'}%)`);
  }

  console.log('');
  console.log(`  ${col('bold', 'Total:')} ${formatSize(totalCurr)}${totalDeltaStr}`);
}

function run() {
  const args = process.argv.slice(2);

  if (args.includes('--help') || args.includes('-h')) { help(); process.exit(0); }
  if (args.includes('--version') || args.includes('-v')) { console.log(VERSION); process.exit(0); }

  let watchDir = './dist';
  let threshold = 0;

  for (let i = 0; i < args.length; i++) {
    if ((args[i] === '--threshold' || args[i] === '-t') && args[i + 1]) {
      threshold = parseInt(args[++i], 10) || 0;
    } else if (!args[i].startsWith('-')) {
      watchDir = args[i];
    }
  }

  watchDir = path.resolve(watchDir);

  if (!fs.existsSync(watchDir)) {
    console.error(`Error: directory not found: ${watchDir}`);
    process.exit(1);
  }

  let snapshot = scanDir(watchDir);
  const fileCount  = Object.keys(snapshot).length;
  const totalBytes = Object.values(snapshot).reduce((a, b) => a + b, 0);

  console.log('');
  console.log(col('bold', `buildwatch v${VERSION}`));
  console.log(`Watching ${col('cyan', watchDir)}`);
  console.log(`Initial state: ${fileCount} file${fileCount !== 1 ? 's' : ''}, ${formatSize(totalBytes)} total`);
  if (threshold > 0) console.log(`Threshold: only reporting changes ≥ ${formatSize(threshold)}`);
  console.log(col('dim', 'Press Ctrl+C to stop'));
  console.log('');

  let debounceTimer = null;

  const watcher = fs.watch(watchDir, { recursive: true }, () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const newSnapshot = scanDir(watchDir);

      const changed = new Set([
        ...Object.keys(snapshot).filter(k => snapshot[k] !== newSnapshot[k]),
        ...Object.keys(newSnapshot).filter(k => snapshot[k] !== newSnapshot[k]),
        ...Object.keys(snapshot).filter(k => !(k in newSnapshot)),
        ...Object.keys(newSnapshot).filter(k => !(k in snapshot)),
      ]);

      if (changed.size > 0) {
        const now = new Date().toLocaleTimeString();
        console.log(col('cyan', `[${now}]`) + ` ${changed.size} file${changed.size !== 1 ? 's' : ''} changed`);
        console.log('');
        printReport(snapshot, newSnapshot, threshold);
        console.log('');
        snapshot = newSnapshot;
      }
    }, DEBOUNCE_MS);
  });

  process.on('SIGINT', () => {
    clearTimeout(debounceTimer);
    watcher.close();
    console.log('\n' + col('dim', 'Stopped.'));
    process.exit(0);
  });
}

run();
