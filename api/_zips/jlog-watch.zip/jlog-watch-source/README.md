# jlog-watch

> Watch a JSON log file and pretty-print each new line with ANSI colors and aligned fields.

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd jlog-watch-source
npm install -g .
```

Verify the install worked:

```bash
jlog-watch --version
```

---

## Usage

```
jlog-watch v1.0.0

  Watch a JSON log file and pretty-print each new line with ANSI colors,
  aligned log levels, and readable timestamps.

  Works with pino, bunyan, winston (JSON transport), and any log that
  writes one JSON object per line.

Usage:
  jlog-watch <logfile>        Watch a file for new JSON log lines
  jlog-watch --version        Print version
  jlog-watch --help           Show this help

Examples:
  jlog-watch app.log
  jlog-watch /var/log/myapp/current
  node server.js | tee app.log & jlog-watch app.log

Log levels:
  10 TRACE   20 DEBUG   30 INFO   40 WARN   50 ERROR   60 FATAL
```

### Examples

Watch your pino-powered API server log in real time:

```bash
node server.js | tee app.log &
jlog-watch app.log
```

Watch a log file that another process is writing to:

```bash
jlog-watch /var/log/myapp/current
```

What you see when lines arrive:

```
● jlog-watch watching /project/app.log
Press Ctrl+C to stop

2026-05-19 04:00:01.412  INFO   server listening  port=3000
2026-05-19 04:00:02.118  DEBUG  incoming request  method=GET path=/health
2026-05-19 04:00:04.903  WARN   slow query        ms=312  table=users
2026-05-19 04:00:07.551  ERROR  unhandled exception  err={"code":"ECONNREFUSED","address":"127.0.0.1"}
^C
──────────────────────────────────────────
Stopped.  errors seen: 1
```

Each line is colored by level (green=INFO, yellow=WARN, red=ERROR, magenta=FATAL). Non-JSON lines print dimmed so they don't drown the signal. File rotation is detected automatically.

---

## Why this exists

**Problem:** Structured JSON logs from frameworks like pino and bunyan are unreadable with `tail -f` — every line is a compact JSON blob with no color, no level emphasis, and no field alignment.

**Solution:** jlog-watch tails any log file, parses each JSON line as it arrives, and renders it with ANSI colors by log level, a human-readable timestamp, and key=value extras on one clean line.

**How it works:** Pure Node.js using `fs.watchFile()` for change detection, manual byte-position tracking to read only new bytes since the last event, `JSON.parse` per line, and ANSI escape codes for coloring — zero npm dependencies.

---

## Support

Questions or issues? Email anishpunati@gmail.com
