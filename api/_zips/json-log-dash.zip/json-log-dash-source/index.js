#!/usr/bin/env node

'use strict';

const fs = require('fs');
const http = require('http');
const path = require('path');
const { exec } = require('child_process');
const readline = require('readline');

const VERSION = '1.0.0';
const args = process.argv.slice(2);

if (args.includes('--version')) {
  console.log(VERSION);
  process.exit(0);
}

if (args.includes('--help') || (args.length === 0 && process.stdin.isTTY)) {
  console.log(`
json-log-dash v${VERSION}

Spin up a local web dashboard to browse, filter, and inspect JSON log files.

Usage:
  json-log-dash <file>             Read from a .log file
  cat app.log | json-log-dash      Read from stdin
  json-log-dash <file> --port 8080 Use a custom port

Options:
  --port <n>    Port to listen on (default: 7777)
  --help        Show this help
  --version     Show version

Supported formats:
  Newline-delimited JSON (ndjson) — pino, winston, bunyan, and most
  structured loggers output this format. Each line must be a valid
  JSON object with optional fields: level, msg/message, time/timestamp.

Press Enter in this terminal to shut down the server.
`);
  process.exit(0);
}

// Parse --port flag
let port = 7777;
const portIdx = args.indexOf('--port');
if (portIdx !== -1 && args[portIdx + 1]) {
  port = parseInt(args[portIdx + 1], 10) || 7777;
}

// Find file arg (first arg that isn't a flag or the port value)
const skipNext = new Set();
if (portIdx !== -1) skipNext.add(portIdx + 1);
const fileArg = args.find((a, i) => !a.startsWith('--') && !skipNext.has(i));

const inputStream = fileArg
  ? fs.createReadStream(path.resolve(fileArg))
  : process.stdin;

if (fileArg && !fs.existsSync(path.resolve(fileArg))) {
  console.error(`Error: file not found: ${fileArg}`);
  process.exit(1);
}

// ── Parse all newline-delimited JSON lines ────────────────────────────────────
const entries = [];
const parseErrors = [];
let lineNum = 0;

const rl = readline.createInterface({ input: inputStream, crlfDelay: Infinity });

rl.on('line', line => {
  lineNum++;
  const trimmed = line.trim();
  if (!trimmed) return;
  try {
    const obj = JSON.parse(trimmed);
    if (typeof obj === 'object' && obj !== null && !Array.isArray(obj)) {
      entries.push(obj);
    }
  } catch {
    parseErrors.push({ line: lineNum, raw: trimmed.slice(0, 120) });
  }
});

rl.on('close', () => startServer());
rl.on('error', err => {
  console.error(`Error reading input: ${err.message}`);
  process.exit(1);
});

// ── Server ────────────────────────────────────────────────────────────────────
function startServer() {
  const count = entries.length;
  if (count === 0 && parseErrors.length === 0) {
    console.error('No log entries found. Make sure the file contains newline-delimited JSON.');
    process.exit(1);
  }

  const entriesJson = JSON.stringify(entries);
  const errorsJson  = JSON.stringify(parseErrors);

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>json-log-dash — ${count.toLocaleString()} entries</title>
<style>
  :root {
    --bg:      #0f1117;
    --surface: #1a1d27;
    --border:  #2a2d3d;
    --text:    #e2e8f0;
    --muted:   #94a3b8;
    --accent:  #6366f1;
    --trace:   #475569;
    --debug:   #0891b2;
    --info:    #059669;
    --warn:    #d97706;
    --error:   #dc2626;
    --fatal:   #9333ea;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace; font-size: 13px; height: 100vh; display: flex; flex-direction: column; }
  header { background: var(--surface); border-bottom: 1px solid var(--border); padding: 12px 20px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap; flex: 0 0 auto; }
  header h1 { font-size: 15px; font-weight: 700; color: var(--accent); flex: 0 0 auto; }
  #search { flex: 1; min-width: 180px; background: var(--bg); border: 1px solid var(--border); border-radius: 6px; padding: 6px 10px; color: var(--text); font-family: inherit; font-size: 13px; outline: none; }
  #search:focus { border-color: var(--accent); }
  .levels { display: flex; gap: 5px; flex-wrap: wrap; }
  .lvl-btn { padding: 3px 10px; border-radius: 4px; border: 1px solid var(--border); background: transparent; color: var(--muted); cursor: pointer; font-size: 11px; font-family: inherit; transition: background .12s, color .12s, border-color .12s; }
  .lvl-btn:hover { border-color: var(--muted); color: var(--text); }
  .lvl-btn.active[data-lvl="ALL"]   { background: var(--accent); border-color: var(--accent); color: #fff; }
  .lvl-btn.active[data-lvl="trace"] { background: var(--trace);  border-color: var(--trace);  color: #fff; }
  .lvl-btn.active[data-lvl="debug"] { background: var(--debug);  border-color: var(--debug);  color: #fff; }
  .lvl-btn.active[data-lvl="info"]  { background: var(--info);   border-color: var(--info);   color: #fff; }
  .lvl-btn.active[data-lvl="warn"]  { background: var(--warn);   border-color: var(--warn);   color: #fff; }
  .lvl-btn.active[data-lvl="error"] { background: var(--error);  border-color: var(--error);  color: #fff; }
  .lvl-btn.active[data-lvl="fatal"] { background: var(--fatal);  border-color: var(--fatal);  color: #fff; }
  #stats-bar { padding: 6px 20px; background: var(--surface); border-bottom: 1px solid var(--border); color: var(--muted); font-size: 11px; flex: 0 0 auto; }
  .scroll-wrap { flex: 1; overflow-y: auto; }
  table { width: 100%; border-collapse: collapse; }
  thead th { position: sticky; top: 0; background: var(--surface); border-bottom: 1px solid var(--border); padding: 7px 12px; text-align: left; color: var(--muted); font-weight: 600; font-size: 10px; letter-spacing: .6px; text-transform: uppercase; z-index: 2; }
  tbody tr.data-row { cursor: pointer; }
  tbody tr.data-row:hover td { background: #1e2132; }
  tbody tr.data-row.open td { background: #1b1f31; }
  td { padding: 5px 12px; border-bottom: 1px solid #1c1f2e; vertical-align: middle; }
  .col-n    { width: 60px;  color: var(--muted); font-size: 11px; text-align: right; }
  .col-time { width: 155px; color: var(--muted); white-space: nowrap; font-size: 11px; }
  .col-lvl  { width: 64px; }
  .col-msg  { }
  .col-exp  { width: 24px; text-align: center; color: var(--muted); font-size: 10px; }
  .msg-inner { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 700px; }
  .badge { display: inline-block; padding: 1px 7px; border-radius: 3px; font-size: 10px; font-weight: 700; letter-spacing: .3px; }
  .badge.trace { background: var(--trace); color: #fff; }
  .badge.debug { background: var(--debug); color: #fff; }
  .badge.info  { background: var(--info);  color: #fff; }
  .badge.warn  { background: var(--warn);  color: #fff; }
  .badge.error { background: var(--error); color: #fff; }
  .badge.fatal { background: var(--fatal); color: #fff; }
  tr.detail-row td { padding: 0 12px 10px 72px; background: #181b2c; }
  .detail-box { background: var(--bg); border: 1px solid var(--border); border-radius: 5px; padding: 10px 14px; overflow: auto; max-height: 340px; white-space: pre; font-size: 12px; line-height: 1.65; }
  .k  { color: #93c5fd; }
  .s  { color: #86efac; }
  .n  { color: #fbbf24; }
  .b  { color: #f472b6; }
  .nl { color: var(--muted); }
  #empty { text-align: center; padding: 80px 24px; color: var(--muted); }
</style>
</head>
<body>
<header>
  <h1>json-log-dash</h1>
  <input id="search" type="search" placeholder="Search all fields…" autocomplete="off" spellcheck="false">
  <div class="levels">
    <button class="lvl-btn active" data-lvl="ALL">all</button>
    <button class="lvl-btn" data-lvl="trace">trace</button>
    <button class="lvl-btn" data-lvl="debug">debug</button>
    <button class="lvl-btn" data-lvl="info">info</button>
    <button class="lvl-btn" data-lvl="warn">warn</button>
    <button class="lvl-btn" data-lvl="error">error</button>
    <button class="lvl-btn" data-lvl="fatal">fatal</button>
  </div>
</header>
<div id="stats-bar"></div>
<div class="scroll-wrap">
  <table>
    <thead>
      <tr>
        <th class="col-n">#</th>
        <th class="col-time">Time</th>
        <th class="col-lvl">Level</th>
        <th class="col-msg">Message</th>
        <th class="col-exp"></th>
      </tr>
    </thead>
    <tbody id="tbody"></tbody>
  </table>
  <div id="empty" style="display:none">No matching entries.</div>
</div>

<script>
const RAW    = ${entriesJson};
const ERRORS = ${errorsJson};

// ── Normalise log entry fields ────────────────────────────────────────────────
function lvlNum(n) {
  if (n < 20) return 'trace';
  if (n < 30) return 'debug';
  if (n < 40) return 'info';
  if (n < 50) return 'warn';
  if (n < 60) return 'error';
  return 'fatal';
}
function getLevel(e) {
  const v = e.level ?? e.Level ?? e.severity ?? e.lvl ?? e.LEVEL ?? '';
  if (typeof v === 'number') return lvlNum(v);
  const s = String(v).toLowerCase();
  return ['trace','debug','info','warn','warning','error','fatal','critical'].includes(s)
    ? (s === 'warning' ? 'warn' : s === 'critical' ? 'fatal' : s)
    : 'info';
}
function getTime(e) {
  const v = e.time ?? e.timestamp ?? e.ts ?? e.date ?? e['@timestamp'] ?? e.Time ?? '';
  if (!v) return '';
  const d = new Date(typeof v === 'number' && v < 1e12 ? v * 1000 : v);
  if (isNaN(d)) return String(v).slice(0, 26);
  return d.toISOString().replace('T', ' ').replace(/\\.\\d+Z$/, '');
}
function getMsg(e) {
  return String(e.msg ?? e.message ?? e.Message ?? e.text ?? e.event ?? '');
}
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function colorJson(obj) {
  return JSON.stringify(obj, null, 2)
    .replace(/("(?:\\\\u[a-fA-F0-9]{4}|\\\\[^u]|[^\\\\"])*"(?:\\s*:)?|\\b(?:true|false|null)\\b|-?\\d+(?:\\.\\d*)?(?:[eE][+-]?\\d+)?)/g, m => {
      if (/^"/.test(m)) {
        if (/:$/.test(m)) return '<span class="k">' + esc(m) + '</span>';
        return '<span class="s">' + esc(m) + '</span>';
      }
      if (m === 'true' || m === 'false') return '<span class="b">' + m + '</span>';
      if (m === 'null') return '<span class="nl">' + m + '</span>';
      return '<span class="n">' + m + '</span>';
    });
}

// ── Build normalised entry list ───────────────────────────────────────────────
const entries = RAW.map((raw, i) => ({
  i, raw,
  level: getLevel(raw),
  time:  getTime(raw),
  msg:   getMsg(raw),
  str:   JSON.stringify(raw).toLowerCase(),
}));

// ── Stats bar ─────────────────────────────────────────────────────────────────
const counts = {};
entries.forEach(e => { counts[e.level] = (counts[e.level] || 0) + 1; });
const statsBar = document.getElementById('stats-bar');
const order = ['fatal','error','warn','info','debug','trace'];
const cParts = order.filter(l => counts[l]).map(l => counts[l] + ' ' + l);
statsBar.textContent =
  entries.length.toLocaleString() + ' entries' +
  (cParts.length ? '  ·  ' + cParts.join('  ') : '') +
  (ERRORS.length ? '  ·  ' + ERRORS.length + ' parse error(s)' : '');

// ── State ─────────────────────────────────────────────────────────────────────
let activeLevel = 'ALL';
let query = '';

function render() {
  const q = query.toLowerCase();
  const filtered = entries.filter(e => {
    if (activeLevel !== 'ALL' && e.level !== activeLevel) return false;
    if (q && !e.str.includes(q) && !e.msg.toLowerCase().includes(q)) return false;
    return true;
  });

  const tbody = document.getElementById('tbody');
  tbody.innerHTML = '';

  if (filtered.length === 0) {
    document.getElementById('empty').style.display = '';
    return;
  }
  document.getElementById('empty').style.display = 'none';

  const cap = 3000;
  const visible = filtered.slice(0, cap);

  visible.forEach((e, rowIdx) => {
    const tr = document.createElement('tr');
    tr.className = 'data-row';
    tr.innerHTML =
      '<td class="col-n">' + (e.i + 1) + '</td>' +
      '<td class="col-time">' + esc(e.time) + '</td>' +
      '<td class="col-lvl"><span class="badge ' + e.level + '">' + e.level + '</span></td>' +
      '<td class="col-msg"><div class="msg-inner">' + esc(e.msg) + '</div></td>' +
      '<td class="col-exp">▶</td>';
    tr.addEventListener('click', () => toggleDetail(tr, e));
    tbody.appendChild(tr);
  });

  if (filtered.length > cap) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td colspan="5" style="text-align:center;color:var(--muted);padding:14px;font-size:12px">' +
      (filtered.length - cap).toLocaleString() + ' more entries — refine your search or level filter</td>';
    tbody.appendChild(tr);
  }

  statsBar.dataset.shown = filtered.length;
}

function toggleDetail(tr, e) {
  const id = 'det-' + e.i;
  const existing = document.getElementById(id);
  if (existing) {
    existing.remove();
    tr.classList.remove('open');
    tr.querySelector('.col-exp').textContent = '▶';
    return;
  }
  tr.classList.add('open');
  tr.querySelector('.col-exp').textContent = '▼';
  const dr = document.createElement('tr');
  dr.id = id;
  dr.className = 'detail-row';
  dr.innerHTML = '<td colspan="5"><div class="detail-box">' + colorJson(e.raw) + '</div></td>';
  tr.after(dr);
}

document.getElementById('search').addEventListener('input', ev => {
  query = ev.target.value.trim();
  render();
});

document.querySelectorAll('.lvl-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.lvl-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeLevel = btn.dataset.lvl;
    render();
  });
});

render();
</script>
</body>
</html>`;

  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  server.listen(port, '127.0.0.1', () => {
    const url = `http://localhost:${port}`;
    console.log(`\njson-log-dash — ${count.toLocaleString()} entr${count === 1 ? 'y' : 'ies'} loaded`);
    if (parseErrors.length > 0) {
      console.log(`  (${parseErrors.length} line(s) skipped — not valid JSON)`);
    }
    console.log(`\n  Server: ${url}\n`);
    console.log('  Press Enter to stop.\n');

    const open = process.platform === 'darwin' ? 'open'
               : process.platform === 'win32'  ? 'start'
               : 'xdg-open';
    exec(`${open} "${url}"`);
  });

  // Shut down on Enter keypress
  if (process.stdin.isTTY) {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', ch => {
      if (ch === '\r' || ch === '\n' || ch === '\x03') {
        console.log('\nServer stopped.');
        server.close(() => process.exit(0));
      }
    });
  }

  // Also shut down after 60 s of inactivity
  let lastHit = Date.now();
  server.on('request', () => { lastHit = Date.now(); });
  const idle = setInterval(() => {
    if (Date.now() - lastHit > 60_000) {
      clearInterval(idle);
      console.log('\nNo activity for 60 s — shutting down.');
      server.close(() => process.exit(0));
    }
  }, 10_000);

  server.on('error', err => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${port} is already in use. Try: json-log-dash <file> --port 7778`);
      process.exit(1);
    }
    throw err;
  });
}
