# croncheck

> Parse and preview cron expressions interactively — see the next 10 run times before you deploy

Purchased from [µ micro](https://anishpunati.github.io/mumicro/) — a new developer tool, shipped daily.

---

## Install

After unzipping this archive:

```bash
cd croncheck-source
npm install -g .
```

Verify the install worked:

```bash
croncheck --version
```

---

## Usage

```
croncheck v1.0.0
Parse and preview cron expressions interactively.

Usage:
  croncheck [expression]

Options:
  --help, -h     Show this help
  --version, -v  Show version

Examples:
  croncheck                    # Launch interactive TUI
  croncheck "0 */4 * * *"      # Preview a specific expression and exit
  croncheck "30 9 * * 1-5"     # Mon-Fri at 9:30am
  croncheck "0 0 1 * *"        # First day of every month

Cron format:
  ┌─────── minute (0-59)
  │ ┌───── hour (0-23)
  │ │ ┌─── day of month (1-31)
  │ │ │ ┌─ month (1-12)
  │ │ │ │ ┌ day of week (0-6, Sun=0)
  │ │ │ │ │
  * * * * *
```

### Examples

**One-shot preview — check an expression and exit:**
```bash
croncheck "30 9 * * 1-5"
```
Output:
```
  Expression: 30 9 * * 1-5
  Meaning:    minute 30, hour 9, every day, every month, weekdays 1-5

  Next 10 run times:
   1. Mon May 25 2026  09:30  in 4d 23h
   2. Tue May 26 2026  09:30  in 5d 23h
   3. Wed May 27 2026  09:30  in 6d 23h
   ...
```

**Every 4 hours:**
```bash
croncheck "0 */4 * * *"
```

**Interactive TUI (no arguments) — type expressions and see live results:**
```bash
croncheck
```
Press Tab to cycle through built-in examples. Use ↑↓ to navigate history. Press `q` or Ctrl+C to quit.

---

## Why this exists

**Problem:** Cron syntax is notoriously hard to verify — developers copy expressions from Stack Overflow or write their own, then paste them into random online parsers to check them, often without offline access or confidence in edge-case handling.

**Solution:** croncheck is a zero-dependency interactive TUI that parses cron expressions locally, annotates each field in plain English, and shows the next 10 scheduled run times with relative timestamps — no browser, no network call.

**How it works:** Pure Node.js cron parser that expands each field (minute, hour, day, month, weekday) into a sorted array of valid values using set arithmetic, then advances a Date object forward one minute at a time to collect the next N matching timestamps, rendered in a raw-mode terminal UI.

---

## Support

Questions or issues? Email anishpunati@gmail.com
